﻿/* ===== Malevo v3.0 · Panel de Administración ===== */
'use strict';

/* ── Constantes ── */
const DISCIPLINAS_VIDEO  = ['Bachata','Salsa'];
const DISCIPLINAS_ASIST  = ['Zumba','Tango','Ritmos Libres'];
const TODAS_DISCIPLINAS  = [...DISCIPLINAS_VIDEO,...DISCIPLINAS_ASIST,'Otro'];
const NIVELES            = [1,2,3,4];
const DIAS               = ['Dom','Lun','Mar','Mié','Jue','Vie','Sáb'];
const DIAS_FULL          = ['Domingo','Lunes','Martes','Miércoles','Jueves','Viernes','Sábado'];
const PLANES = {
  'suelta': 'Clase suelta',
  '35':     '1 clase/sem',
  '50':     '2 clases/sem',
  '80':     'VIP · Full Pass',
  'bono':   'Bono 10 clases'
};
const PORTAL_PLANS = ['35','50','80'];
const ROLES_LABEL= { admin:'Admin',teacher:'Profesor',student:'Alumno',guest:'Invitado' };

/* ── Catálogo oficial de vídeos de YouTube por disciplina y nivel ──
   Fuente: estructura oficial proporcionada por la academia.
   Se siembra automáticamente en el arranque (sembrarCatalogoOficialVideos,
   llamada desde arrancarApp) — no requiere ninguna acción manual del admin. */
const CATALOGO_OFICIAL_VIDEOS = {
  bachata: {
    nivel1: ['uYU3HiNVKM8','IavcdMT3M28','WoQGCSsZ23w','Mg3px2M_UVk','LBU9EJETy8g','0QeH4BMywhI'],
    nivel2: ['0QeH4BMywhI','YPZL4hobRP0'],
    nivel3: ['0QeH4BMywhI','Lb1nc_YciT0']
  },
  salsa: {
    nivel1: ['IfAR1EqRjeE','kCJ-Hmy32pw','oQVgBItTr04','GJCE0cpGX6c','IavcdMT3M28','84l5Y_Fxo9c','96p88pO-H-E','86HDu6kT2kc','zT-BGPOE1tc','D_oG0LbmxWE','ca-nJ8NT8rg','Cd-UnDCUusc'],
    nivel2: ['zT-BGPOE1tc','Z-tsOAUX4sI','23e2dYRDLWI','VsNGPg3n2m4','OvFVyPy6WAM','QAs_zB29ufc','DzAANwMqI_E','IbsPlQ3CA2s','0L8O8RSrwS4'],
    nivel3: ['zUoXytGVHHI','RVF1FDFIc2E','unXFLyUc3nU','9M8x3aFQX90','mx5eoRgAAkE','vnqbh9hR7LQ','CoNMTYl9Rb8','OGddunSLCD4','mQra8BCQdd8','nEHawWIA80c','Lb1nc_YciT0']
  }
};

/* ── Estado global ── */
let db       = null;
let _rev     = 0;
let _syncTimer = null;
let currentUser = null;
let activeView  = 'dashboard';

/* ── Helpers ── */
const eur = n => Number(n||0).toLocaleString('es-ES',{style:'currency',currency:'EUR',minimumFractionDigits:2});
const hoy = () => new Date().toISOString().slice(0,10);
const mesActual = () => new Date().toISOString().slice(0,7);
const iniciales = n => (n||'').trim().split(/\s+/).slice(0,2).map(w=>w[0]).join('').toUpperCase()||'?';

/* ── Nivel 4 se muestra como "Coreografías" en toda la interfaz de vídeo ── */
const nivelLabel = n => n===4 ? 'Coreografías' : 'Nivel '+n;
const nivelLabelCorto = n => n===4 ? 'Coreo' : 'N'+n;
const uuid = () => 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g,c=>{
  const r=Math.random()*16|0; return (c==='x'?r:r&0x3|0x8).toString(16); });
function esc(s){ return String(s??'').replace(/[&<>"']/g,c=>
  ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function $(id){ return document.getElementById(id); }
function el(tag,attrs,content){
  const e=document.createElement(tag);
  Object.entries(attrs||{}).forEach(([k,v])=>{ if(k==='style')e.style.cssText=v; else e.setAttribute(k,v); });
  if(content!=null) e.innerHTML=content;
  return e;
}

/* ── Ripple (onda expansiva) global — delegado, no requiere tocar cada botón ── */
document.addEventListener('pointerdown', function(e){
  const el = e.target.closest('.btn, .nav-btn, .alumno-card, .alumno-action, .acc-toggle');
  if (!el) return;
  const rect = el.getBoundingClientRect();
  const size = Math.max(rect.width, rect.height) * 1.4;
  const span = document.createElement('span');
  span.className = 'ripple-span';
  span.style.width = span.style.height = size+'px';
  span.style.left = (e.clientX - rect.left - size/2)+'px';
  span.style.top  = (e.clientY - rect.top  - size/2)+'px';
  el.appendChild(span);
  setTimeout(()=>span.remove(), 620);
});

/* ── API ── */
async function api(method, path_, data){
  const opts = { method, headers:{'Content-Type':'application/json'}, credentials:'same-origin' };
  if (data) opts.body = JSON.stringify(data);
  const r = await fetch(path_,opts);
  if (r.status===401) { mostrarLogin(); throw new Error('401'); }
  if (r.status===403) { throw new Error('403: Acceso denegado'); }
  return r;
}
async function apiJSON(method, path_, data){
  const r = await api(method,path_,data);
  return r.json();
}

/* ── Logo del negocio en el header (arriba a la izquierda) ── */
function actualizarLogoHeader(){
  const cont = $('mainBrandIcon');
  if (!cont) return;
  const logo = db?.config?.negocio?.logo;
  cont.innerHTML = logo
    ? `<img src="${logo}" alt="Logo" style="width:100%;height:100%;object-fit:contain;border-radius:10px;">`
    : `<span>M</span>`;
}

/* ── DB helpers ── */
async function cargarDB(){
  const r = await api('GET','/api/db');
  if (!r.ok) throw new Error('HTTP '+r.status);
  db = await r.json();
  _rev = db._rev||0;
  return db;
}
async function guardarDB(){
  const r = await apiJSON('PUT','/api/db',db);
  if (r._rev) { _rev=r._rev; db._rev=r._rev; }
  marcarEstado(true);
}
function guardar(){
  guardarDB().then(()=>{}).catch(()=>{ marcarEstado(false); showToast('Sin conexión — cambios guardados localmente','warn'); });
}

function marcarEstado(online){
  const elem=$('estadoSync');
  if(!elem) return;
  const dot=elem.querySelector('.dot');
  // Actualizar texto (último nodo de texto)
  const nodes=[...elem.childNodes];
  const textNode=nodes.find(n=>n.nodeType===3&&n.textContent.trim());
  if(textNode) textNode.textContent=online?' En línea':' Sin conexión';
  else elem.insertAdjacentText('beforeend',online?' En línea':' Sin conexión');
  elem.className=online?'sync-online':'sync-offline';
  if(dot){
    dot.style.background=online?'var(--ok)':'var(--warn)';
    dot.style.boxShadow=online?'0 0 8px var(--ok-glow)':'none';
  }
}

async function sincronizar(){
  try {
    const r = await fetch('/api/db',{cache:'no-store',credentials:'same-origin'});
    if (r.status===401){ marcarEstado(false); mostrarLogin(); return; }
    if (!r.ok) return;
    const d = await r.json();
    marcarEstado(true);
    if ((d._rev||0) > _rev){ db=d; _rev=db._rev||0; actualizarLogoHeader(); refrescarVista(); }
  } catch { marcarEstado(false); }
}

/* ── Navegación ── */
const VIEWS_ADMIN   = ['dashboard','alumnos','clases','pagos','videos'];
const VIEWS_TEACHER = ['dashboard','clases'];
const VIEW_LABELS   = {
  dashboard:'Dashboard', alumnos:'Alumnos', clases:'Clases',
  pagos:'Pagos', videos:'Multimedia', config:'Configuración'
};
const VIEW_ICONS = {
  dashboard:'◉', alumnos:'◍', clases:'▦',
  pagos:'◆', videos:'▶', config:'⚙'
};

function buildNav(){
  const nav = $('mainNav');
  nav.innerHTML='';
  const views = currentUser.role==='admin' ? VIEWS_ADMIN : VIEWS_TEACHER;

  // Logo / título compacto en la cabecera del sidebar
  const header = document.createElement('div');
  header.style.cssText='padding:4px 8px 16px;border-bottom:1px solid rgba(255,215,0,.1);margin-bottom:12px;';
  header.innerHTML=`<div style="font-size:9.5px;text-transform:uppercase;letter-spacing:2px;
    color:var(--muted);font-weight:700;">Panel Admin</div>`;
  nav.appendChild(header);

  views.forEach(v=>{
    const b=document.createElement('button');
    b.dataset.vista=v;
    b.className='nav-btn';
    b.innerHTML=`<span style="font-size:14px;opacity:.75;flex:0 0 auto;">${VIEW_ICONS[v]||'·'}</span>
      <span>${VIEW_LABELS[v]}</span>`;
    b.onclick=()=>{ navigateTo(v); };
    nav.appendChild(b);
  });

  // Separador inferior
  const sep = document.createElement('div');
  sep.style.cssText='flex:1;';
  nav.appendChild(sep);

  const footer = document.createElement('div');
  footer.style.cssText='border-top:1px solid rgba(255,215,0,.1);padding-top:12px;margin-top:8px;';
  footer.innerHTML=`<div style="font-size:10.5px;color:var(--faint);padding:4px 8px;line-height:1.5;">
    Malevo v3.0<br><span style="color:var(--muted);">Academia de Baile</span></div>`;
  nav.appendChild(footer);
}

function toggleSidebar(){
  const nav = $('mainNav');
  const overlay = $('sidebarOverlay');
  if(!nav || !overlay) return;
  nav.classList.toggle('open');
  overlay.classList.toggle('open');
}

function navigateTo(v){
  activeView=v;
  document.querySelectorAll('.nav-btn').forEach(b=>{
    b.classList.toggle('active', b.dataset.vista===v);
  });
  const nav=$('mainNav'), ov=$('sidebarOverlay');
  if(nav) nav.classList.remove('open');
  if(ov)  ov.classList.remove('open');
  playNav();
  renderView(v);
}

function refrescarVista(){ renderView(activeView); }

function renderView(v){
  const main=$('mainContent');
  main.innerHTML='';
  const fade=el('div',{style:'animation:fade .28s cubic-bezier(.4,0,.2,1);'});
  main.appendChild(fade);
  if (v==='dashboard')  renderHoy(fade);
  else if(v==='alumnos')   renderAlumnos(fade);
  else if(v==='clases')    renderClases(fade);
  else if(v==='pagos')     renderPagos(fade);
  else if(v==='videos')    renderVideos(fade);
  else if(v==='informes')  renderConfig(fade);
  else if(v==='config')    renderConfig(fade);
}

/* ── Finanzas helpers ── */
function calcularReparto(importe, numPago){
  const c=db.config;
  const base=importe/(1+c.iva/100);
  const iva=importe-base;
  const esIni = numPago<=(c.mesesIniciales||3);
  const r = esIni ? c.inicial : c.posterior;
  return { importe, base, iva, malevo:base*(r.malevo/100), box:base*(r.box/100),
    periodo: esIni?'Inicial':'Posterior', malevoPct:r.malevo, boxPct:r.box };
}
function numPagoDeUsuario(userId, mes, excluirId){
  const lista = db.payments
    .filter(p=>p.userId===userId && p.id!==excluirId)
    .map(p=>p.mes);
  if (!lista.includes(mes)) lista.push(mes);
  lista.sort();
  return lista.indexOf(mes)+1;
}
function precioUsuario(u){
  return db.config.precios[u.plan]??0;
}
function nombreUsuario(id){
  if(!id || id==='__anonimo__') return '— Anónimo (simplif.)';
  const u=(db.users||[]).find(x=>x.id===id);
  return u?u.nombre:'(eliminado)';
}

/* ── Vista HOY ── */
/* ── Vista HOY (Dashboard) ── */
/* ══════════════════════════════════════════════════════
   DASHBOARD — Diseño nuevo con imagen de bailarines
══════════════════════════════════════════════════════ */
/* ══ DASHBOARD ══ */
/* ══ DASHBOARD ══ */
/* ══ DASHBOARD — imagen completa de fondo + HTML encima ══ */
/* ── Vista HOY (Dashboard) ── */
function renderHoy(cont){
  var ahora=new Date();
  var dow=ahora.getDay(), mes=mesActual(), today=hoy();
  var hora=ahora.getHours();
  var saludo=hora<13?'¡Buenos días':hora<20?'¡Buenas tardes':'¡Buenas noches';
  var nombre=(currentUser&&currentUser.nombre||'').split(' ')[0]||'Admin';
  var fechaStr=ahora.toLocaleDateString('es-ES',{weekday:'long',day:'numeric',month:'long',year:'numeric'});

  var clasesHoy=(db.classes||[]).filter(function(c){return c.dia===dow;}).sort(function(a,b){return(a.inicio||'').localeCompare(b.inicio||'');});
  var alumnosActivos=(db.users||[]).filter(function(u){return u.active&&u.role==='student';}).length;
  var totalAlumnos=(db.users||[]).filter(function(u){return u.role==='student';}).length;
  var faltaCobrar=new Map();
  clasesHoy.forEach(function(c){
    usersOfClass(c.id).forEach(function(u){
      if(!u.guestCourtesy&&!db.payments.find(function(p){return p.userId===u.id&&p.mes===mes;}))
        faltaCobrar.set(u.id,u);
    });
  });
  var ingresosMes=(db.payments||[]).filter(function(p){return p.mes===mes;}).reduce(function(s,p){return s+(p.importe||0);},0);
  var pagosHoy=(db.payments||[]).filter(function(p){return p.fechaPago===today;}).length;

  // Datos para el gráfico de asistencia (últimos 7 días, incluyendo hoy)
  var DIAS_CORTO=['D','L','M','X','J','V','S'];
  var asistenciaSemana=[];
  for(var i=6;i>=0;i--){
    var d=new Date(ahora); d.setDate(d.getDate()-i);
    var fStr=d.toISOString().slice(0,10);
    var presentes=(db.attendances||[]).filter(function(a){return a.fecha===fStr&&a.present;}).length;
    asistenciaSemana.push({label:DIAS_CORTO[d.getDay()],value:presentes,hoy:i===0});
  }

  // Datos para el gráfico de ingresos (últimos 6 meses, incluyendo el actual)
  var MESES_CORTO=['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'];
  var ingresosMeses=[];
  for(var j=5;j>=0;j--){
    var dm=new Date(ahora.getFullYear(),ahora.getMonth()-j,1);
    var mStr=dm.toISOString().slice(0,7);
    var total=(db.payments||[]).filter(function(p){return p.mes===mStr;}).reduce(function(s,p){return s+(p.importe||0);},0);
    ingresosMeses.push({label:MESES_CORTO[dm.getMonth()],value:total,hoy:j===0});
  }

  var uAdmin=(db.users||[]).find(function(x){return x.id===(currentUser&&currentUser.sub);});
  var fotoAdmin=uAdmin&&uAdmin.fotoPerfil;
  var avatarHtml=fotoAdmin
    ? '<img src="'+esc(fotoAdmin)+'" alt="" style="width:100%;height:100%;object-fit:cover;">'
    : '<span style="font-family:\'Sora\',sans-serif;font-weight:700;font-size:19px;color:var(--text-2);">'+iniciales(nombre)+'</span>';

  var h='';

  /* ── HERO ── */
  h+='<div style="'+
    'background:var(--card-bg);'+
    'border:1px solid var(--card-border);border-radius:var(--r-xl);'+
    'padding:28px 34px;margin-bottom:24px;">'+
    '<div style="display:flex;align-items:center;justify-content:space-between;gap:20px;flex-wrap:wrap;">'+
      '<div style="display:flex;align-items:center;gap:16px;">'+
        '<button onclick="abrirGestorAvatarAdmin()" title="Cambiar foto de perfil" style="'+
          'flex:0 0 auto;width:58px;height:58px;border-radius:50%;overflow:hidden;cursor:pointer;'+
          'background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.14);padding:0;'+
          'display:flex;align-items:center;justify-content:center;position:relative;transition:border-color .2s;"'+
          'onmouseover="this.style.borderColor=\'rgba(255,255,255,.32)\'" onmouseout="this.style.borderColor=\'rgba(255,255,255,.14)\'">'+
          avatarHtml+
        '</button>'+
        '<div>'+
          '<div style="font-size:10.5px;color:var(--muted);text-transform:uppercase;letter-spacing:2px;margin-bottom:5px;">Panel de control</div>'+
          '<h1 style="font-family:\'Sora\',sans-serif;font-size:clamp(19px,2.3vw,28px);font-weight:700;'+
            'color:var(--text);letter-spacing:-.3px;margin-bottom:4px;">'+saludo+', '+esc(nombre)+'!</h1>'+
          '<p style="color:var(--text-2);font-size:13px;">'+fechaStr+'</p>'+
        '</div>'+
      '</div>'+
      '<div style="display:flex;flex-direction:column;align-items:flex-end;gap:7px;">'+
        '<div style="display:inline-flex;align-items:center;gap:7px;padding:5px 14px;'+
          'background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);'+
          'border-radius:30px;font-size:11.5px;font-weight:600;color:var(--text-2);">'+
          '<span style="width:6px;height:6px;border-radius:50%;background:var(--ok);'+
            'box-shadow:0 0 5px var(--ok-glow);display:inline-block;"></span>'+
          'Sistema en línea'+
        '</div>'+
        (pagosHoy?'<div style="font-size:11.5px;color:var(--text-2);">✓ '+pagosHoy+' pago'+(pagosHoy!==1?'s':'')+' hoy</div>':'<div style="font-size:11.5px;color:var(--faint);">— 0 pagos registrados hoy</div>')+
      '</div>'+
    '</div>'+
  '</div>';

  /* ── STATS ── */
  var stats=[
    {icon:'📅',lbl:'Clases hoy',       val:clasesHoy.length, sub:clasesHoy.length?clasesHoy[0].inicio+' '+clasesHoy[0].nombre:'Sin clases hoy'},
    {icon:'👥',lbl:'Alumnos activos',  val:alumnosActivos,   sub:totalAlumnos!==alumnosActivos?(totalAlumnos-alumnosActivos)+' de baja':'Todos activos'},
    {icon:'💳',lbl:'Pendientes cobro', val:faltaCobrar.size, sub:faltaCobrar.size?'Este mes':'Al día ✓', warn:faltaCobrar.size>0},
    {icon:'€', lbl:'Ingresos del mes', val:eur(ingresosMes), sub:mes.replace('-','/'), gold:true},
  ];
  h+='<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px;margin-bottom:28px;">';
  stats.forEach(function(s){
    var vc=s.warn?'var(--warn)':s.gold?'var(--gold-2)':'var(--text)';
    h+=statCard(s.lbl,s.val,vc,s.icon,s.sub);
  });
  h+='</div>';

  /* ── CLASES DE HOY ── */
  h+='<div style="display:flex;align-items:center;gap:10px;margin-bottom:16px;">'+
    '<span style="width:3px;height:14px;border-radius:2px;flex:0 0 auto;'+
      'background:linear-gradient(var(--gold),var(--accent-deep));box-shadow:0 0 8px var(--gold-glow);"></span>'+
    '<span style="font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:2px;color:var(--muted);">Clases de hoy</span>'+
  '</div>';

  if(!clasesHoy.length){
    h+='<div style="text-align:center;padding:60px 24px;background:rgba(255,255,255,.02);'+
      'border:1px dashed rgba(255,215,0,.14);border-radius:var(--r-xl);">'+
      '<div style="font-size:40px;margin-bottom:14px;opacity:.4;">📅</div>'+
      '<div style="font-size:15px;font-weight:600;color:var(--muted);margin-bottom:6px;">Sin clases hoy</div>'+
      '<div style="font-size:13px;color:var(--faint);">Disfruta el día libre o revisa la sección de Alumnos.</div>'+
    '</div>';
  } else {
    h+='<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px;margin-bottom:28px;">';
    clasesHoy.forEach(function(c){
      var lista=usersOfClass(c.id);
      var ocupacionHtml='';
      if (c.aforo){
        var pct=Math.min(100,Math.round(lista.length/c.aforo*100));
        var pcol = pct>=100?'var(--warn)':pct>=75?'var(--amber)':'var(--ok)';
        ocupacionHtml=
          '<div style="margin:10px 0 12px;">'+
            '<div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:5px;">'+
              '<span style="font-size:10.5px;color:var(--muted);">👥 '+lista.length+' / '+c.aforo+' plazas</span>'+
              '<span style="font-size:11px;font-weight:700;color:'+pcol+';">'+pct+'%</span>'+
            '</div>'+
            '<div style="height:5px;border-radius:4px;background:rgba(255,255,255,.07);overflow:hidden;">'+
              '<div style="height:100%;width:'+pct+'%;border-radius:4px;background:'+pcol+';transition:width .5s ease-in-out;"></div>'+
            '</div>'+
          '</div>';
      } else {
        ocupacionHtml='<div style="font-size:11px;color:var(--muted);margin:8px 0 12px;">👥 '+lista.length+' alumno'+(lista.length!==1?'s':'')+' · sin cupo definido</div>';
      }
      h+='<div class="card">'+
        '<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:2px;">'+
          '<div>'+
            '<div style="font-size:16px;font-weight:700;margin-bottom:3px;">'+esc(c.nombre)+'</div>'+
            '<div style="color:var(--muted);font-size:12px;">'+esc(c.estilo)+(c.nivelNum?' · Nivel '+c.nivelNum:'')+'</div>'+
          '</div>'+
          '<div style="font-family:\'Sora\',sans-serif;font-size:14.5px;font-weight:700;color:var(--text-2);white-space:nowrap;">'+c.inicio+(c.fin?'–'+c.fin:'')+'</div>'+
        '</div>'+
        ocupacionHtml+
        '<button class="btn sec sm" style="width:100%;margin-bottom:12px;" onclick="abrirAsistencia(\''+c.id+'\')">📋 Pasar lista</button>'+
        '<div style="display:flex;flex-direction:column;gap:5px;">';
      lista.forEach(function(u){
        var pagado=!!db.payments.find(function(p){return p.userId===u.id&&p.mes===mes;});
        var asist=db.attendances.find(function(a){return a.classId===c.id&&a.userId===u.id&&a.fecha===today;});
        var mc2=asist?(asist.present?'var(--ok)':'var(--warn)'):'var(--border)';
        h+='<div style="display:flex;justify-content:space-between;align-items:center;padding:7px 10px;border-radius:8px;'+
          'background:'+(asist&&asist.present?'rgba(255,215,0,.05)':asist?'rgba(224,92,92,.05)':'rgba(255,255,255,.02)')+';'+
          'border:1px solid '+mc2+'33;">'+
          '<div style="display:flex;align-items:center;gap:8px;">'+
            '<span style="width:7px;height:7px;border-radius:50%;background:'+mc2+';flex:0 0 auto;"></span>'+
            '<span style="font-size:13px;font-weight:500;">'+esc(u.nombre)+'</span>'+
          '</div>'+
          (pagado?'<span class="badge ok" style="font-size:10.5px;">✓ Pagado</span>':'<button class="btn sm" style="padding:4px 10px;font-size:11px;" onclick="abrirPago(\''+u.id+'\')">Cobrar</button>')+
        '</div>';
      });
      h+='</div></div>';
    });
    h+='</div>';
  }

  /* ── COBROS PENDIENTES ── */
  if(faltaCobrar.size){
    h+='<div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;margin-top:8px;">'+
      '<span style="width:3px;height:14px;border-radius:2px;background:var(--warn);flex:0 0 auto;"></span>'+
      '<span style="font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:2px;color:var(--warn);">Cobros pendientes</span>'+
      '<span style="background:var(--warn-soft);border:1px solid rgba(224,92,92,.25);padding:2px 10px;border-radius:20px;font-size:10px;color:var(--warn);font-weight:700;">'+
        faltaCobrar.size+' pendiente'+(faltaCobrar.size!==1?'s':'')+
      '</span></div>';
    var rows='';
    faltaCobrar.forEach(function(u){
      rows+='<tr><td><strong>'+esc(u.nombre)+'</strong></td>'+
        '<td><span class="badge muted">'+(PLANES[u.plan]||u.plan||'—')+'</span></td>'+
        '<td><span class="badge warn">'+eur(precioUsuario(u))+'</span></td>'+
        '<td style="text-align:right;"><button class="btn sm" onclick="abrirPago(\''+u.id+'\')">Registrar pago</button></td></tr>';
    });
    h+='<div class="tbl-wrap"><table><thead><tr><th>Alumno</th><th>Plan</th><th>Importe</th><th style="text-align:right;">Acción</th></tr></thead><tbody>'+rows+'</tbody></table></div>';
  }

  /* ── ANALÍTICAS — rellena el espacio inferior con datos reales ── */
  h+='<div style="display:flex;align-items:center;gap:10px;margin:8px 0 16px;">'+
    '<span style="width:3px;height:14px;border-radius:2px;flex:0 0 auto;'+
      'background:linear-gradient(var(--gold),var(--accent-deep));box-shadow:0 0 8px var(--gold-glow);"></span>'+
    '<span style="font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:2px;color:var(--muted);">Analíticas</span>'+
  '</div>'+
  '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(340px,1fr));gap:18px;margin-bottom:8px;">'+
    '<div class="card" style="border-color:rgba(255,255,255,.08);">'+
      '<div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:18px;">'+
        '<div style="font-size:13px;font-weight:700;">Asistencia · últimos 7 días</div>'+
        '<div style="font-size:11px;color:var(--muted);">'+asistenciaSemana.reduce(function(s,d){return s+d.value;},0)+' check-ins</div>'+
      '</div>'+
      miniBarChart(asistenciaSemana,{unidad:''})+
    '</div>'+
    '<div class="card" style="border-color:rgba(255,255,255,.08);">'+
      '<div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:18px;">'+
        '<div style="font-size:13px;font-weight:700;">Ingresos · últimos 6 meses</div>'+
        '<div style="font-size:11px;color:var(--muted);">'+eur(ingresosMes)+' este mes</div>'+
      '</div>'+
      miniBarChart(ingresosMeses,{unidad:'€',esDinero:true})+
    '</div>'+
  '</div>';

  cont.innerHTML=h;
}

/* ── Mini gráfico de barras en SVG puro (sin librerías externas) ──
   items: [{label, value, hoy}]. opts.esDinero formatea el tooltip/valor en €. */
function miniBarChart(items, opts){
  opts=opts||{};
  var max=Math.max.apply(null,items.map(function(d){return d.value;}).concat([1]));
  var w=340, h=110, barGap=10, barW=(w-barGap*(items.length-1))/items.length;
  var bars='', labels='';
  items.forEach(function(d,i){
    var barH=Math.max(3, Math.round((d.value/max)*(h-24)));
    var x=i*(barW+barGap);
    var y=h-24-barH;
    var fill=d.hoy?'var(--gold)':'rgba(255,255,255,.16)';
    bars+='<rect x="'+x+'" y="'+y+'" width="'+barW+'" height="'+barH+'" rx="4" fill="'+fill+'">'+
      '<title>'+d.label+': '+(opts.esDinero?eur(d.value):d.value)+'</title></rect>';
    if (d.hoy) bars+='<text x="'+(x+barW/2)+'" y="'+(y-6)+'" text-anchor="middle" font-size="10" font-weight="700" fill="var(--gold-2)" font-family="Sora,sans-serif">'+(opts.esDinero?Math.round(d.value):d.value)+'</text>';
    labels+='<text x="'+(x+barW/2)+'" y="'+(h-6)+'" text-anchor="middle" font-size="10" fill="'+(d.hoy?'var(--text-2)':'var(--faint)')+'" font-family="Inter,sans-serif">'+d.label+'</text>';
  });
  return '<svg viewBox="0 0 '+w+' '+h+'" style="width:100%;height:auto;display:block;overflow:visible;">'+
    '<line x1="0" y1="'+(h-24)+'" x2="'+w+'" y2="'+(h-24)+'" stroke="rgba(255,255,255,.08)" stroke-width="1"/>'+
    bars+labels+
  '</svg>';
}

/* Fondo del dashboard gestionado dentro de navigateTo (ver arriba) */

function statCard(label,val,color,icon,sub){
  icon=icon||''; sub=sub||'';
  const iconSpan=icon?'<span style="font-size:14px;opacity:.7;">'+icon+'</span>':'';
  const subDiv=sub?'<div style="font-size:11px;color:var(--muted);margin-top:6px;">'+sub+'</div>':'';
  return '<div class="card stat glow" style="position:relative;overflow:hidden;">'+
    '<div style="position:absolute;top:-12px;right:-8px;font-size:42px;opacity:.07;pointer-events:none;line-height:1;">'+icon+'</div>'+
    '<div class="lbl" style="display:flex;align-items:center;gap:6px;margin-bottom:6px;">'+iconSpan+label+'</div>'+
    '<div class="val" style="color:'+color+';font-size:38px;line-height:1.1;">'+val+'</div>'+
    subDiv+
    '</div>';
}
function usersOfClass(classId){
  return (db.enrollments||[])
    .filter(e=>e.classId===classId&&e.status==='active')
    .map(e=>(db.users||[]).find(u=>u.id===e.userId))
    .filter(Boolean);
}

/* ── Avatar del admin en el Dashboard: gestión de foto de perfil propia ──
   Reutiliza el mismo campo fotoPerfil que ya usan los alumnos, pero se
   guarda con guardar()/PUT /api/db (el mecanismo genérico ya usado en toda
   la app), no con PUT /api/users/{id}, para no depender de validaciones
   de esquema específicas de rol que no conocemos del lado del servidor. */
function abrirGestorAvatarAdmin(){
  const u = (db.users||[]).find(x=>x.id===currentUser.sub);
  const fotoActual = u?.fotoPerfil || '';
  const overlay=document.createElement('div');
  overlay.className='modal-overlay open';
  overlay.id='modalAvatarAdmin';
  overlay.innerHTML=`
    <div class="modal-box" style="max-width:360px;width:100%;text-align:center;">
      <h3 class="modal-title">Foto de perfil</h3>
      <div id="avAdminPreview" style="width:92px;height:92px;border-radius:50%;margin:8px auto 20px;
        overflow:hidden;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.14);
        display:flex;align-items:center;justify-content:center;">
        ${fotoActual
          ? `<img src="${esc(fotoActual)}" style="width:100%;height:100%;object-fit:cover;">`
          : `<span style="font-size:28px;color:var(--text-2);font-weight:700;font-family:'Sora',sans-serif;">${iniciales(u?.nombre||currentUser.nombre)}</span>`}
      </div>
      <label class="btn sec sm" style="display:inline-flex;align-items:center;gap:6px;cursor:pointer;">
        📁 Elegir foto
        <input type="file" accept="image/*" style="display:none;" onchange="avAdminPreviewFoto(this)">
      </label>
      ${fotoActual?`<button class="btn sec sm" style="margin-left:8px;" onclick="avAdminQuitarFoto()">Quitar</button>`:''}
      <p style="font-size:11px;color:var(--faint);margin-top:14px;">JPG o PNG, máx. 2 MB.</p>
      <div style="display:flex;gap:8px;justify-content:center;margin-top:18px;">
        <button class="btn sec" onclick="cerrarModal('modalAvatarAdmin')">Cancelar</button>
        <button class="btn" onclick="avAdminGuardarFoto()">Guardar</button>
      </div>
    </div>`;
  playModal(); document.body.appendChild(overlay);
}
function avAdminPreviewFoto(input){
  const file=input.files[0]; if(!file) return;
  if(file.size>2*1024*1024){ showToast('Imagen debe ser < 2 MB','warn'); return; }
  const reader=new FileReader();
  reader.onload=e=>{
    window._avAdminFotoTemp = e.target.result;
    const p=$('avAdminPreview');
    if(p) p.innerHTML='<img src="'+e.target.result+'" style="width:100%;height:100%;object-fit:cover;">';
  };
  reader.readAsDataURL(file);
}
function avAdminQuitarFoto(){
  window._avAdminFotoTemp='';
  const p=$('avAdminPreview');
  if(p) p.innerHTML='<span style="font-size:28px;color:var(--text-2);font-weight:700;font-family:\'Sora\',sans-serif;">'+iniciales(currentUser.nombre)+'</span>';
}
async function avAdminGuardarFoto(){
  if (window._avAdminFotoTemp===undefined){ cerrarModal('modalAvatarAdmin'); return; }
  const u=(db.users||[]).find(x=>x.id===currentUser.sub);
  if(!u){ showToast('No se encontró tu usuario en la base de datos','warn'); return; }
  u.fotoPerfil = window._avAdminFotoTemp;
  try {
    guardar();
    delete window._avAdminFotoTemp;
    cerrarModal('modalAvatarAdmin');
    renderView('dashboard');
    showToast('Foto de perfil actualizada','ok');
    playSuccess(); flashSuccess();
  } catch(e){ showToast('Error al guardar: '+e.message,'warn'); }
}

/* ── Vista ALUMNOS ── */
function renderAlumnos(cont){
  cont.innerHTML=`
  <div class="section-head">
    <div class="h2">◍ Alumnos y clientes</div>
    <button class="btn" onclick="abrirModalAlumno()">+ Nuevo alumno</button>
  </div>
  <div class="toolbar">
    <input type="text" id="busqAlumno" placeholder="Buscar por nombre o tel…" style="max-width:220px;" oninput="filtrarAlumnos()">
    <select id="filtPlan" onchange="filtrarAlumnos()" style="max-width:190px;">
      <option value="">Todos los planes</option>
      <option value="suelta">Clase suelta · 12 €</option>
      <option value="35">1 clase/sem · 35 €</option>
      <option value="50">2 clases/sem · 50 €</option>
      <option value="bono">Bono 10 clases · 100 €</option>
      <option value="80">VIP / Full Pass · 80 €</option>
    </select>
    <select id="filtActivo" onchange="filtrarAlumnos()" style="max-width:160px;">
      <option value="">Activos e inactivos</option>
      <option value="1">Solo activos</option>
      <option value="0">Inactivos</option>
    </select>
    <select id="filtTipo" onchange="filtrarAlumnos()" style="max-width:170px;">
      <option value="">Todos</option>
      <option value="normal">Pago digital</option>
      <option value="cash">Efectivo / sin factura</option>
      <option value="guest">Invitados cortesía</option>
    </select>
    <span id="cntAlumnos" style="margin-left:auto;color:var(--muted);font-size:12px;"></span>
  </div>
  <div class="alumnos-layout">
    <div id="tablaAlumnos" class="alumnos-grid-wrap"></div>
    <div class="az-index" id="azIndex"></div>
  </div>`;
  filtrarAlumnos();
}

function filtrarAlumnos(){
  const q=(($('busqAlumno')||{}).value||'').toLowerCase();
  const fp=($('filtPlan')||{}).value||'';
  const fa=($('filtActivo')||{}).value??'';
  const ft=($('filtTipo')||{}).value||'';

  // Exclusión estricta: admins y teachers NO aparecen aquí
  const lista=(db.users||[]).filter(u=>{
    if(['admin','teacher'].includes(u.role)) return false;
    const matchQ = u.nombre.toLowerCase().includes(q) ||
                   (u.telefono||'').replace(/\s/g,'').includes(q.replace(/\s/g,''));
    const matchP = !fp || u.plan===fp;
    const matchA = fa==='' || (u.active?'1':'0')===fa;
    const matchT = !ft ||
      (ft==='cash'  && !!u.cashOnly) ||
      (ft==='guest' && !!u.guestCourtesy) ||
      (ft==='normal'&& !u.cashOnly && !u.guestCourtesy);
    return matchQ && matchP && matchA && matchT;
  }).sort((a,b)=>a.nombre.localeCompare(b.nombre));

  const cnt=$('cntAlumnos');
  if(cnt) cnt.textContent=`${lista.length} alumno${lista.length!==1?'s':''}`;
  const cont=$('tablaAlumnos'); if(!cont) return;
  if(!lista.length){ cont.innerHTML='<div class="vacio">Sin resultados.</div>'; return; }

  const DIAS_F=['Domingo','Lunes','Martes','Miércoles','Jueves','Viernes','Sábado'];
  const initials = n => (n||'').trim().split(/\s+/).slice(0,2).map(w=>w[0]).join('').toUpperCase();

  const grid=document.createElement('div'); grid.className='alumnos-grid';
  const letrasPresentes=new Set();
  let letraAnterior='';

  lista.forEach((u,idx)=>{
    let tipoBadges='';
    if(u.guestCourtesy) tipoBadges+='<span class="alumno-badge" title="Invitado de cortesía">♡ Cortesía</span>';
    if(u.cashOnly)      tipoBadges+='<span class="alumno-badge" title="Pago en efectivo">💵 Efectivo</span>';

    const factLabel={'email':'📧 Email','whatsapp':'💬 WhatsApp','none':'— Sin envío'}[u.facturaEnvio||'none'];
    const clasesAsig=(db.classes||[]).filter(c=>(u.assignedClasses||[]).includes(c.id));
    const clasesTxt = clasesAsig.length
      ? clasesAsig.map(c=>`${DIAS_F[c.dia]?.slice(0,3)||''} ${c.inicio} · ${esc(c.nombre)}`).join('<br>')
      : 'Sin clases asignadas';

    // Letra inicial para el índice A-Z: solo se marca la primera tarjeta de cada letra
    const letra=(u.nombre||'#').trim()[0]?.toUpperCase()||'#';
    const esNuevaLetra = letra!==letraAnterior;
    if (esNuevaLetra){ letrasPresentes.add(letra); letraAnterior=letra; }

    const card=document.createElement('div');
    card.className='alumno-card';
    card.style.animationDelay=(idx*0.03)+'s';
    if (esNuevaLetra) card.id='az_'+letra;
    card.innerHTML=`
      <div class="alumno-card-top">
        <div class="alumno-avatar">${u.fotoPerfil ? `<img src="${esc(u.fotoPerfil)}" alt="" loading="lazy">` : initials(u.nombre)}</div>
        <div style="flex:1;min-width:0;">
          <button class="alumno-name" onclick="verComoAlumno('${u.id}')">${esc(u.nombre)}</button>
          ${u.telefono
            ? `<div><a class="alumno-tel" href="https://wa.me/${(u.telefono||'').replace(/\D/g,'')}?text=${encodeURIComponent('Hola '+u.nombre+', te escribimos desde la Academia Malevo 💃')}" target="_blank">📱 ${esc(u.telefono)}</a></div>`
            : '<div style="font-size:12px;color:var(--faint);margin-top:2px;">Sin teléfono</div>'}
          <div class="alumno-badges">
            <span class="alumno-badge">${PLANES[u.plan]||'—'}</span>
            <span class="alumno-status${u.active?' active':''}"><span class="dot"></span>${u.active?'Activo':'Inactivo'}</span>
            ${tipoBadges}
          </div>
        </div>
      </div>
      <div class="alumno-actions">
        <button class="alumno-action" onclick="abrirModalAlumno('${u.id}')">✏ Editar</button>
        <button class="alumno-action" onclick="abrirPago('${u.id}')">+ Pago</button>
        <button class="alumno-action" onclick="archivarUsuario('${u.id}','${esc(u.nombre)}')" title="Archivar alumno (no elimina datos)">⬇ Archivar</button>
      </div>
      <button class="acc-toggle" onclick="this.classList.toggle('open');this.nextElementSibling.classList.toggle('open')" style="margin-top:12px;">
        <span class="chev">▾</span> Ver detalles
      </button>
      <div class="acc-body">
        <div class="alumno-acc-row"><span>Factura</span><span>${factLabel}</span></div>
        <div class="alumno-acc-row"><span>Nivel Bachata</span><span>${u.nivelBachata?'Nivel '+u.nivelBachata:'—'}</span></div>
        <div class="alumno-acc-row"><span>Nivel Salsa</span><span>${u.nivelSalsa?'Nivel '+u.nivelSalsa:'—'}</span></div>
        <div class="alumno-acc-row"><span>Clases asignadas</span><span>${clasesTxt}</span></div>
      </div>`;
    grid.appendChild(card);
  });
  cont.innerHTML=''; cont.appendChild(grid);

  // ── Índice alfabético lateral A-Z ──
  const az=$('azIndex');
  if (az){
    az.innerHTML='';
    'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').forEach(L=>{
      const disponible=letrasPresentes.has(L);
      const b=document.createElement('button');
      b.textContent=L;
      b.className=disponible?'has':'';
      b.disabled=!disponible;
      if (disponible) b.onclick=()=>{ $('az_'+L)?.scrollIntoView({behavior:'smooth',block:'start'}); };
      az.appendChild(b);
    });
  }
}


/* ── Modal unificado: Alta / Editar alumno (contacto + plan + niveles + clases) ── */
function abrirModalAlumno(id){
  const u   = id ? (db.users||[]).find(x=>x.id===id) : null;
  const plan = u?.plan||'35';
  const assigned = u?.assignedClasses||[];

  const DIAS_F = ['Domingo','Lunes','Martes','Miércoles','Jueves','Viernes','Sábado'];
  const allCls = (db.classes||[]).sort((a,b)=>{
    const da=a.dia===0?7:a.dia, db_=b.dia===0?7:b.dia;
    return da-db_||(a.inicio||'').localeCompare(b.inicio||'');
  });

  const tel      = u?.telefono||'';
  const telLimpio= tel.replace(/\D/g,'');
  const appUrl   = window.location.origin+'/portal.html';
  const msgWa    = encodeURIComponent('¡Hola '+(u?.nombre||'')+'! 🎵 Accede al Aula Virtual de la Academia Malevo: '+appUrl);
  const waLink   = telLimpio
    ? `<a href="https://wa.me/${telLimpio}?text=${msgWa}" target="_blank" class="btn ok"
         style="display:inline-flex;align-items:center;gap:7px;font-size:12.5px;padding:8px 14px;text-decoration:none;">
         💬 Enviar enlace por WhatsApp</a>`
    : '<span style="color:var(--muted);font-size:12px;">Guarda el teléfono primero para enviar el enlace.</span>';

  // Grid de clases
  const clasesHtml = allCls.length ? allCls.map(c=>{
    const chk = assigned.includes(c.id);
    return `<label id="alClaseLbl_${c.id}" style="display:flex;align-items:center;gap:10px;padding:9px 12px;
      border-radius:8px;cursor:pointer;transition:all .15s;
      background:${chk?'rgba(255,215,0,.09)':'rgba(255,255,255,.03)'};
      border:1px solid ${chk?'rgba(255,215,0,.28)':'rgba(255,255,255,.07)'};"
      onmouseover="if(!this.querySelector('input').checked)this.style.borderColor='rgba(255,215,0,.2)'"
      onmouseout="if(!this.querySelector('input').checked)this.style.borderColor='rgba(255,255,255,.07)'">
      <input type="checkbox" value="${c.id}" style="width:auto;accent-color:var(--gold);"
        ${chk?'checked':''} onchange="alToggleClase(this,'${c.id}')">
      <div style="width:3px;height:32px;border-radius:2px;background:${chk?'#FFD700':'var(--card-border)'};flex:0 0 auto;"></div>
      <div style="flex:1;min-width:0;">
        <div style="font-size:13px;font-weight:600;">${esc(c.nombre)}</div>
        <div style="font-size:11px;color:var(--muted);">${DIAS_F[c.dia]||''} ${c.inicio}${c.fin?'–'+c.fin:''} · ${esc(c.estilo)}${c.nivelNum?' · N'+c.nivelNum:''}</div>
      </div>
    </label>`;
  }).join('')
  : '<p style="color:var(--muted);font-size:13px;">Sin clases creadas aún.</p>';

  const overlay=document.createElement('div');
  overlay.className='modal-overlay open';
  overlay.id='modalAlumno';
  overlay.style.cssText='align-items:flex-start;padding:32px 16px;';

  overlay.innerHTML=`
  <div class="modal-box" style="max-width:640px;width:100%;">
  <h3 class="modal-title">${u?'✏️ Editar alumno':'➕ Nuevo alumno'}</h3>

  <!-- Datos de contacto -->
  <div class="sect-lbl">Datos de contacto</div>
  <label class="label-field">Nombre completo *</label>
  <input type="text" id="alNombre" value="${esc(u?.nombre||'')}" placeholder="Nombre y apellidos" style="font-size:15px;font-weight:600;">
  <div class="g2" style="margin-top:12px;">
    <div>
      <label class="label-field">📱 Teléfono (WhatsApp)</label>
      <input type="tel" id="alTel" value="${esc(tel)}" placeholder="600 000 000"
        style="font-size:15px;border-color:rgba(255,215,0,.35);border-width:2px;"
        oninput="actualizarEnlaceWa()">
    </div>
    <div>
      <label class="label-field">Email</label>
      <input type="email" id="alEmail" value="${esc(u?.email||'')}" placeholder="correo@…">
    </div>
  </div>

  <!-- Plan y niveles -->
  <div class="sect-lbl" style="margin-top:18px;">Plan y niveles de baile</div>
  <div class="g2">
    <div>
      <label class="label-field">Plan / Tarifa</label>
      <select id="alPlan" style="font-size:13.5px;font-weight:600;">
        ${[['suelta','Clase suelta · 12€'],['35','1 clase/sem · 35€/mes'],['50','2 clases/sem · 50€/mes'],
           ['bono','Bono 10 clases · 100€'],['80','VIP / Full Pass · 80€/mes [AULA VIRTUAL]']]
          .map(([k,l])=>`<option value="${k}"${plan===k?' selected':''}>${l}</option>`).join('')}
      </select>
      <small style="color:var(--muted);font-size:11px;margin-top:4px;display:block;">Solo VIP incluye acceso al Aula Virtual.</small>
    </div>
    <div>
      <label class="label-field">Rol de baile</label>
      <select id="alRol">
        <option value="leader"${(u?.rol||'indiferente')==='leader'?' selected':''}>🕺 Leader</option>
        <option value="follower"${u?.rol==='follower'?' selected':''}>💃 Follower</option>
        <option value="indiferente"${(!u?.rol||u?.rol==='indiferente')?' selected':''}>🔄 Indiferente</option>
      </select>
    </div>
  </div>
  <div class="g2" style="margin-top:10px;">
    <div>
      <label class="label-field">Nivel Bachata</label>
      <select id="alNivelBachata">
        <option value="">Sin nivel</option>
        ${[1,2,3,4].map(n=>`<option value="${n}"${u?.nivelBachata==n?' selected':''}>${nivelLabel(n)}</option>`).join('')}
      </select>
    </div>
    <div>
      <label class="label-field">Nivel Salsa</label>
      <select id="alNivelSalsa">
        <option value="">Sin nivel</option>
        ${[1,2,3,4].map(n=>`<option value="${n}"${u?.nivelSalsa==n?' selected':''}>${nivelLabel(n)}</option>`).join('')}
      </select>
    </div>
  </div>

  <!-- Clases asignadas -->
  <div class="sect-lbl" style="margin-top:18px;">
    📅 Clases asignadas
    <span id="alClaseCnt" style="margin-left:8px;color:var(--gold-2);font-weight:700;font-size:11px;">
      ${assigned.length?`(${assigned.length} asignada${assigned.length!==1?'s':''})`:''}</span>
  </div>
  <p style="color:var(--muted);font-size:12px;margin-bottom:10px;">Marca los días y clases a los que asiste este alumno.</p>
  <div id="alClasesGrid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(270px,1fr));
    gap:7px;max-height:260px;overflow-y:auto;padding:2px 2px 2px 0;">
    ${clasesHtml}
  </div>

  <!-- Facturación y accesos -->
  <div class="sect-lbl" style="margin-top:18px;">Facturación y accesos</div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px;">
    <label class="chk-card">
      <input type="checkbox" id="alCashOnly" style="width:auto;accent-color:var(--gold);"${u?.cashOnly?' checked':''}>
      <div><div style="font-size:13px;font-weight:600;">💵 Pago en efectivo</div>
      <div style="font-size:11.5px;color:var(--muted);">Factura generada igualmente</div></div>
    </label>
    <label class="chk-card">
      <input type="checkbox" id="alCourtesy" style="width:auto;accent-color:var(--amber);"${u?.guestCourtesy?' checked':''}
        onchange="actualizarContadorInvitados()">
      <div><div style="font-size:13px;font-weight:600;color:var(--amber);">♡ Invitado de cortesía</div>
      <div style="font-size:11.5px;color:var(--muted);">Sin cobro<span id="contInvitados" style="display:none;color:var(--warn);font-weight:700;margin-left:4px;"></span></div></div>
    </label>
  </div>
  <label class="chk-card" style="margin-bottom:10px;">
    <input type="checkbox" id="alPortalAccess" style="width:auto;accent-color:var(--ok);"
      ${(u?.portalAccess||PORTAL_PLANS.includes(u?.plan||''))?' checked':''}>
    <div><div style="font-size:13px;font-weight:600;color:var(--ok);">🎓 Acceso al Aula Virtual</div>
    <div style="font-size:11.5px;color:var(--muted);">Activo aunque el plan no lo incluya</div></div>
  </label>
  <div style="display:flex;gap:8px;margin-bottom:10px;">
    ${[{v:'email',l:'📧 Email'},{v:'whatsapp',l:'💬 WhatsApp'},{v:'none',l:'— Sin envío'}].map(o=>
      `<label class="chk-card" style="flex:1;">
        <input type="radio" name="alFactura" value="${o.v}" style="width:auto;accent-color:var(--gold);"
          ${(u?.facturaEnvio||'none')===o.v?' checked':''}>
        ${o.l}
      </label>`).join('')}
  </div>
  <label style="display:flex;align-items:center;gap:10px;">
    <input type="checkbox" id="alActivo" style="width:auto;accent-color:var(--ok);"${u?.active!==false?' checked':''}>
    <span style="font-size:13.5px;color:var(--text-2);">Usuario activo</span>
  </label>

  <!-- Enlace WhatsApp (solo en edición) -->
  ${u?`<div style="margin-top:16px;padding:13px 15px;background:rgba(37,211,102,.07);
    border:1px solid rgba(37,211,102,.22);border-radius:var(--r);">
    <div style="font-size:11.5px;color:var(--muted);margin-bottom:8px;">🔗 Enlace de acceso al Aula Virtual</div>
    <div id="waLinkBox">${waLink}</div>
  </div>`:'<div style="margin-top:12px;padding:11px 13px;background:rgba(255,255,255,.03);border:1px dashed rgba(255,215,0,.18);border-radius:var(--r);color:var(--muted);font-size:12px;">💬 Tras guardar podrás enviarle el enlace de acceso por WhatsApp.</div>'}

  <div style="display:flex;gap:10px;margin-top:22px;justify-content:flex-end;">
    <button class="btn sec" onclick="cerrarModal('modalAlumno')">Cancelar</button>
    <button class="btn" onclick="guardarAlumno('${u?.id||''}')">
      ${u?'Guardar cambios':'Dar de alta'}
    </button>
  </div>
  </div>`;

  playModal(); document.body.appendChild(overlay);
  actualizarContadorInvitados();
  alActualizarContadorClases();
}

/* ── Toggle visual clase en modal de edición ── */
function alToggleClase(input, classId){
  const lbl = document.getElementById('alClaseLbl_'+classId);
  if(!lbl) return;
  lbl.style.background   = input.checked ? 'rgba(255,215,0,.09)' : 'rgba(255,255,255,.03)';
  lbl.style.borderColor  = input.checked ? 'rgba(255,215,0,.28)' : 'rgba(255,255,255,.07)';
  alActualizarContadorClases();
}
function alActualizarContadorClases(){
  const n = document.querySelectorAll('#alClasesGrid input:checked').length;
  const el = $('alClaseCnt');
  if(el) el.textContent = n ? `(${n} asignada${n!==1?'s':''})` : '';
}

/* ── Archivar alumno (en lugar de eliminar) ── */
async function archivarUsuario(id, nombre){
  if(!confirm(`¿Archivar a ${nombre}?\n\nSe marcará como Inactivo. Su historial de pagos e inscripciones se conserva intacto. Puedes reactivarlo en cualquier momento desde Editar.`)) return;
  try {
    const u = (db.users||[]).find(x=>x.id===id);
    if(!u) return;
    await apiJSON('PUT',`/api/users/${id}`,{
      nombre:u.nombre, telefono:u.telefono||'', email:u.email||'',
      role:'student', plan:u.plan, active:false,
      cashOnly:u.cashOnly||false, guestCourtesy:u.guestCourtesy||false,
      portalAccess:u.portalAccess||false, facturaEnvio:u.facturaEnvio||'none'
    });
    await cargarDB(); renderView('alumnos');
    showToast(`${nombre} archivado. Sus datos se conservan intactos.`,'ok');
  } catch(e){ showToast('Error: '+e.message,'warn'); }
}

/* ── Contador de invitados de cortesía (máx 5) ── */
function actualizarContadorInvitados(){
  const chk = $('alCourtesy');
  const span = $('contInvitados');
  if(!chk || !span) return;
  const totalActual = (db.users||[]).filter(u=>u.guestCourtesy).length;
  if(chk.checked){
    const limite = 5;
    if(totalActual >= limite){
      span.textContent = ' (límite '+limite+' alcanzado)';
      span.style.display='inline';
      chk.checked = false;
      showToast('Límite de '+limite+' invitados de cortesía alcanzado.','warn');
    } else {
      span.textContent = ' ('+totalActual+'/'+limite+')';
      span.style.display='inline';
    }
  } else {
    span.style.display='none';
  }
}

/* ── Actualizar enlace WhatsApp en tiempo real al escribir el teléfono ── */
function actualizarEnlaceWa(){
  const box = $('waLinkBox');
  if(!box) return; // solo existe en modo edición
  const tel = ($('alTel')?.value||'').replace(/\D/g,'');
  const nombre = $('alNombre')?.value||'';
  const appUrl = window.location.origin + '/portal.html';
  const msgWa = encodeURIComponent(
    '¡Hola ' + nombre + '! 🎵 Te hemos registrado en el Aula Virtual de la Academia Malevo. ' +
    'Accede aquí: ' + appUrl
  );
  if(tel){
    box.innerHTML =
      '<a href="https://wa.me/'+tel+'?text='+msgWa+'" target="_blank" class="btn ok" '+
      'style="display:inline-flex;align-items:center;gap:7px;font-size:13px;padding:9px 16px;text-decoration:none;">'+
      '💬 Enviar enlace de acceso por WhatsApp</a>';
  } else {
    box.innerHTML = '<span style="color:var(--muted);font-size:12px;">Introduce el teléfono para activar el enlace.</span>';
  }
}

async function guardarAlumno(id){
  const nombre=$('alNombre').value.trim();
  const tel=$('alTel').value.trim();
  if(!nombre){ showToast('El nombre es obligatorio.','warn'); return; }

  const facturaEnvio=document.querySelector('input[name="alFactura"]:checked')?.value||'none';
  const esInvitado = $('alCourtesy').checked;
  const plan = $('alPlan').value;
  const rol  = $('alRol')?.value || 'indiferente';
  const nivelBachata = $('alNivelBachata')?.value || null;
  const nivelSalsa   = $('alNivelSalsa')?.value   || null;

  // Recoger clases marcadas en el modal fusionado
  const classIds = [...document.querySelectorAll('#alClasesGrid input[type=checkbox]:checked')]
    .map(i => i.value);

  if(esInvitado && !id){
    const totalInvitados = (db.users||[]).filter(u=>u.guestCourtesy).length;
    if(totalInvitados >= 5){ showToast('Límite de 5 invitados de cortesía alcanzado.','warn'); return; }
  }

  const data={
    nombre, telefono:tel, email:$('alEmail').value.trim(),
    role:'student', plan, active:$('alActivo').checked,
    cashOnly:$('alCashOnly').checked, guestCourtesy:esInvitado,
    portalAccess:$('alPortalAccess').checked, facturaEnvio,
  };

  try {
    let userId = id;
    if(id){
      await apiJSON('PUT',`/api/users/${id}`,data);
    } else {
      const res = await apiJSON('POST','/api/users',data);
      userId = res.user?.id || res.id;
    }
    // Guardar clases + niveles + rol si tenemos userId
    if(userId && classIds !== undefined){
      await apiJSON('PUT',`/api/users/${userId}/classes`,{
        classIds, plan, nivelBachata:nivelBachata||null,
        nivelSalsa:nivelSalsa||null, rol
      });
      // Inscripción automática VIP
      if(plan==='80'){
        if(nivelBachata) await apiJSON('POST','/api/enrollments',{userId,disciplina:'Bachata',nivelMax:parseInt(nivelBachata)}).catch(()=>{});
        if(nivelSalsa)   await apiJSON('POST','/api/enrollments',{userId,disciplina:'Salsa',  nivelMax:parseInt(nivelSalsa)}).catch(()=>{});
      }
    }
    cerrarModal('modalAlumno');
    await cargarDB();
    renderView('alumnos');
    confirmSave(id ? 'Alumno actualizado' : 'Alumno dado de alta');
  } catch(e){ showToast('Error: '+e.message,'warn'); }
}

async function borrarUsuario(id){
  const u=(db.users||[]).find(x=>x.id===id);
  if(!confirm(`¿Eliminar a "${u?.nombre}"? Se borrarán también sus inscripciones y pagos.`)) return;
  db.users=db.users.filter(x=>x.id!==id);
  db.enrollments=(db.enrollments||[]).filter(e=>e.userId!==id);
  db.payments=(db.payments||[]).filter(p=>p.userId!==id);
  db.attendances=(db.attendances||[]).filter(a=>a.userId!==id);
  db._rev++;
  guardar(); renderView('alumnos');
}

/* ── Modal Configuración completa del alumno (admin) ── */
function abrirConfigAlumno(userId){
  const u=(db.users||[]).find(x=>x.id===userId);
  if(!u) return;
  const DIAS_F=['Domingo','Lunes','Martes','Miércoles','Jueves','Viernes','Sábado'];
  const allCls=(db.classes||[]).sort((a,b)=>{
    const da=a.dia===0?7:a.dia, db_=b.dia===0?7:b.dia;
    return da-db_||(a.inicio||'').localeCompare(b.inicio||'');
  });
  const assigned=u.assignedClasses||[];

  // Construir opciones de plan
  const planOpts=[
    {k:'suelta',l:'Clase suelta · 12 EUR'},
    {k:'35',    l:'1 clase/sem · 35 EUR'},
    {k:'50',    l:'2 clases/sem · 50 EUR'},
    {k:'bono',  l:'Bono 10 clases · 100 EUR'},
    {k:'80',    l:'VIP / Full Pass · 80 EUR [AULA VIRTUAL]'}
  ].map(p=>'<option value="'+p.k+'"'+(u.plan===p.k?' selected':'')+'>'+p.l+'</option>').join('');

  // Opciones de rol
  const rolOpts=
    '<option value="leader"'+(u.rol==='leader'?' selected':'')+'>Leader</option>'+
    '<option value="follower"'+(u.rol==='follower'?' selected':'')+'>Follower</option>'+
    '<option value="indiferente"'+((u.rol||'indiferente')==='indiferente'?' selected':'')+'>Indiferente</option>';

  // Opciones de nivel
  const nivelOpts='<option value="">Sin nivel</option>'+
    NIVELES.map(n=>'<option value="'+n+'"'+(u.nivelBachata==n?' selected':'')+'>Nivel '+n+'</option>').join('');
  const nivelOptsS='<option value="">Sin nivel</option>'+
    NIVELES.map(n=>'<option value="'+n+'"'+(u.nivelSalsa==n?' selected':'')+'>Nivel '+n+'</option>').join('');

  // Grid de clases
  let clasesHtml='';
  if(!allCls.length){
    clasesHtml='<p style="color:var(--muted);font-size:13px;">Sin clases. Créalas en Clases.</p>';
  } else {
    allCls.forEach(function(c){
      const chk=assigned.includes(c.id);
      const bg   = chk ? 'rgba(255,215,0,.09)' : 'rgba(255,255,255,.03)';
      const bord = chk ? 'rgba(255,215,0,.28)' : 'rgba(255,255,255,.08)';
      const dia  = DIAS_F[c.dia]||'';
      const hora = c.inicio+(c.fin?'–'+c.fin:'');
      const disc = esc(c.estilo)+(c.nivelNum?' · Nivel '+c.nivelNum:'');
      clasesHtml+=
        '<label id="caClaseLbl_'+c.id+'" class="ca-clase-lbl" data-chk="'+chk+'" '+
          'style="display:flex;align-items:center;gap:12px;padding:10px 14px;'+
          'border-radius:var(--r-sm);cursor:pointer;'+
          'background:'+bg+';border:1px solid '+bord+';">'+
          '<input type="checkbox" value="'+c.id+'" style="width:auto;accent-color:var(--gold);"'+
            (chk?' checked':'')+' onchange="toggleCaClase(this,\''+c.id+'\')">'+
          '<div style="width:4px;height:36px;border-radius:2px;background:'+(chk?'#FFD700':'var(--card-border)')+';flex:0 0 auto;"></div>'+
          '<div style="flex:1;">'+
            '<div style="font-size:13.5px;font-weight:600;">'+esc(c.nombre)+'</div>'+
            '<div style="font-size:11.5px;color:var(--muted);">'+dia+' '+hora+' · '+disc+'</div>'+
          '</div>'+
          (c.aforo?'<span style="font-size:11px;color:var(--muted);">👥 '+c.aforo+'</span>':'')+
        '</label>';
    });
  }

  const overlay=document.createElement('div');
  overlay.className='modal-overlay open';
  overlay.id='modalConfigAlumno';
  overlay.innerHTML=
    '<div class="modal-box" style="max-width:640px;">'+
    '<h3 class="modal-title">⚙ Configurar alumno</h3>'+
    '<div style="display:flex;align-items:center;gap:14px;margin-bottom:22px;padding:14px 16px;'+
      'background:rgba(255,215,0,.07);border:1px solid rgba(255,215,0,.18);border-radius:var(--r);">'+
      '<div style="width:42px;height:42px;border-radius:12px;flex:0 0 auto;'+
        'background:linear-gradient(135deg,rgba(255,215,0,.3),rgba(138,112,0,.2));'+
        'display:flex;align-items:center;justify-content:center;font-size:18px;">👤</div>'+
      '<div>'+
        '<div style="font-weight:700;font-size:15px;">'+esc(u.nombre)+'</div>'+
        '<div style="font-size:12px;color:var(--muted);">@'+esc(u.username)+' · '+(ROLES_LABEL[u.role]||u.role)+'</div>'+
      '</div>'+
    '</div>'+
    '<div class="sect-lbl">Tarifa y niveles de baile</div>'+
    '<div class="g2" style="margin-bottom:18px;">'+
      '<div><label class="label-field">Plan / Tarifa</label>'+
        '<select id="caPlan">'+planOpts+'</select></div>'+
      '<div><label class="label-field">Rol de baile</label>'+
        '<select id="caRol">'+rolOpts+'</select></div>'+
    '</div>'+
    '<div class="g2" style="margin-bottom:20px;">'+
      '<div><label class="label-field">Nivel Bachata</label>'+
        '<select id="caNivelBachata">'+nivelOpts+'</select></div>'+
      '<div><label class="label-field">Nivel Salsa</label>'+
        '<select id="caNivelSalsa">'+nivelOptsS+'</select></div>'+
    '</div>'+
    '<div class="sect-lbl">Días y clases asignados</div>'+
    '<p style="color:var(--muted);font-size:12.5px;margin-bottom:12px;">'+
      'Marca las clases a las que asistirá. Aparecerán en su agenda.</p>'+
    '<div id="caClasesGrid" style="display:flex;flex-direction:column;gap:8px;'+
      'max-height:280px;overflow-y:auto;padding-right:4px;">'+
      clasesHtml+
    '</div>'+
    '<div style="display:flex;gap:10px;margin-top:22px;justify-content:flex-end;">'+
      '<button class="btn sec" onclick="cerrarModal(\'modalConfigAlumno\')">Cancelar</button>'+
      '<button class="btn ok" onclick="guardarConfigAlumno(\''+userId+'\')">✓ Guardar</button>'+
    '</div>'+
    '</div>';

  playModal(); document.body.appendChild(overlay);
}
function toggleCaClase(inp, classId){
  const lbl=document.getElementById('caClaseLbl_'+classId);
  if(!lbl) return;
  lbl.style.background=inp.checked?'rgba(255,215,0,.09)':'rgba(255,255,255,.03)';
  lbl.style.borderColor=inp.checked?'rgba(255,215,0,.28)':'rgba(255,255,255,.08)';
}

async function guardarConfigAlumno(userId){
  const classIds=[...document.querySelectorAll('#caClasesGrid input[type=checkbox]:checked')].map(i=>i.value);
  const plan=$('caPlan').value;
  const rol=$('caRol').value;
  const nivelBachata=$('caNivelBachata').value||null;
  const nivelSalsa=$('caNivelSalsa').value||null;
  try {
    // 1. Guardar clases asignadas + plan + rol + niveles via ruta dedicada
    await apiJSON('PUT',`/api/users/${userId}/classes`,{classIds,plan,nivelBachata,nivelSalsa,rol});
    // 2. También actualizar en el objeto local para reflejo inmediato
    const u=(db.users||[]).find(x=>x.id===userId);
    if(u){
      u.assignedClasses=classIds; u.plan=plan; u.rol=rol;
      u.nivelBachata=nivelBachata; u.nivelSalsa=nivelSalsa;
    }
    // 3. Si VIP, inscribir automáticamente en los niveles correspondientes
    if(plan==='80'){
      if(nivelBachata) await apiJSON('POST','/api/enrollments',{userId,disciplina:'Bachata',nivelMax:parseInt(nivelBachata)}).catch(()=>{});
      if(nivelSalsa)   await apiJSON('POST','/api/enrollments',{userId,disciplina:'Salsa',  nivelMax:parseInt(nivelSalsa)}).catch(()=>{});
    }
    cerrarModal('modalConfigAlumno');
    await cargarDB(); renderView('alumnos');
    confirmSave('Alumno configurado correctamente');
  } catch(e){ showToast('Error al guardar: '+e.message,'warn'); }
}

/* ══════════════════════════════════════════════
   VER COMO ALUMNO — Vista previa del portal
   desde la perspectiva de un alumno específico
══════════════════════════════════════════════ */
function verComoAlumno(userId){
  const u = (db.users||[]).find(x => x.id === userId);
  if (!u) return;

  // Clases asignadas al alumno
  const clasesDelAlumno = (u.assignedClasses||[])
    .map(cid => (db.classes||[]).find(c => c.id === cid))
    .filter(Boolean)
    .sort((a,b) => { const da = a.dia===0?7:a.dia, db_ = b.dia===0?7:b.dia; return da-db_||(a.inicio||'').localeCompare(b.inicio||''); });

  const DIAS_FULL_L  = ['Domingo','Lunes','Martes','Miércoles','Jueves','Viernes','Sábado'];
  const DIAS_CORTO_L = ['Dom','Lun','Mar','Mié','Jue','Vie','Sáb'];
  const tieneVideos  = u.plan === '80' || u.portalAccess === true;
  const planNombre   = {'suelta':'Clase suelta','35':'1 clase/semana','50':'2 clases/semana','80':'VIP · Full Pass','bono':'Bono 10 clases'}[u.plan] || '—';

  // Hora y saludo
  const hora = new Date().getHours();
  const saludo = hora < 13 ? '¡Buenos días' : hora < 20 ? '¡Buenas tardes' : '¡Buenas noches';
  const primerNombre = (u.nombre||'').split(' ')[0] || 'alumno';
  const hoyNum  = new Date().getDay();
  const manaNum = (hoyNum + 1) % 7;
  const clasesHoy  = clasesDelAlumno.filter(c => (c.dia ?? 0) === hoyNum);
  const clasesMana = clasesDelAlumno.filter(c => (c.dia ?? 0) === manaNum);

  function chipClase(c){
    return `<div style="background:var(--card-bg);border:1px solid var(--card-border);
      border-radius:8px;padding:9px 12px;margin-bottom:7px;">
      <div style="font-size:11px;color:var(--text-2);font-weight:700;">${c.inicio||''}${c.fin?' – '+c.fin:''}</div>
      <div style="font-size:13px;font-weight:600;margin-top:2px;">${esc(c.nombre)}</div>
      <div style="font-size:11px;color:var(--muted);">${esc(c.estilo)}${c.nivelNum?' · Nivel '+c.nivelNum:''}</div>
    </div>`;
  }
  function bloqueHorario(lista, etiqueta){
    if(!lista.length) return `<div style="color:var(--muted);font-size:12px;text-align:center;padding:14px 0;
      border:1px dashed rgba(255,215,0,.1);border-radius:8px;">Sin clases ${etiqueta.toLowerCase()}</div>`;
    return lista.map(chipClase).join('');
  }

  // Generar tabla de agenda semanal compacta
  function tablaAgenda(){
    if(!clasesDelAlumno.length) return `<div style="color:var(--muted);font-size:13px;text-align:center;padding:24px;">
      Sin clases asignadas todavía.</div>`;
    const porDia = {};
    clasesDelAlumno.forEach(c => { const d = c.dia??0; if(!porDia[d]) porDia[d]=[]; porDia[d].push(c); });
    const diasCon = [1,2,3,4,5,6,0].filter(d => porDia[d]);
    return diasCon.map(d => {
      const cls = porDia[d].sort((a,b) => (a.inicio||'').localeCompare(b.inicio||''));
      return `<div style="margin-bottom:10px;">
        <div style="font-size:10px;text-transform:uppercase;letter-spacing:1.5px;color:var(--muted);
          font-weight:600;margin-bottom:6px;padding-bottom:4px;border-bottom:1px solid rgba(255,215,0,.1);">
          ${DIAS_FULL_L[d]}
        </div>
        ${cls.map(chipClase).join('')}
      </div>`;
    }).join('');
  }

  // Sección de vídeos: previsualización (sin reproducción real)
  function seccionVideos(){
    if(!tieneVideos) return `<div style="text-align:center;padding:28px;background:rgba(255,255,255,.02);
      border:1px dashed rgba(255,215,0,.15);border-radius:12px;">
      <div style="font-size:32px;margin-bottom:10px;">🔒</div>
      <div style="font-size:13.5px;font-weight:600;color:var(--gold-2);margin-bottom:6px;">Aula Virtual no activa</div>
      <div style="font-size:12.5px;color:var(--muted);">Este alumno no tiene plan VIP.<br>
        Cambia su plan a <strong>VIP · Full Pass</strong> para activar el acceso.</div>
    </div>`;
    const videos = (db.videos||[]);
    if(!videos.length) return `<div style="color:var(--muted);font-size:13px;text-align:center;padding:20px;">
      Sin vídeos cargados en el sistema todavía.</div>`;
    const disciplinas = [...new Set(videos.map(v => v.disciplina))];
    return disciplinas.map(disc => {
      const porNivel = {};
      videos.filter(v => v.disciplina === disc).forEach(v => {
        if(!porNivel[v.nivel]) porNivel[v.nivel] = [];
        porNivel[v.nivel].push(v);
      });
      return `<div style="margin-bottom:18px;">
        <div style="font-size:11px;text-transform:uppercase;letter-spacing:1.5px;color:var(--muted);
          font-weight:700;margin-bottom:10px;">${esc(disc)}</div>
        ${Object.entries(porNivel).sort(([a],[b]) => +a - +b).map(([nivel, vids]) => `
          <div style="margin-bottom:12px;">
            <div style="font-size:11.5px;color:var(--gold-2);font-weight:600;margin-bottom:6px;display:flex;align-items:center;gap:6px;">
              <span style="background:rgba(255,215,0,.15);border:1px solid rgba(255,215,0,.25);
                padding:2px 10px;border-radius:20px;">${nivelLabel(+nivel)}</span>
              <span style="color:var(--muted);font-weight:400;">${vids.length} clase${vids.length!==1?'s':''}</span>
            </div>
            <div style="display:flex;flex-direction:column;gap:5px;">
              ${vids.sort((a,b)=>a.orden-b.orden).map(v => `
                <div style="display:flex;align-items:center;gap:10px;padding:9px 12px;
                  background:rgba(255,255,255,.03);border:1px solid rgba(255,215,0,.1);border-radius:8px;">
                  <div style="width:26px;height:26px;border-radius:7px;
                    background:rgba(255,215,0,.12);border:1px solid rgba(255,215,0,.22);
                    display:flex;align-items:center;justify-content:center;
                    font-size:10px;font-weight:700;color:var(--gold-2);flex:0 0 auto;">${v.orden||'▶'}</div>
                  <div style="flex:1;font-size:13px;font-weight:500;">${esc(v.titulo)}</div>
                  <span style="font-size:10.5px;color:var(--muted);">▶ Vídeo</span>
                </div>`).join('')}
            </div>
          </div>`).join('')}
      </div>`;
    }).join('');
  }

  // Construir el modal completo
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay open';
  overlay.id = 'modalVerAlumno';
  overlay.style.cssText = 'align-items:flex-start;padding:0;overflow-y:auto;';

  overlay.innerHTML = `
  <div style="width:100%;min-height:100%;display:flex;flex-direction:column;">

    <!-- ── Barra de contexto admin (siempre visible) ── -->
    <div id="barraContextoAdmin" style="
      position:sticky;top:0;z-index:10;
      background:rgba(12,10,2,.97);
      backdrop-filter:blur(24px);
      border-bottom:2px solid rgba(255,215,0,.35);
      padding:12px 28px;
      display:flex;align-items:center;justify-content:space-between;gap:16px;
      box-shadow:0 4px 20px rgba(0,0,0,.7);">
      <div style="display:flex;align-items:center;gap:14px;">
        <div style="background:linear-gradient(135deg,rgba(255,215,0,.25),rgba(138,112,0,.15));
          border:1px solid rgba(255,215,0,.4);border-radius:10px;
          padding:6px 14px;font-size:11.5px;font-weight:700;color:var(--gold-2);
          letter-spacing:.5px;white-space:nowrap;">
          👁 VISTA PREVIA · ADMIN
        </div>
        <div>
          <div style="font-size:14px;font-weight:700;">${esc(u.nombre)}</div>
          <div style="font-size:11px;color:var(--muted);">@${esc(u.username)} · Plan: ${esc(planNombre)}</div>
        </div>
      </div>
      <div style="display:flex;gap:8px;align-items:center;">
        <button onclick="cerrarModal('modalVerAlumno');abrirConfigAlumno('${u.id}')"
          style="background:linear-gradient(135deg,rgba(255,215,0,.18),rgba(138,112,0,.12));
            border:1px solid rgba(255,215,0,.32);color:var(--gold-2);
            padding:7px 16px;border-radius:8px;cursor:pointer;font-size:12.5px;
            font-family:inherit;font-weight:600;transition:all .2s;white-space:nowrap;">
          ⚙ Editar alumno
        </button>
        <button onclick="cerrarModal('modalVerAlumno')"
          style="background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.12);
            color:var(--muted);padding:7px 16px;border-radius:8px;cursor:pointer;
            font-size:12.5px;font-family:inherit;transition:all .2s;">
          × Cerrar
        </button>
      </div>
    </div>

    <!-- ── Contenido del portal simulado ── -->
    <div style="flex:1;padding:32px 28px;max-width:1060px;margin:0 auto;width:100%;">

      <!-- Hero bienvenida (como lo ve el alumno) -->
      <div style="
        background:linear-gradient(135deg,rgba(255,215,0,.1),rgba(138,112,0,.07) 60%,rgba(255,255,255,.02));
        border:1px solid rgba(255,215,0,.22);border-radius:22px;
        padding:32px 36px;margin-bottom:24px;position:relative;overflow:hidden;">
        <div style="position:absolute;top:-50px;right:-50px;width:180px;height:180px;border-radius:50%;
          background:radial-gradient(circle,rgba(255,215,0,.12),transparent 70%);pointer-events:none;"></div>
        <h2 style="font-family:'Sora',sans-serif;font-size:22px;font-weight:700;
          color:var(--gold-light);letter-spacing:-.3px;margin-bottom:6px;">
          ${saludo}, ${esc(primerNombre)}! 👋</h2>
        <p style="color:var(--text-2);font-size:13.5px;line-height:1.6;">
          Bienvenido a tu espacio en la Academia Malevo.<br>
          Aquí tienes todo lo que necesitas para tu práctica.</p>
        <div style="display:inline-flex;align-items:center;gap:8px;margin-top:14px;
          padding:5px 16px;border-radius:30px;font-size:11.5px;font-weight:600;
          background:rgba(255,215,0,.14);border:1px solid rgba(255,215,0,.28);color:var(--gold-2);">
          🎓 ${esc(planNombre)}
          ${tieneVideos ? '&nbsp;·&nbsp;<span style="color:var(--ok);">✓ Aula Virtual activa</span>' : ''}
        </div>
      </div>

      <!-- Stats -->
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:12px;margin-bottom:24px;">
        ${[
          {n: clasesDelAlumno.length, l:'Clases activas'},
          {n: u.nivelBachata ? 'Nivel '+u.nivelBachata : '—', l:'Bachata', col: u.nivelBachata?'var(--gold-2)':''},
          {n: u.nivelSalsa   ? 'Nivel '+u.nivelSalsa   : '—', l:'Salsa',   col: u.nivelSalsa  ?'var(--gold-2)':''},
          {n: u.rol==='leader'?'🕺':u.rol==='follower'?'💃':'🔄', l: u.rol==='leader'?'Leader':u.rol==='follower'?'Follower':'Indistinto'}
        ].map(s=>`
          <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,215,0,.14);
            border-radius:14px;padding:16px;text-align:center;">
            <div style="font-family:'Sora',sans-serif;font-size:24px;font-weight:800;
              ${s.col?'color:'+s.col+';':''}">${s.n}</div>
            <div style="font-size:10.5px;color:var(--muted);text-transform:uppercase;
              letter-spacing:1px;margin-top:4px;">${s.l}</div>
          </div>`).join('')}
      </div>

      <!-- Grid principal: Agenda + Vídeos -->
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:24px;">

        <!-- Clases hoy / mañana -->
        <div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,215,0,.14);
          border-radius:18px;padding:22px;">
          <div style="font-size:10px;text-transform:uppercase;letter-spacing:2px;color:var(--muted);
            font-weight:700;margin-bottom:14px;display:flex;align-items:center;gap:6px;">
            <span style="width:3px;height:12px;border-radius:2px;background:linear-gradient(var(--gold),var(--accent-deep));
              box-shadow:0 0 6px var(--gold-glow);display:inline-block;"></span>
            Esta semana
          </div>
          <div style="margin-bottom:14px;">
            <div style="font-size:10px;text-transform:uppercase;letter-spacing:1.5px;
              color:${clasesHoy.length?'var(--gold-2)':'var(--muted)'};font-weight:600;margin-bottom:7px;">
              ${clasesHoy.length?'● ':''} HOY — ${DIAS_FULL_L[hoyNum]}
            </div>
            ${bloqueHorario(clasesHoy, 'Hoy')}
          </div>
          <div>
            <div style="font-size:10px;text-transform:uppercase;letter-spacing:1.5px;
              color:var(--muted);font-weight:600;margin-bottom:7px;">
              MAÑANA — ${DIAS_FULL_L[manaNum]}
            </div>
            ${bloqueHorario(clasesMana, 'Mañana')}
          </div>
        </div>

        <!-- Aula virtual -->
        <div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,215,0,.14);
          border-radius:18px;padding:22px;overflow-y:auto;max-height:420px;">
          <div style="font-size:10px;text-transform:uppercase;letter-spacing:2px;color:var(--muted);
            font-weight:700;margin-bottom:14px;display:flex;align-items:center;gap:6px;">
            <span style="width:3px;height:12px;border-radius:2px;background:linear-gradient(var(--gold),var(--accent-deep));
              box-shadow:0 0 6px var(--gold-glow);display:inline-block;"></span>
            Aula virtual · Mis vídeos
          </div>
          ${seccionVideos()}
        </div>
      </div>

      <!-- Agenda semanal completa -->
      <div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,215,0,.14);
        border-radius:18px;padding:22px;margin-bottom:24px;">
        <div style="font-size:10px;text-transform:uppercase;letter-spacing:2px;color:var(--muted);
          font-weight:700;margin-bottom:16px;display:flex;align-items:center;gap:6px;">
          <span style="width:3px;height:12px;border-radius:2px;background:linear-gradient(var(--gold),var(--accent-deep));
            box-shadow:0 0 6px var(--gold-glow);display:inline-block;"></span>
          Agenda semanal completa
        </div>
        ${tablaAgenda()}
      </div>

      <!-- Panel de edición rápida (exclusivo para admin) -->
      <div style="background:rgba(255,215,0,.05);border:1px solid rgba(255,215,0,.2);
        border-radius:18px;padding:22px;margin-bottom:12px;">
        <div style="font-size:10px;text-transform:uppercase;letter-spacing:2px;color:var(--gold-2);
          font-weight:700;margin-bottom:16px;display:flex;align-items:center;justify-content:space-between;">
          <span style="display:flex;align-items:center;gap:6px;">
            <span style="width:3px;height:12px;border-radius:2px;background:var(--gold);
              box-shadow:0 0 6px var(--gold-glow);display:inline-block;"></span>
            Edición rápida · Solo visible para el administrador
          </span>
          <span style="font-size:10px;color:var(--muted);font-weight:400;letter-spacing:.3px;">Los cambios aplican inmediatamente</span>
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;margin-bottom:16px;">
          <div>
            <label style="font-size:10.5px;color:var(--muted);display:block;margin-bottom:5px;text-transform:uppercase;letter-spacing:.7px;">Plan / Tarifa</label>
            <select id="vca_plan_${u.id}" style="font-size:13px;font-weight:600;">
              ${[['suelta','Clase suelta'],['35','1 clase/sem · 35€'],['50','2 clases/sem · 50€'],['bono','Bono 10 · 100€'],['80','VIP Full Pass · 80€']]
                .map(([k,l])=>`<option value="${k}"${u.plan===k?' selected':''}>${l}</option>`).join('')}
            </select>
          </div>
          <div>
            <label style="font-size:10.5px;color:var(--muted);display:block;margin-bottom:5px;text-transform:uppercase;letter-spacing:.7px;">Nivel Bachata</label>
            <select id="vca_bach_${u.id}">
              <option value="">Sin nivel</option>
              ${[1,2,3,4].map(n=>`<option value="${n}"${u.nivelBachata==n?' selected':''}>${nivelLabel(n)}</option>`).join('')}
            </select>
          </div>
          <div>
            <label style="font-size:10.5px;color:var(--muted);display:block;margin-bottom:5px;text-transform:uppercase;letter-spacing:.7px;">Nivel Salsa</label>
            <select id="vca_sals_${u.id}">
              <option value="">Sin nivel</option>
              ${[1,2,3,4].map(n=>`<option value="${n}"${u.nivelSalsa==n?' selected':''}>${nivelLabel(n)}</option>`).join('')}
            </select>
          </div>
          <div>
            <label style="font-size:10.5px;color:var(--muted);display:block;margin-bottom:5px;text-transform:uppercase;letter-spacing:.7px;">Rol de baile</label>
            <select id="vca_rol_${u.id}">
              <option value="leader"${u.rol==='leader'?' selected':''}>Leader</option>
              <option value="follower"${u.rol==='follower'?' selected':''}>Follower</option>
              <option value="indiferente"${(!u.rol||u.rol==='indiferente')?' selected':''}>Indiferente</option>
            </select>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:14px;flex-wrap:wrap;">
          <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
            <input type="checkbox" id="vca_portal_${u.id}" style="width:auto;accent-color:var(--ok);"
              ${(u.portalAccess||u.plan==='80')?' checked':''}>
            <span style="font-size:13px;color:var(--text-2);">🎓 Acceso Aula Virtual</span>
          </label>
          <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
            <input type="checkbox" id="vca_activo_${u.id}" style="width:auto;accent-color:var(--ok);"
              ${u.active!==false?' checked':''}>
            <span style="font-size:13px;color:var(--text-2);">✓ Usuario activo</span>
          </label>
          <button onclick="guardarEdicionRapida('${u.id}')"
            style="margin-left:auto;background:linear-gradient(135deg,var(--gold),var(--accent-deep));
              color:#0a0a0a;border:none;padding:9px 22px;border-radius:9px;cursor:pointer;
              font-size:13px;font-weight:700;font-family:inherit;transition:all .2s;
              box-shadow:0 4px 14px rgba(0,0,0,.4);">
            ✓ Guardar cambios
          </button>
        </div>
      </div>

    </div>
  </div>`;

  playModal(); document.body.appendChild(overlay);
}

/* ── Guardar cambios desde la vista previa del alumno ── */
async function guardarEdicionRapida(userId){
  const u = (db.users||[]).find(x => x.id === userId);
  if (!u) return;
  const plan         = document.getElementById('vca_plan_'+userId)?.value || u.plan;
  const nivelBachata = document.getElementById('vca_bach_'+userId)?.value || null;
  const nivelSalsa   = document.getElementById('vca_sals_'+userId)?.value || null;
  const rol          = document.getElementById('vca_rol_'+userId)?.value  || 'indiferente';
  const portalAccess = document.getElementById('vca_portal_'+userId)?.checked ?? false;
  const active       = document.getElementById('vca_activo_'+userId)?.checked ?? true;

  try {
    // Guardar plan, niveles y rol vía ruta de clases (mantiene clases asignadas)
    await apiJSON('PUT', `/api/users/${userId}/classes`, {
      classIds: u.assignedClasses || [],
      plan, nivelBachata: nivelBachata||null, nivelSalsa: nivelSalsa||null, rol
    });
    // Guardar estado activo y acceso portal
    await apiJSON('PUT', `/api/users/${userId}`, {
      nombre: u.nombre, telefono: u.telefono||'', email: u.email||'',
      role: 'student', plan, active, portalAccess,
      cashOnly: u.cashOnly||false, guestCourtesy: u.guestCourtesy||false,
      facturaEnvio: u.facturaEnvio||'none'
    });
    // Reflejar en objeto local
    Object.assign(u, { plan, nivelBachata: nivelBachata||null, nivelSalsa: nivelSalsa||null, rol, active, portalAccess });
    await cargarDB();
    cerrarModal('modalVerAlumno');
    renderView('alumnos');
    confirmSave('Cambios guardados correctamente');
  } catch(e){ showToast('Error al guardar: '+e.message,'warn'); }
}

function abrirModalInscripcion(userId){
  const u=(db.users||[]).find(x=>x.id===userId);
  const discOpts=DISCIPLINAS_VIDEO.map(function(d){
    return '<option value="'+d+'">'+d+'</option>';
  }).join('');
  const nivelOpts=NIVELES.map(function(n){
    return '<option value="'+n+'">'+nivelLabel(n)+'</option>';
  }).join('');
  const overlay=document.createElement('div');
  overlay.className='modal-overlay open';
  overlay.id='modalInscrip';
  overlay.innerHTML=
    '<div class="modal-box">'+
    '<h3 class="modal-title">Inscribir a '+esc(u&&u.nombre||'')+'</h3>'+
    '<p style="color:var(--muted);font-size:13px;margin-bottom:18px;">'+
      'Se desbloquearán los niveles 1 hasta el nivel seleccionado.</p>'+
    '<label class="label-field">Disciplina (con vídeo)</label>'+
    '<select id="inscDisc">'+discOpts+'</select>'+
    '<label class="label-field">Nivel máximo a desbloquear</label>'+
    '<select id="inscNivel">'+nivelOpts+'</select>'+
    '<p style="color:var(--gold-2);font-size:12px;margin-top:10px;">'+
      '⚡ Inscripciones acumulativas automáticas.</p>'+
    '<div style="display:flex;gap:10px;margin-top:22px;justify-content:flex-end;">'+
      '<button class="btn sec" onclick="cerrarModal(&quot;modalInscrip&quot;)">Cancelar</button>'+
      '<button class="btn" onclick="guardarInscripcion(&quot;'+userId+'&quot;)">Inscribir</button>'+
    '</div>'+
    '</div>';
  playModal(); document.body.appendChild(overlay);
}

async function guardarInscripcion(userId){
  const disciplina=$('inscDisc').value;
  const nivelMax=parseInt($('inscNivel').value);
  try {
    await apiJSON('POST','/api/enrollments',{userId,disciplina,nivelMax});
    cerrarModal('modalInscrip');
    await cargarDB(); renderView('alumnos');
    confirmSave(`Acceso desbloqueado: ${disciplina} niveles 1–${nivelMax}`);
  } catch(e){ alert('Error: '+e.message); }
}

/* ── Vista CLASES ── */
function renderClases(cont){
  const isAdmin = currentUser.role==='admin';
  const totalClases = (db.classes||[]).length;
  cont.innerHTML=`<div class="section-head">
    <div>
      <div class="h2" style="margin-bottom:4px;">▦ Clases</div>
      <div style="font-size:12.5px;color:var(--muted);">Calendario semanal · ${totalClases} clase${totalClases!==1?'s':''}</div>
    </div>
    ${isAdmin?'<button class="btn" style="background:var(--card-bg);border:1px solid var(--card-border);color:var(--gold);box-shadow:none;" onclick="abrirModalClase()">+ Nueva clase</button>':''}
  </div>
  <div id="calendarioSemanal" class="cal-grid-admin"></div>`;
  renderCalendario();
}

function renderCalendario(){
  const cal=$('calendarioSemanal');
  if (!cal) return;
  const diasOrden=[1,2,3,4,5,6]; // domingo cerrado — no se muestra en el calendario
  const hoyNum=new Date().getDay();
  let html='';
  diasOrden.forEach(function(d){
    const clasesDia=(db.classes||[]).filter(c=>c.dia===d).sort((a,b)=>(a.inicio||'').localeCompare(b.inicio||''));
    const esHoy = d===hoyNum;
    let chips='';
    clasesDia.forEach(function(c){
      const n=usersOfClass(c.id).length;
      const aforo=c.aforo||0;
      const pct = aforo ? Math.min(100,Math.round(n/aforo*100)) : 0;
      chips+=
        '<div class="cal-card" onclick="abrirAsistencia(\''+c.id+'\')">'+
          '<button class="cal-card-edit" onclick="event.stopPropagation();abrirModalClase(\''+c.id+'\')" title="Editar clase">✎</button>'+
          '<div class="cal-card-time">'+c.inicio+(c.fin?'–'+c.fin:'')+'</div>'+
          '<div class="cal-card-name">'+esc(c.nombre)+'</div>'+
          '<div class="cal-card-disc">'+esc(c.estilo)+(c.nivelNum?' · N'+c.nivelNum:'')+'</div>'+
          '<div class="cal-card-meta">'+
            '<span class="cal-card-count">👥 '+n+'/'+(aforo||'—')+'</span>'+
            '<span class="cal-card-pct">'+pct+'%</span>'+
          '</div>'+
          '<div class="cal-card-bar"><div class="cal-card-bar-fill" style="width:'+pct+'%;"></div></div>'+
        '</div>';
    });
    if(!chips) chips='<div class="cal-empty">Sin clases</div>';
    html+=
      '<div class="cal-col'+(esHoy?' is-today':'')+'">'+
        '<div class="cal-col-label">'+DIAS[d]+(esHoy?' <span class="cal-col-dot"></span>':'')+'</div>'+
        '<div class="cal-col-body">'+chips+'</div>'+
      '</div>';
  });
  cal.innerHTML=html;
}

function abrirModalClase(id){
  const c=id?(db.classes||[]).find(x=>x.id===id):null;
  const discOpts=TODAS_DISCIPLINAS.map(function(d){
    return '<option value="'+d+'"'+(((c&&c.estilo)||'Salsa')===d?' selected':'')+'>'+d+'</option>';
  }).join('');
  const nivelOpts='<option value="">Sin nivel específico</option>'+
    NIVELES.map(function(n){
      return '<option value="'+n+'"'+((c&&c.nivelNum==n)?' selected':'')+'>'+n+'</option>';
    }).join('');
  const diaOpts=DIAS_FULL.map(function(d,i){
    return '<option value="'+i+'"'+(((c&&c.dia!=null?c.dia:1))==i?' selected':'')+'>'+d+'</option>';
  }).join('');

  const overlay=document.createElement('div');
  overlay.className='modal-overlay open';
  overlay.id='modalClase';
  overlay.innerHTML=
    '<div class="modal-box">'+
    '<h3 class="modal-title">'+(c?'Editar clase':'Nueva clase')+'</h3>'+
    '<label class="label-field">Nombre *</label>'+
    '<input type="text" id="clNombre" value="'+esc(c&&c.nombre||'')+'" placeholder="Ej: Bachata Intermedio">'+
    '<div class="g2">'+
      '<div><label class="label-field">Disciplina</label>'+
        '<select id="clEstilo">'+discOpts+'</select></div>'+
      '<div><label class="label-field">Nivel (si aplica)</label>'+
        '<select id="clNivel">'+nivelOpts+'</select></div>'+
    '</div>'+
    '<div class="g2">'+
      '<div><label class="label-field">Día de la semana</label>'+
        '<select id="clDia">'+diaOpts+'</select></div>'+
      '<div><label class="label-field">Aforo máximo</label>'+
        '<input type="number" id="clAforo" value="'+(c&&c.aforo||'')+'" placeholder="Opcional" min="1"></div>'+
    '</div>'+
    '<div class="g2">'+
      '<div><label class="label-field">Hora inicio</label>'+
        '<input type="time" id="clInicio" value="'+(c&&c.inicio||'19:00')+'"></div>'+
      '<div><label class="label-field">Hora fin</label>'+
        '<input type="time" id="clFin" value="'+(c&&c.fin||'20:00')+'"></div>'+
    '</div>'+
    '<label style="display:flex;align-items:center;gap:10px;margin-top:14px;">'+
      '<input type="checkbox" id="clHasVideo" style="width:auto;"'+(c&&c.hasVideo?' checked':'')+'>'+
      '<span style="font-size:13.5px;color:var(--text-2);">Clase con vídeo (portal alumnos)</span>'+
    '</label>'+
    '<div style="display:flex;gap:10px;margin-top:24px;justify-content:flex-end;">'+
      (c?'<button class="btn warn sm" onclick="borrarClase(&quot;'+c.id+'&quot;)">Eliminar</button>':'')+
      '<button class="btn sec" onclick="cerrarModal(&quot;modalClase&quot;)">Cancelar</button>'+
      '<button class="btn" onclick="guardarClase(&quot;'+(c&&c.id||'')+'&quot;)">Guardar</button>'+
    '</div>'+
    '</div>';
  playModal(); document.body.appendChild(overlay);
}

function guardarClase(id){
  const nombre=$('clNombre').value.trim();
  if (!nombre){alert('El nombre es obligatorio.');return;}
  const data={
    nombre, estilo:$('clEstilo').value,
    nivelNum:$('clNivel').value?parseInt($('clNivel').value):null,
    dia:parseInt($('clDia').value), inicio:$('clInicio').value,
    fin:$('clFin').value, aforo:$('clAforo').value?parseInt($('clAforo').value):null,
    hasVideo:$('clHasVideo').checked
  };
  if (id){
    const idx=(db.classes||[]).findIndex(c=>c.id===id);
    if (idx!==-1) Object.assign(db.classes[idx],data);
  } else {
    db.classes=(db.classes||[]);
    db.classes.push({id:uuid(),...data});
  }
  guardar(); cerrarModal('modalClase'); renderView('clases'); confirmSave('Clase guardada');
}
function borrarClase(id){
  if (!confirm('¿Eliminar esta clase?')) return;
  db.classes=(db.classes||[]).filter(c=>c.id!==id);
  db.enrollments=(db.enrollments||[]).filter(e=>e.classId!==id);
  guardar(); cerrarModal('modalClase'); renderView('clases');
}

/* ── Asistencia modal ── */
function abrirAsistencia(classId){
  const c=(db.classes||[]).find(x=>x.id===classId);
  const today=hoy();
  const lista=usersOfClass(classId);

  let rowsHtml='';
  lista.forEach(function(u){
    const a=(db.attendances||[]).find(x=>x.classId===classId&&x.userId===u.id&&x.fecha===today);
    const chk=a?.present?'checked':'';
    rowsHtml+=
      '<div style="display:flex;align-items:center;justify-content:space-between;'+
        'padding:10px 0;border-top:1px solid rgba(255,255,255,.07);">'+
        '<span>'+esc(u.nombre)+'</span>'+
        '<label style="position:relative;display:inline-block;width:46px;height:26px;margin:0;">'+
          '<input type="checkbox" data-uid="'+u.id+'" '+chk+' style="opacity:0;width:0;height:0;">'+
          '<span class="asist-toggle" style="position:absolute;inset:0;border-radius:30px;cursor:pointer;'+
            'background:'+(a?.present?'var(--ok-soft)':'rgba(255,255,255,.06)')+';'+
            'border:1px solid '+(a?.present?'var(--ok)':'rgba(255,255,255,.12)')+';transition:.25s;"'+
            ' onclick="var i=this.previousElementSibling;i.click();'+
              'this.style.background=i.checked?\'var(--ok-soft)\':\' rgba(255,255,255,.06)\';'+
              'this.style.borderColor=i.checked?\'var(--ok)\':\' rgba(255,255,255,.12)\';'+
              'this.firstElementChild.style.transform=i.checked?\'translateX(20px)\':\'\';'+
              'this.firstElementChild.style.background=i.checked?\'var(--ok)\':\' var(--muted)\';">'+
            '<span style="position:absolute;height:18px;width:18px;left:3px;top:3px;'+
              'background:'+(a?.present?'var(--ok)':'var(--muted)')+';border-radius:50%;transition:.25s;"></span>'+
          '</span>'+
        '</label>'+
      '</div>';
  });
  if(!rowsHtml) rowsHtml='<div class="vacio" style="padding:20px;">Sin alumnos inscritos.</div>';

  const overlay=document.createElement('div');
  overlay.className='modal-overlay open';
  overlay.id='modalAsist';
  overlay.innerHTML=
    '<div class="modal-box">'+
    '<h3 class="modal-title">📋 Lista · '+esc(c?.nombre||'')+'</h3>'+
    '<p style="color:var(--muted);font-size:12.5px;margin-bottom:18px;margin-top:-10px;">'+today+'</p>'+
    '<div>'+rowsHtml+'</div>'+
    '<div style="display:flex;gap:10px;margin-top:22px;justify-content:flex-end;">'+
      '<button class="btn sec" onclick="cerrarModal(\'modalAsist\')">Cancelar</button>'+
      '<button class="btn ok" onclick="guardarAsistencia(\''+classId+'\',\''+today+'\')">Guardar lista</button>'+
    '</div>'+
    '</div>';
  playModal(); document.body.appendChild(overlay);
}

async function guardarAsistencia(classId,fecha){
  const checks=document.querySelectorAll('#modalAsist input[data-uid]');
  for (const inp of checks){
    await apiJSON('POST','/api/attendances',{classId,userId:inp.dataset.uid,fecha,present:inp.checked});
  }
  cerrarModal('modalAsist');
  await cargarDB(); renderView(activeView);
  confirmSave('Lista de asistencia guardada');
}

/* ── Vista PAGOS ── */
function renderPagos(cont){
  const mes=mesActual();
  cont.innerHTML=`<div class="section-head">
    <div class="h2">◆ Pagos</div>
    <div style="display:flex;gap:8px;">
      <button class="btn sec" onclick="abrirFacturaSimplificada()" title="Factura exprés para cobro puntual sin datos de cliente">⚡ Factura simplificada</button>
      <button class="btn" onclick="abrirPago()">+ Registrar pago</button>
    </div>
  </div>
  <div style="display:flex;gap:10px;margin-bottom:18px;flex-wrap:wrap;align-items:center;">
    <input type="month" id="filtroPagoMes" value="${mes}" onchange="filtrarPagos()" style="max-width:160px;">
    <input type="text" id="busqPago" placeholder="Buscar alumno…" style="max-width:200px;" oninput="filtrarPagos()">
    <div style="margin-left:auto;color:var(--muted);font-size:12px;" id="resumenPagos"></div>
  </div>
  <div id="tablaPagos"></div>
  <div class="h2" style="margin-top:28px;">! Pendientes del mes</div>
  <div class="toolbar">
    <input type="month" id="pendMes" value="${mes}" onchange="renderPendientes()" style="max-width:160px;">
  </div>
  <div id="tablaPendientes"></div>`;
  filtrarPagos(); renderPendientes();
}

function filtrarPagos(){
  const fm=($('filtroPagoMes')||{}).value||'';
  const q=(($('busqPago')||{}).value||'').toLowerCase();
  const lista=(db.payments||[]).filter(p=>
    (!fm||p.mes===fm)&&nombreUsuario(p.userId).toLowerCase().includes(q)
  ).sort((a,b)=> (a.numeroTicket||0) - (b.numeroTicket||0));
  const cont=$('tablaPagos');
  if (!cont) return;
  if (!lista.length){ cont.innerHTML='<div class="vacio">Sin pagos con estos filtros.</div>'; return; }
  let total=0;
  const wrap=document.createElement('div');
  wrap.className='tbl-wrap';
  let h=`<table><thead><tr>
    <th>Ticket</th><th>Mes</th><th>Alumno</th>
    <th>Total</th><th>IVA</th><th>Malevo</th>
    <th>Método</th><th></th>
  </tr></thead><tbody>`;
  lista.forEach(p=>{
    const n=numPagoDeUsuario(p.userId,p.mes,p.id);
    const r=calcularReparto(p.importe||0,n);
    total+=r.importe;
    const numT = p.numeroTicket ? 'T-'+String(p.numeroTicket).padStart(5,'0') : '—';
    const u    = (db.users||[]).find(x=>x.id===p.userId);
    const tel  = (u?.telefono||'').replace(/\D/g,'');
    // Mensaje WhatsApp con enlace directo al PDF
    const pdfUrl = `${location.origin}/api/factura/${p.id}/pdf`;
    const importeStr = (Math.round(r.importe*100)/100).toLocaleString('es-ES',{minimumFractionDigits:2});
    const waMsg = encodeURIComponent(
      `Hola ${u?.nombre||''}! 👋\nTe enviamos tu factura:\n📄 Factura: ${numT}\n💶 Importe: ${importeStr} €\n📅 Mes: ${p.mes||''}\n\n🔗 Descarga tu PDF aquí:\n${pdfUrl}\n\nGracias por bailar con nosotros 💃🕺`
    );
    const waBtn = tel
      ? `<a href="https://wa.me/${tel}?text=${waMsg}" target="_blank"
           class="btn sm ok" title="Enviar confirmación por WhatsApp"
           style="text-decoration:none;background:linear-gradient(135deg,#25d366,#128c7e);
             box-shadow:0 2px 8px rgba(37,211,102,.30);">💬</a>`
      : `<span class="btn sm sec" style="opacity:.3;cursor:not-allowed;" title="Sin teléfono registrado">💬</span>`;

    h+=`<tr>
      <td><b style="color:var(--accent);">${numT}</b></td>
      <td>${p.mes||'—'}</td>
      <td>${p.simplificada
        ?'<span class="badge muted" title="Factura simplificada">⚡ '+esc(p.notas||'Anónimo')+'</span>'
        :esc(nombreUsuario(p.userId))}</td>
      <td><b>${eur(r.importe)}</b></td>
      <td style="color:var(--warn);">${eur(r.iva)}</td>
      <td style="color:var(--ok);">${eur(r.malevo)}</td>
      <td><span class="badge muted">${esc(p.metodo||'')}</span></td>
      <td><div style="display:flex;gap:5px;align-items:center;">
        <button class="btn sm ok" title="Ver / Imprimir PDF"
          onclick="${p.simplificada
            ?"generarTicketSimplificado('"+p.id+"','"+esc(p.notas||'Cobro puntual').replace(/'/g,"\\'")+"')"
            :"generarTicket('"+p.id+"')"}">🧾</button>
        ${waBtn}
        <button class="btn sm sec" onclick="editarPago('${p.id}')">Editar</button>
        <button class="btn sm warn" onclick="borrarPago('${p.id}')">×</button>
      </div></td>
    </tr>`;
  });
  wrap.innerHTML=h+'</tbody></table>';
  cont.innerHTML='';
  cont.appendChild(wrap);
  const res=$('resumenPagos');
  if (res) res.textContent=`${lista.length} pagos · ${eur(total)} total`;
}

function renderPendientes(){
  const mes=($('pendMes')||{}).value||mesActual();
  const pagados=new Set((db.payments||[]).filter(p=>p.mes===mes).map(p=>p.userId));
  const pend=(db.users||[]).filter(u=>u.active&&u.role==='student'&&!u.guestCourtesy&&!pagados.has(u.id));
  const cont=$('tablaPendientes');
  if (!cont) return;
  if (!pend.length){ cont.innerHTML='<div class="vacio" style="color:var(--ok);">✓ Todos los alumnos han pagado este mes.</div>'; return; }
  const wrap=document.createElement('div');
  wrap.className='tbl-wrap';
  let h=`<table><thead><tr><th>Alumno</th><th>Plan</th><th>Importe</th><th></th></tr></thead><tbody>`;
  pend.forEach(u=>{
    h+=`<tr>
      <td><strong>${esc(u.nombre)}</strong></td>
      <td><span class="badge muted">${PLANES[u.plan]||'—'}</span></td>
      <td><span class="badge warn">Pendiente · ${eur(precioUsuario(u))}</span></td>
      <td><button class="btn sm" onclick="abrirPago('${u.id}')">Registrar pago</button></td>
    </tr>`;
  });
  wrap.innerHTML=h+'</tbody></table>';
  cont.innerHTML='';
  cont.appendChild(wrap);
}

function abrirPago(userId,pagoId){
  const p=pagoId?(db.payments||[]).find(x=>x.id===pagoId):null;
  const alumnos=(db.users||[]).filter(u=>u.role==='student'||u.role==='guest').sort((a,b)=>a.nombre.localeCompare(b.nombre));
  const html=`<div class="modal-overlay open" id="modalPago">
  <div class="modal-box">
    <h3 class="modal-title">${p?'Editar pago':'Registrar pago'}</h3>
    <label class="label-field">Alumno *</label>
    <select id="pgAlumno" onchange="autoImporteTarifa();calcDesglose()">
      ${alumnos.map(function(u){return '<option value="'+u.id+'"'+((p&&p.userId||userId)===u.id?' selected':'')+'>'+esc(u.nombre)+'</option>';}).join('')}
    </select>
    <div class="g2">
      <div><label class="label-field">Mes del pago *</label>
        <input type="month" id="pgMes" value="${p?.mes||mesActual()}" onchange="calcDesglose()"></div>
      <div><label class="label-field">Fecha de cobro</label>
        <input type="date" id="pgFecha" value="${p?.fechaPago||hoy()}"></div>
    </div>
    <div class="g2">
      <div>
        <label class="label-field">Importe (€) *</label>
        <div style="position:relative;">
          <input type="number" id="pgImporte" value="${p?.importe||''}" step="0.01" oninput="calcDesglose()"
            style="padding-right:70px;">
          <span id="pgPlanTag" style="position:absolute;right:10px;top:50%;transform:translateY(-50%);
            font-size:10px;font-weight:600;color:var(--muted);pointer-events:none;"></span>
        </div>
      </div>
      <div><label class="label-field">Método</label>
        <select id="pgMetodo">
          ${['Efectivo','Bizum','Transferencia','Tarjeta'].map(function(m){return '<option'+((p&&p.metodo||'Efectivo')===m?' selected':'')+'>'+m+'</option>';}).join('')}
        </select></div>
    </div>
    <label class="label-field">Notas</label>
    <textarea id="pgNotas" rows="2">${esc(p?.notas||'')}</textarea>
    <div id="pgDesglose" style="background:var(--surface-2);border:1px solid var(--border-2);
      border-radius:12px;padding:14px;margin-top:14px;font-size:13px;"></div>
    <div style="display:flex;gap:10px;margin-top:22px;justify-content:flex-end;">
      <button class="btn sec" onclick="cerrarModal(&quot;modalPago&quot;)">Cancelar</button>
      <button class="btn" onclick="guardarPago('${p?.id||''}')">Guardar</button>
    </div>
  </div></div>`;
  document.body.insertAdjacentHTML('beforeend',html);
  // Al abrir para nuevo pago: autocompletar importe según tarifa del alumno
  if(!p) autoImporteTarifa();
  calcDesglose();
}

// Autocompleta el importe con la tarifa del plan del alumno seleccionado
function autoImporteTarifa(){
  const uid  = $('pgAlumno')?.value;
  const imp  = $('pgImporte');
  const tag  = $('pgPlanTag');
  if(!uid || !imp) return;
  const u     = (db.users||[]).find(x=>x.id===uid);
  const plan  = u?.plan;
  const precio= plan && db.config.precios?.[plan];
  if(precio != null && precio > 0){
    imp.value = precio;
    if(tag){
      const labels={'suelta':'Clase suelta','35':'1 cls/sem','50':'2 cls/sem','80':'VIP','bono':'Bono'};
      tag.textContent = labels[plan] || plan;
    }
  } else {
    imp.value = '';
    if(tag) tag.textContent = '';
  }
}

function calcDesglose(){
  const uid=($('pgAlumno')||{}).value;
  const imp=parseFloat(($('pgImporte')||{}).value);
  const mes=($('pgMes')||{}).value;
  const cont=$('pgDesglose');
  if (!cont||!uid||isNaN(imp)||imp<=0){if(cont)cont.innerHTML='<em style="color:var(--muted);">Introduce datos para ver el desglose.</em>';return;}
  const n=numPagoDeUsuario(uid,mes,'');
  const r=calcularReparto(imp,n);
  cont.innerHTML=`
    <div style="display:flex;justify-content:space-between;padding:4px 0;"><span style="color:var(--muted);">Total cobrado</span><b>${eur(r.importe)}</b></div>
    <div style="display:flex;justify-content:space-between;padding:4px 0;"><span style="color:var(--muted);">IVA (${db.config.iva}%)</span><span style="color:var(--warn);">${eur(r.iva)}</span></div>
    <div style="display:flex;justify-content:space-between;padding:4px 0;"><span style="color:var(--muted);">Base imponible</span><b>${eur(r.base)}</b></div>
    <div style="border-top:1px solid var(--border);margin-top:8px;padding-top:8px;display:flex;justify-content:space-between;"><span style="color:var(--muted);">➜ Malevo (${r.malevoPct}%)</span><b style="color:var(--ok);">${eur(r.malevo)}</b></div>
    <div style="display:flex;justify-content:space-between;padding:4px 0;"><span style="color:var(--muted);">➜ The Box (${r.boxPct}%)</span><span>${eur(r.box)}</span></div>`;
}

async function guardarPago(id){
  const userId=$('pgAlumno').value;
  const importe=parseFloat($('pgImporte').value);
  if (!userId||isNaN(importe)||importe<=0){alert('Datos incompletos.');return;}
  const data={userId,mes:$('pgMes').value,fechaPago:$('pgFecha').value||hoy(),
    importe,metodo:$('pgMetodo').value,notas:$('pgNotas').value.trim()};
  try {
    if (id){ await apiJSON('PUT',`/api/payments/${id}`,data); }
    else { await apiJSON('POST','/api/payments',data); }
    cerrarModal('modalPago');
    await cargarDB();
    if (confirm('Pago guardado. ¿Generar ticket?')) generarTicket(id||db.payments[db.payments.length-1]?.id);
    confirmSave('Pago registrado');
    renderView('pagos');
  } catch(e){ alert('Error: '+e.message); }
}

/* ── Factura Simplificada Exprés ── */
function abrirFacturaSimplificada(){
  const precios = db.config?.precios || {};
  const iva     = db.config?.iva ?? 21;

  // Conceptos rápidos predefinidos + libre
  const conceptos = [
    { l:'Clase suelta',         v: precios.suelta || 12 },
    { l:'Clase suelta × 2',     v: (precios.suelta||12) * 2 },
    { l:'Bono 10 clases',       v: precios.bono   || 100 },
    { l:'1 clase/sem — mensual',v: precios['35']  || 35 },
    { l:'2 clases/sem — mensual',v: precios['50'] || 50 },
    { l:'VIP / Full Pass',      v: precios['80']  || 80 },
    { l:'Personalizado…',       v: 0 }
  ];

  const html =
    '<div class="modal-overlay open" id="modalFSimp">'+
    '<div class="modal-box" style="max-width:460px;">'+
    '<h3 class="modal-title">⚡ Factura simplificada exprés</h3>'+
    '<p style="color:var(--muted);font-size:12.5px;margin-bottom:18px;line-height:1.5;">'+
      'Para cobros puntuales sin cliente registrado. La factura se numera y queda en el sistema.</p>'+

    '<label class="label-field">Concepto *</label>'+
    '<select id="fsConcepto" onchange="fsSyncImporte()" style="font-size:14px;">'+
      conceptos.map(c=>'<option value="'+c.v+'">'+c.l+(c.v?' · '+eur(c.v):'')+'</option>').join('')+
    '</select>'+

    '<label class="label-field" style="margin-top:12px;">Descripción libre</label>'+
    '<input type="text" id="fsDesc" placeholder="Ej: Clase suelta bachata — 4 ago. 2026"'+
      ' value="Clase suelta — '+new Date().toLocaleDateString('es-ES',{day:'numeric',month:'long',year:'numeric'})+'">'+

    '<div class="g2" style="margin-top:12px;">'+
      '<div><label class="label-field">Importe total (€, IVA incl.) *</label>'+
        '<input type="number" id="fsImporte" step="0.01" min="0" placeholder="12.00"'+
          ' value="'+(precios.suelta||12)+'" oninput="fsActualizaDesglose()"'+
          ' style="font-size:18px;font-weight:700;color:var(--gold-2);">'+
      '</div>'+
      '<div><label class="label-field">Método de cobro</label>'+
        '<select id="fsMetodo">'+
          ['Efectivo','Bizum','Transferencia','Tarjeta'].map(m=>'<option>'+m+'</option>').join('')+
        '</select>'+
      '</div>'+
    '</div>'+

    '<div id="fsDesglose" style="background:var(--surface-2);border:1px solid var(--border-2);'+
      'border-radius:12px;padding:14px;margin-top:14px;font-size:13px;"></div>'+

    '<label class="label-field" style="margin-top:14px;">Fecha</label>'+
    '<input type="date" id="fsFecha" value="'+hoy()+'">'+

    '<div style="display:flex;gap:10px;margin-top:22px;justify-content:flex-end;">'+
      '<button class="btn sec" onclick="cerrarModal(\'modalFSimp\')">Cancelar</button>'+
      '<button class="btn ok" onclick="emitirFacturaSimplificada()">⚡ Emitir y generar ticket</button>'+
    '</div>'+
    '</div></div>';

  document.body.insertAdjacentHTML('beforeend', html);
  fsActualizaDesglose();
}

function fsSyncImporte(){
  const sel = $('fsConcepto');
  const val = parseFloat(sel?.value);
  if(val > 0){ const imp = $('fsImporte'); if(imp) imp.value = val; }
  fsActualizaDesglose();
}

function fsActualizaDesglose(){
  const cont = $('fsDesglose');
  if(!cont) return;
  const imp = parseFloat($('fsImporte')?.value);
  const iva  = db.config?.iva ?? 21;
  if(isNaN(imp) || imp <= 0){
    cont.innerHTML='<em style="color:var(--muted);">Introduce el importe para ver el desglose.</em>';
    return;
  }
  const base = imp / (1 + iva/100);
  const ivaAmt = imp - base;
  const f = x => (Math.round(x*100)/100).toLocaleString('es-ES',{minimumFractionDigits:2})+'€';
  cont.innerHTML=
    '<div style="display:flex;justify-content:space-between;padding:3px 0;">'+
      '<span style="color:var(--muted);">Base imponible</span><b>'+f(base)+'</b></div>'+
    '<div style="display:flex;justify-content:space-between;padding:3px 0;">'+
      '<span style="color:var(--muted);">IVA ('+iva+'%)</span>'+
      '<span style="color:var(--warn);">'+f(ivaAmt)+'</span></div>'+
    '<div style="display:flex;justify-content:space-between;padding:6px 0 0;'+
      'border-top:1px solid var(--border);margin-top:6px;">'+
      '<b>Total facturado</b><b style="color:var(--gold-2);font-size:16px;">'+f(imp)+'</b></div>';
}

async function emitirFacturaSimplificada(){
  const importe = parseFloat($('fsImporte')?.value);
  if(!importe || importe <= 0){ showToast('Introduce un importe válido.','warn'); return; }
  const desc    = ($('fsDesc')?.value||'').trim() || 'Factura simplificada';
  const metodo  = $('fsMetodo')?.value || 'Efectivo';
  const fecha   = $('fsFecha')?.value  || hoy();
  const mes     = fecha.slice(0,7);

  // Guardar como pago sin userId (cliente anónimo)
  try {
    const res = await apiJSON('POST', '/api/payments', {
      userId:   '__anonimo__',
      mes,
      fechaPago: fecha,
      importe,
      metodo,
      notas:    desc,
      simplificada: true
    });
    cerrarModal('modalFSimp');
    await cargarDB();
    // Generar ticket directamente
    const pid = res?.payment?.id || db.payments[db.payments.length-1]?.id;
    if(pid) generarTicketSimplificado(pid, desc);
    confirmSave('Factura simplificada emitida');
    renderView('pagos');
  } catch(e){ showToast('Error: '+e.message,'warn'); }
}

// ── Factura completa de cuota mensual — descarga PDF del servidor ─────────
function generarTicket(pagoId){
  _descargarPDFFactura(pagoId);
}

// ── Factura simplificada — descarga PDF del servidor ─────────────────────
function generarTicketSimplificado(pagoId, desc){
  _descargarPDFFactura(pagoId);
}

// Descarga un PDF individual desde el servidor
function _descargarPDFFactura(pagoId){
  const p = (db.payments||[]).find(x=>x.id===pagoId);
  if(!p){ showToast('Pago no encontrado','warn'); return; }
  const numT = p.numeroTicket ? 'T-'+String(p.numeroTicket).padStart(5,'0') : pagoId.slice(0,8);
  const a = document.createElement('a');
  a.href     = `/api/factura/${pagoId}/pdf`;
  a.download = `${numT}.pdf`;
  a.click();
  showToast(`Descargando ${numT}.pdf…`, 'info', 2000);
}

// Etiquetas de plan (usadas en el servidor, aquí solo para referencia en UI)
const PLAN_DESC = {
  suelta: 'Clase suelta',
  '35':   'Tarifa 1 clase/semana',
  '50':   'Tarifa 2 clases/semana',
  '80':   'Tarifa VIP / Full Pass',
  bono:   'Bono 10 clases',
};

// CSS común para A4
function _estiloFacturaA4(){
  return `
    @page { size: A4; margin: 24mm 22mm 20mm; }
    * { box-sizing: border-box; }
    body {
      font-family: "Segoe UI", "Helvetica Neue", Arial, sans-serif;
      color: #1a1a1a; margin: 0; padding: 0; font-size: 13px; line-height: 1.5;
    }
    /* ── Cabecera emisor ── */
    .hdr {
      display: flex; align-items: flex-start;
      justify-content: space-between; gap: 24px;
      padding-bottom: 18px; margin-bottom: 24px;
      border-bottom: 2px solid #FFD700;
    }
    .hdr-left { flex: 1; }
    .hdr-logo { max-height: 60px; max-width: 200px;
      object-fit: contain; display: block; margin-bottom: 10px; }
    .hdr-nombre { font-size: 18px; font-weight: 700; color: #1a1a1a; margin: 0 0 5px; }
    .hdr-meta { font-size: 11px; color: #666; line-height: 1.75; }
    .hdr-right { text-align: right; flex: 0 0 auto; }
    .hdr-tipo {
      font-size: 9px; letter-spacing: 2px; text-transform: uppercase;
      color: #aaa; margin-bottom: 5px;
    }
    .hdr-num { font-size: 24px; font-weight: 800; color: #FFD700; letter-spacing: 1px; }
    .hdr-fecha { font-size: 11px; color: #888; margin-top: 4px; }
    /* ── Secciones ── */
    .sec-label {
      font-size: 9.5px; text-transform: uppercase; letter-spacing: 1.5px;
      color: #bbb; font-weight: 700; margin: 20px 0 8px;
    }
    /* ── Bloque cliente ── */
    .cliente-box {
      background: #f8f7f4; border-radius: 8px;
      padding: 14px 18px; margin-bottom: 8px;
    }
    .cliente-nombre { font-size: 15px; font-weight: 700; margin: 0 0 3px; }
    .cliente-meta { font-size: 11.5px; color: #777; }
    /* ── Tabla desglose ── */
    table { width: 100%; border-collapse: collapse; margin-top: 4px; }
    thead th {
      text-align: left; font-size: 9.5px; text-transform: uppercase;
      letter-spacing: 1px; color: #bbb; font-weight: 700;
      padding: 5px 0 6px; border-bottom: 1px solid #e0e0e0;
    }
    thead th.r { text-align: right; }
    tbody td { padding: 9px 0; border-bottom: 1px solid #f0f0f0; vertical-align: top; }
    .sub-label { color: #888; }
    .r { text-align: right; }
    .fila-base td { font-size: 13px; }
    .fila-iva  td { font-size: 12.5px; color: #888; }
    .fila-tot  td {
      font-size: 17px; font-weight: 800;
      border-top: 2px solid #FFD700; border-bottom: none;
      padding-top: 10px; color: #1a1a1a;
    }
    .fila-tot .r { color: #FFD700; }
    /* ── Pie ── */
    .foot {
      margin-top: 36px; padding-top: 14px;
      border-top: 1px dashed #ddd;
      font-size: 10.5px; color: #aaa; text-align: center; line-height: 1.8;
    }
    .btn-print {
      display: block; width: 100%; padding: 13px; margin-top: 24px;
      background: linear-gradient(135deg, #FFD700, #8A7000);
      color: #fff; border: none; border-radius: 10px;
      cursor: pointer; font-size: 14px; font-weight: 600;
    }
    @media print { .btn-print { display: none; } }
  `;
}

// Cabecera HTML del emisor
function _cabeceraPDF(neg, numT, tipo, fechaStr){
  return `
  <div class="hdr">
    <div class="hdr-left">
      ${neg.logo ? `<img class="hdr-logo" src="${neg.logo}" alt="Logo">` : ''}
      <div class="hdr-nombre">${esc(neg.nombre||'Academia de Baile Malevo')}</div>
      <div class="hdr-meta">
        ${neg.nif       ? `<span>NIF: ${esc(neg.nif)}</span><br>` : ''}
        ${neg.direccion ? `<span>${esc(neg.direccion)}</span><br>` : ''}
        ${neg.telefono  ? `<span>Tel: ${esc(neg.telefono)}</span>` : ''}
        ${neg.telefono && neg.email ? '&emsp;' : ''}
        ${neg.email     ? `<span>${esc(neg.email)}</span>` : ''}
      </div>
    </div>
    <div class="hdr-right">
      <div class="hdr-tipo">${tipo}</div>
      <div class="hdr-num">${numT}</div>
      <div class="hdr-fecha">${fechaStr}</div>
    </div>
  </div>`;
}

// Pie de factura
function _piePDF(neg, metodo){
  const textoLegal = neg.nif ? `NIF emisor: ${esc(neg.nif)}` : '';
  const textoPago  = metodo  ? `Método de pago: ${esc(metodo)}` : '';
  const sep = textoLegal && textoPago ? ' &nbsp;·&nbsp; ' : '';
  return `
  <div class="foot">
    ${esc(neg.pie || 'Gracias por bailar con nosotros 💃🕺')}<br>
    ${textoLegal}${sep}${textoPago}
  </div>`;
}

// ── Factura completa de cuota mensual ─────────────────────────────────────
function generarTicket(pagoId){
  const p = (db.payments||[]).find(x=>x.id===pagoId);
  if(!p) return;
  const u   = (db.users||[]).find(x=>x.id===p.userId);
  const c   = db.config;
  const neg = c.negocio || {};
  const ivaRate = c.iva ?? 21;
  const base    = p.importe / (1 + ivaRate/100);
  const ivaAmt  = p.importe - base;
  const f = x => (Math.round(x*100)/100).toLocaleString('es-ES',{minimumFractionDigits:2}) + ' €';

  const numT      = p.numeroTicket ? 'T-' + String(p.numeroTicket).padStart(5,'0') : '—';
  const fechaStr  = new Date((p.fechaPago||hoy())+'T12:00:00')
    .toLocaleDateString('es-ES',{day:'numeric',month:'long',year:'numeric'});
  const mesStr    = p.mes
    ? new Date(p.mes+'-01T00:00:00').toLocaleDateString('es-ES',{month:'long',year:'numeric'})
    : '';

  // Concepto claro: plan + mes
  const planLabel = (u && PLAN_DESC[u.plan]) ? PLAN_DESC[u.plan] : 'Servicio de clases de baile';
  const concepto  = mesStr
    ? `${planLabel} · ${mesStr.charAt(0).toUpperCase()+mesStr.slice(1)}`
    : (p.notas || planLabel);
  const notasExtra = p.notas && p.notas !== concepto ? p.notas : '';

  const html = `<!DOCTYPE html>
<html lang="es"><head>
<meta charset="UTF-8">
<title>Factura ${numT}</title>
<style>${_estiloFacturaA4()}</style>
</head><body>

${_cabeceraPDF(neg, numT, 'Factura simplificada', fechaStr)}

<div class="sec-label">Cliente</div>
<div class="cliente-box">
  <div class="cliente-nombre">${esc(u?.nombre || '—')}</div>
  ${u?.email    ? `<div class="cliente-meta">✉ ${esc(u.email)}</div>`    : ''}
  ${u?.telefono ? `<div class="cliente-meta">📞 ${esc(u.telefono)}</div>` : ''}
</div>

<div class="sec-label">Concepto y desglose</div>
<table>
  <thead>
    <tr>
      <th>Descripción</th>
      <th class="r">Base imponible</th>
      <th class="r">IVA (${ivaRate}%)</th>
      <th class="r">Total</th>
    </tr>
  </thead>
  <tbody>
    <tr class="fila-base">
      <td>
        ${esc(concepto)}
        ${notasExtra ? `<br><span style="font-size:11px;color:#999;">${esc(notasExtra)}</span>` : ''}
      </td>
      <td class="r">${f(base)}</td>
      <td class="r">${f(ivaAmt)}</td>
      <td class="r">${f(p.importe)}</td>
    </tr>
  </tbody>
  <tfoot>
    <tr class="fila-tot">
      <td>Total a pagar</td>
      <td class="r" colspan="3">${f(p.importe)}</td>
    </tr>
  </tfoot>
</table>

${_piePDF(neg, p.metodo)}
<button class="btn-print" onclick="window.print()">🖨 Imprimir / Guardar PDF</button>
<script>window.onload=()=>setTimeout(()=>window.print(),400);<\/script>
</body></html>`;

  const w = window.open('','_blank','width=700,height=900');
  if(!w){ alert('Permite ventanas emergentes para generar la factura.'); return; }
  w.document.write(html); w.document.close();
}

// ── Factura simplificada (clase suelta / cobro exprés) ────────────────────
function generarTicketSimplificado(pagoId, desc){
  const p = (db.payments||[]).find(x=>x.id===pagoId);
  if(!p) return;
  const c   = db.config;
  const neg = c.negocio || {};
  const ivaRate = c.iva ?? 21;
  const base    = p.importe / (1 + ivaRate/100);
  const ivaAmt  = p.importe - base;
  const f = x => (Math.round(x*100)/100).toLocaleString('es-ES',{minimumFractionDigits:2}) + ' €';

  const numT     = p.numeroTicket ? 'T-' + String(p.numeroTicket).padStart(5,'0') : '—';
  const fechaStr = new Date((p.fechaPago||hoy())+'T12:00:00')
    .toLocaleDateString('es-ES',{day:'numeric',month:'long',year:'numeric'});

  // Cliente: puede ser anónimo (clase suelta exprés) o un alumno
  const u = p.userId && p.userId !== '__anonimo__'
    ? (db.users||[]).find(x=>x.id===p.userId)
    : null;
  const clienteNombre  = u?.nombre || 'Público en general';
  const clienteEmail   = u?.email   || '';
  const clienteTel     = u?.telefono || '';

  // Concepto
  const concepto = desc || p.notas || 'Clase de baile · Cobro puntual';

  const html = `<!DOCTYPE html>
<html lang="es"><head>
<meta charset="UTF-8">
<title>Factura Simplificada ${numT}</title>
<style>${_estiloFacturaA4()}</style>
</head><body>

${_cabeceraPDF(neg, numT, 'Factura simplificada', fechaStr)}

<div class="sec-label">Cliente</div>
<div class="cliente-box">
  <div class="cliente-nombre">${esc(clienteNombre)}</div>
  ${clienteEmail ? `<div class="cliente-meta">✉ ${esc(clienteEmail)}</div>`   : ''}
  ${clienteTel   ? `<div class="cliente-meta">📞 ${esc(clienteTel)}</div>`    : ''}
  ${!u ? `<div class="cliente-meta" style="color:#bbb;font-size:11px;">
    Operación sin identificación de destinatario (art. 4 RD 1619/2012)
  </div>` : ''}
</div>

<div class="sec-label">Concepto y desglose</div>
<table>
  <thead>
    <tr>
      <th>Descripción</th>
      <th class="r">Base imponible</th>
      <th class="r">IVA (${ivaRate}%)</th>
      <th class="r">Total</th>
    </tr>
  </thead>
  <tbody>
    <tr class="fila-base">
      <td>${esc(concepto)}</td>
      <td class="r">${f(base)}</td>
      <td class="r">${f(ivaAmt)}</td>
      <td class="r">${f(p.importe)}</td>
    </tr>
  </tbody>
  <tfoot>
    <tr class="fila-tot">
      <td>Total a pagar</td>
      <td class="r" colspan="3">${f(p.importe)}</td>
    </tr>
  </tfoot>
</table>

${_piePDF(neg, p.metodo)}
<button class="btn-print" onclick="window.print()">🖨 Imprimir / Guardar PDF</button>
<script>window.onload=()=>setTimeout(()=>window.print(),400);<\/script>
</body></html>`;

  const w = window.open('','_blank','width=700,height=900');
  if(!w){ alert('Permite ventanas emergentes para generar la factura.'); return; }
  w.document.write(html); w.document.close();
}

function editarPago(id){ abrirPago(null,id); }
async function borrarPago(id){
  if (!confirm('¿Eliminar este pago?')) return;
  await apiJSON('DELETE',`/api/payments/${id}`);
  await cargarDB(); renderView('pagos');
}

/* ── Vista VÍDEOS ── */
let _videosGrupoActivo = null; // {disciplina, nivel} | null — grupo abierto en "Gestionar →"
let _videosTipoActivo  = null; // 'calentamiento' | 'bonus' | 'playlist' | 'evento' | null

function renderVideos(cont){
  if (_videosGrupoActivo){ renderVideosGrupo(cont); return; }
  if (_videosTipoActivo){ renderVideosPorTipo(cont); return; }

  const vids = (db.videos||[]).filter(v=>!v.tipo||v.tipo==='clase');
  const grupos = [];
  DISCIPLINAS_VIDEO.forEach(disc=>{
    NIVELES.forEach(n=>{
      grupos.push({disciplina:disc, nivel:n, count: vids.filter(v=>v.disciplina===disc&&v.nivel===n).length});
    });
  });
  const maxCount = Math.max(1, ...grupos.map(g=>g.count));
  const contarTipo = t => (db.videos||[]).filter(v=>v.tipo===t).length;

  cont.innerHTML = `<div class="section-head">
    <div></div>
    <button class="btn" style="background:var(--card-bg);border:1px solid var(--card-border);color:var(--gold);box-shadow:none;" onclick="abrirModalVideo()">+ Nuevo contenido</button>
  </div>

  <!-- Accesos rápidos a contenido extra del portal del alumno (Bonus y Playlist se gestionan dentro de cada nivel, en "Gestionar →") -->
  <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:22px;">
    ${[['calentamiento','🔥 Calentamientos'],['evento','🎉 Eventos y Talleres']].map(([t,l])=>
      `<button class="vg-link" style="background:var(--card-bg);border:1px solid var(--card-border);
        border-radius:30px;padding:8px 16px;color:var(--text-2);" onclick="abrirVideosPorTipo('${t}')">
        ${l} <span style="color:var(--muted);">· ${contarTipo(t)}</span>
      </button>`).join('')}
  </div>

  <div class="videos-grid">
    ${grupos.map(g=>{
      const pct = Math.round(g.count/maxCount*100);
      return `<div class="video-group-card">
        <div class="vg-name">${esc(g.disciplina)} · ${nivelLabel(g.nivel)}</div>
        <div class="vg-count"><span class="vg-num">${g.count}</span><span class="vg-label">VÍDEOS</span></div>
        <div class="vg-bar"><div class="vg-bar-fill" style="width:${pct}%;"></div></div>
        <div class="vg-foot">
          <span class="vg-disc">${esc(g.disciplina)}</span>
          <button class="vg-link" onclick="abrirGrupoVideos('${esc(g.disciplina)}',${g.nivel})">Gestionar →</button>
        </div>
      </div>`;
    }).join('')}
  </div>`;
}

function abrirVideosPorTipo(tipo){
  _videosTipoActivo = tipo;
  renderView('videos');
}
function cerrarVideosPorTipo(){
  _videosTipoActivo = null;
  renderView('videos');
}

function renderVideosPorTipo(cont){
  const tipo = _videosTipoActivo;
  const labels = {calentamiento:'🔥 Calentamientos', bonus:'🎁 Bonus', playlist:'🎵 Playlists', evento:'🎉 Eventos y Talleres'};
  const items = (db.videos||[]).filter(v=>v.tipo===tipo).sort((a,b)=>(a.orden||0)-(b.orden||0));

  cont.innerHTML = `<button class="acc-toggle" style="margin-bottom:10px;" onclick="cerrarVideosPorTipo()">← Volver a Vídeos</button>
  <div class="section-head">
    <div>
      <div class="h2" style="margin-bottom:4px;">${labels[tipo]}</div>
      <div style="font-size:12.5px;color:var(--muted);">${items.length} elemento${items.length!==1?'s':''}</div>
    </div>
    <button class="btn" style="background:var(--card-bg);border:1px solid var(--card-border);color:var(--gold);box-shadow:none;"
      onclick="abrirModalVideo(null,null,null,'${tipo}')">+ Añadir</button>
  </div>
  <div id="tablaVideosTipo"></div>`;

  const tabla=$('tablaVideosTipo');
  if (!items.length){ tabla.innerHTML='<div class="vacio">Sin elementos todavía.</div>'; return; }

  const wrap=document.createElement('div'); wrap.className='tbl-wrap';
  let h='<table><thead><tr><th>Título</th>';
  if (tipo==='bonus'||tipo==='playlist') h+='<th>Nivel</th>';
  if (tipo==='evento') h+='<th>Fecha</th>';
  h+='<th></th></tr></thead><tbody>';
  items.forEach(v=>{
    let metaCol='';
    if (tipo==='bonus'||tipo==='playlist') metaCol=`<td><span class="badge muted">${esc(v.disciplina)} · ${nivelLabelCorto(v.nivel)}</span></td>`;
    if (tipo==='evento'){
      let meta={}; try{ meta=JSON.parse(v.notas||'{}'); }catch{}
      metaCol=`<td>${esc(meta.fecha||'—')}</td>`;
    }
    h+=`<tr>
      <td><strong>${esc(v.titulo)}</strong></td>
      ${metaCol}
      <td><div style="display:flex;gap:6px;justify-content:flex-end;">
        <button class="btn sm sec" onclick="abrirModalVideo('${v.id}')">Editar</button>
        <button class="btn sm warn" onclick="borrarVideo('${v.id}')">×</button>
      </div></td>
    </tr>`;
  });
  wrap.innerHTML=h+'</tbody></table>';
  tabla.innerHTML=''; tabla.appendChild(wrap);
}

function abrirGrupoVideos(disciplina, nivel){
  _videosGrupoActivo = {disciplina, nivel};
  renderView('videos');
}
function cerrarGrupoVideos(){
  _videosGrupoActivo = null;
  renderView('videos');
}

function renderVideosGrupo(cont){
  const {disciplina, nivel} = _videosGrupoActivo;
  const vids = (db.videos||[]).filter(v=>v.disciplina===disciplina&&v.nivel===nivel&&(!v.tipo||v.tipo==='clase'))
    .sort((a,b)=>(a.orden||0)-(b.orden||0));
  const bonus = nivel===4 ? [] : (db.videos||[]).filter(v=>v.disciplina===disciplina&&v.nivel===nivel&&v.tipo==='bonus')
    .sort((a,b)=>(a.orden||0)-(b.orden||0));
  const playlists = (db.videos||[]).filter(v=>v.disciplina===disciplina&&v.nivel===nivel&&v.tipo==='playlist')
    .sort((a,b)=>(a.orden||0)-(b.orden||0));

  cont.innerHTML = `<button class="acc-toggle" style="margin-bottom:10px;" onclick="cerrarGrupoVideos()">← Volver a Vídeos</button>
  <div class="section-head">
    <div>
      <div class="h2" style="margin-bottom:4px;">${esc(disciplina)} · ${nivelLabel(nivel)}</div>
      <div style="font-size:12.5px;color:var(--muted);">${vids.length} vídeo${vids.length!==1?'s':''} en este nivel</div>
    </div>
    <button class="btn" style="background:var(--card-bg);border:1px solid var(--card-border);color:var(--gold);box-shadow:none;"
      onclick="abrirModalVideo(null,'${esc(disciplina)}',${nivel})">+ Nuevo vídeo</button>
  </div>
  ${vids.length?`<div style="display:flex;justify-content:flex-end;margin-bottom:10px;">
    <button class="btn sm" style="background:transparent;border:1px solid rgba(224,92,92,.35);color:var(--warn);box-shadow:none;"
      onclick="vaciarNivelVideos('${esc(disciplina)}',${nivel})">🗑 Vaciar nivel (${vids.length})</button>
  </div>`:''}
  <div id="tablaVideos"></div>

  ${nivel!==4 ? `
  <div class="section-head" style="margin-top:32px;">
    <div class="h2" style="margin-bottom:0;">🎁 Bonus (${bonus.length}/3)</div>
    ${bonus.length<3?`<button class="btn" style="background:var(--card-bg);border:1px solid var(--card-border);color:var(--gold);box-shadow:none;"
      onclick="abrirModalVideo(null,'${esc(disciplina)}',${nivel},'bonus')">+ Añadir bonus</button>`:''}
  </div>
  <p style="font-size:12px;color:var(--muted);margin:-6px 0 14px;">Se desbloquean progresivamente a los 5, 10 y 15 vídeos vistos por el alumno en este nivel.</p>
  <div id="tablaBonusNivel"></div>` : ''}

  <div class="section-head" style="margin-top:32px;">
    <div class="h2" style="margin-bottom:0;">🎵 Playlists de este nivel (${playlists.length})</div>
    <button class="btn" style="background:var(--card-bg);border:1px solid var(--card-border);color:var(--gold);box-shadow:none;"
      onclick="abrirModalVideo(null,'${esc(disciplina)}',${nivel},'playlist')">+ Añadir playlist</button>
  </div>
  <p style="font-size:12px;color:var(--muted);margin:-6px 0 14px;">Puedes cargar varias para comparar — todas se mostrarán en el portal del alumno.</p>
  <div id="playlistNivelWrap"></div>`;

  renderTablaVideosGrupo(vids);
  renderTablaBonusNivel(bonus);
  renderPlaylistsNivel(playlists);
}

/* ── Mini-tabla de los hasta 3 vídeos bonus de este nivel ── */
function renderTablaBonusNivel(bonus){
  const cont=$('tablaBonusNivel');
  if (!cont) return;
  if (!bonus.length){ cont.innerHTML='<div class="vacio">Sin bonus cargados todavía en este nivel.</div>'; return; }
  const wrap=document.createElement('div');
  wrap.className='tbl-wrap';
  let h=`<table><thead><tr><th>Título</th><th>URL / Embed</th><th></th></tr></thead><tbody>`;
  bonus.forEach((v,i)=>{
    h+=`<tr>
      <td><span class="badge muted" style="margin-right:8px;">Bonus ${i+1}</span><strong>${esc(v.titulo)}</strong></td>
      <td style="max-width:280px;"><small style="color:var(--muted);word-break:break-all;">${esc(v.url)}</small></td>
      <td><div style="display:flex;gap:6px;">
        <button class="btn sm sec" onclick="abrirModalVideo('${v.id}')">Editar</button>
        <button class="btn sm warn" onclick="borrarVideo('${v.id}')">×</button>
      </div></td>
    </tr>`;
  });
  wrap.innerHTML=h+'</tbody></table>';
  cont.innerHTML=''; cont.appendChild(wrap);
}

/* ── Lista todas las playlists cargadas para este nivel (no hay límite: se
   pueden añadir varias para comparar, todas se muestran en el portal) ── */
function renderPlaylistsNivel(playlists){
  const cont=$('playlistNivelWrap');
  if (!cont) return;
  if (!playlists.length){
    cont.innerHTML='<div class="vacio">Sin playlists cargadas para este nivel todavía.</div>';
    return;
  }
  cont.innerHTML = playlists.map(p=>`<div class="card" style="display:flex;align-items:center;gap:14px;padding:16px 18px;margin-bottom:10px;">
    <div style="width:40px;height:40px;border-radius:10px;background:rgba(255,215,0,.1);
      border:1px solid var(--gold);display:flex;align-items:center;justify-content:center;font-size:18px;flex:0 0 auto;">🎵</div>
    <div style="flex:1;min-width:0;">
      <div style="font-size:13.5px;font-weight:700;color:var(--white);">${esc(p.titulo)}</div>
      <div style="font-size:11.5px;color:var(--muted);word-break:break-all;">${esc(p.url)}</div>
    </div>
    <button class="btn sm sec" onclick="abrirModalVideo('${p.id}')">Editar</button>
    <button class="btn sm warn" onclick="borrarVideo('${p.id}')">×</button>
  </div>`).join('');
}

/* ── Borra de golpe todos los vídeos de clase de un nivel (p.ej. para limpiar
   el catálogo de ejemplo sembrado automáticamente en su día) ── */
async function vaciarNivelVideos(disciplina, nivel){
  const vids = (db.videos||[]).filter(v=>v.disciplina===disciplina&&v.nivel===nivel&&(!v.tipo||v.tipo==='clase'));
  if (!vids.length) return;
  if (!confirm(`¿Eliminar los ${vids.length} vídeos de ${disciplina} · Nivel ${nivel}? Esta acción no se puede deshacer.`)) return;
  try {
    for (const v of vids){ await apiJSON('DELETE',`/api/videos/${v.id}`); }
    await cargarDB();
    renderView('videos');
    confirmSave(`${vids.length} vídeo(s) eliminados de ${disciplina} · Nivel ${nivel}`);
  } catch(e){ alert('Error al vaciar el nivel: '+e.message); }
}

function renderTablaVideosGrupo(vids){
  const cont=$('tablaVideos');
  if (!cont) return;
  if (!vids.length){ cont.innerHTML='<div class="vacio">Sin vídeos en este nivel todavía.</div>'; return; }
  const wrap=document.createElement('div');
  wrap.className='tbl-wrap';
  let h=`<table><thead><tr><th>Título</th><th>URL / Embed</th><th>Orden</th><th></th></tr></thead><tbody>`;
  vids.forEach(v=>{
    h+=`<tr>
      <td><strong>${esc(v.titulo)}</strong></td>
      <td style="max-width:280px;"><small style="color:var(--muted);word-break:break-all;">${esc(v.url)}</small></td>
      <td>${v.orden}</td>
      <td><div style="display:flex;gap:6px;">
        <button class="btn sm sec" onclick="abrirModalVideo('${v.id}')">Editar</button>
        <button class="btn sm warn" onclick="borrarVideo('${v.id}')">×</button>
      </div></td>
    </tr>`;
  });
  wrap.innerHTML=h+'</tbody></table>';
  cont.innerHTML='';
  cont.appendChild(wrap);
}

function abrirModalVideo(id, presetDisc, presetNivel, presetTipo){
  const v=id?(db.videos||[]).find(x=>x.id===id):null;
  const tipo = (v&&v.tipo) || presetTipo || 'clase';
  const discOpts=DISCIPLINAS_VIDEO.map(function(d){
    return '<option value="'+d+'"'+(((v&&v.disciplina)||presetDisc||'Bachata')===d?' selected':'')+'>'+d+'</option>';
  }).join('');
  const nivelOpts=NIVELES.map(function(n){
    return '<option value="'+n+'"'+(((v&&v.nivel)||presetNivel||1)==n?' selected':'')+'>'+nivelLabel(n)+'</option>';
  }).join('');
  let notasEvento={}; if (v&&v.tipo==='evento'){ try{ notasEvento=JSON.parse(v.notas||'{}'); }catch{} }

  const overlay=document.createElement('div');
  overlay.className='modal-overlay open';
  overlay.id='modalVideo';
  overlay.innerHTML=
    '<div class="modal-box">'+
    '<h3 class="modal-title">'+(v?'Editar contenido':'Nuevo contenido')+'</h3>'+

    '<label class="label-field">Tipo de contenido</label>'+
    '<select id="vTipo" onchange="avToggleTipoVideo()">'+
      '<option value="clase"'+(tipo==='clase'?' selected':'')+'>🎬 Clase de nivel</option>'+
      '<option value="calentamiento"'+(tipo==='calentamiento'?' selected':'')+'>🔥 Calentamiento / estiramiento</option>'+
      '<option value="bonus"'+(tipo==='bonus'?' selected':'')+'>🎁 Bonus (desbloqueo progresivo 5/10/15)</option>'+
      '<option value="playlist"'+(tipo==='playlist'?' selected':'')+'>🎵 Playlist oficial</option>'+
      '<option value="evento"'+(tipo==='evento'?' selected':'')+'>🎉 Evento / Taller presencial</option>'+
    '</select>'+

    '<label class="label-field">Título *</label>'+
    '<input type="text" id="vTitulo" value="'+esc(v&&v.titulo||'')+'" placeholder="Ej: Bachata básica — paso básico">'+

    // Disciplina + Nivel (clase, bonus, playlist)
    '<div class="g2" id="vGrupoDiscNivel">'+
      '<div><label class="label-field">Disciplina</label>'+
        '<select id="vDisc" onchange="avRecalcularOrden()">'+discOpts+'</select></div>'+
      '<div><label class="label-field">Nivel</label>'+
        '<select id="vNivel" onchange="avRecalcularOrden()">'+nivelOpts+'</select></div>'+
    '</div>'+

    // URL (clase, calentamiento, bonus) / Enlace playlist (playlist) / Imagen o vídeo (evento)
    '<label class="label-field" id="vUrlLabel">URL del vídeo</label>'+
    '<input type="text" id="vUrl" value="'+esc(v&&v.url||'')+'" placeholder="https://www.youtube.com/embed/…">'+
    '<small style="color:var(--muted);font-size:11.5px;margin-top:6px;display:block;" id="vUrlHint">'+
      'YouTube: youtube.com/embed/VIDEO_ID · Archivos locales: /videos/nombre.mp4</small>'+

    // Notas (clase, calentamiento, bonus)
    '<label class="label-field" id="vNotasLabel">Notas pedagógicas</label>'+
    '<textarea id="vNotas" rows="2" placeholder="Descripción, objetivos…">'+esc(v&&v.tipo!=='evento'?(v.notas||''):'')+'</textarea>'+

    // Orden: se calcula solo (siguiente puesto libre del nivel al crear;
    // al editar se conserva el que ya tenía, sin volver a preguntar)
    '<input type="hidden" id="vOrden" value="'+(v?v.orden||1:1)+'" data-editando="'+(v?'1':'0')+'">'+

    // Campos exclusivos de Evento
    '<div id="vGrupoEvento" style="display:none;">'+
      '<label class="label-field">Fecha del evento</label>'+
      '<input type="date" id="vEvFecha" value="'+esc(notasEvento.fecha||'')+'">'+
      '<label class="label-field">Descripción</label>'+
      '<textarea id="vEvDescripcion" rows="2" placeholder="Qué se va a practicar, quién lo imparte…">'+esc(notasEvento.descripcion||'')+'</textarea>'+

      '<label class="label-field">Imagen del evento</label>'+
      '<select id="vEvFuente" onchange="avToggleFuenteEvento()">'+
        '<option value="upload"'+(!notasEvento.tipoImagen||notasEvento.tipoImagen==='upload'?' selected':'')+'>📁 Subir imagen (JPG/PNG)</option>'+
        '<option value="youtube"'+(notasEvento.tipoImagen==='youtube'?' selected':'')+'>🔗 Enlace de YouTube</option>'+
      '</select>'+

      '<div id="vEvUploadWrap" style="margin-top:10px;display:flex;align-items:center;gap:14px;">'+
        '<div id="vEvPreview" style="width:96px;height:64px;border-radius:8px;overflow:hidden;flex:0 0 auto;'+
          'background:rgba(255,255,255,.04);border:1px solid var(--card-border);display:flex;align-items:center;justify-content:center;">'+
          (v&&v.tipo==='evento'&&(!notasEvento.tipoImagen||notasEvento.tipoImagen==='upload')&&v.url
            ? '<img src="'+esc(v.url)+'" style="width:100%;height:100%;object-fit:cover;">'
            : '<span style="color:var(--muted);font-size:10px;text-align:center;padding:4px;">Sin imagen</span>')+
        '</div>'+
        '<label class="btn sec sm" style="cursor:pointer;">📁 Elegir archivo'+
          '<input type="file" accept="image/jpeg,image/png" style="display:none;" onchange="previsualizarImagenEvento(this)">'+
        '</label>'+
      '</div>'+
      '<input type="hidden" id="vEvImgData" value="'+(v&&v.tipo==='evento'&&(!notasEvento.tipoImagen||notasEvento.tipoImagen==='upload')?esc(v.url||''):'')+'">'+

      '<div id="vEvYoutubeWrap" style="display:none;margin-top:10px;">'+
        '<input type="text" id="vEvYoutubeUrl" value="'+(v&&v.tipo==='evento'&&notasEvento.tipoImagen==='youtube'?esc(v.url||''):'')+'" placeholder="https://www.youtube.com/watch?v=…">'+
      '</div>'+
    '</div>'+

    '<div style="display:flex;gap:10px;margin-top:22px;justify-content:flex-end;">'+
      (v?'<button class="btn warn sm" onclick="borrarVideo(&quot;'+v.id+'&quot;);cerrarModal(&quot;modalVideo&quot;);">Eliminar</button>':'')+
      '<button class="btn sec" onclick="cerrarModal(&quot;modalVideo&quot;)">Cancelar</button>'+
      '<button class="btn" onclick="guardarVideo(&quot;'+(v&&v.id||'')+'&quot;)">Guardar</button>'+
    '</div>'+
    '</div>';
  playModal(); document.body.appendChild(overlay);
  avToggleTipoVideo();
}

/* ── Muestra/oculta campos del modal de contenido según el tipo elegido ── */
function avToggleTipoVideo(){
  const tipo=$('vTipo')?.value||'clase';
  const show=(id,disp)=>{ const el=$(id); if(el) el.style.display=disp; };
  const label={
    clase:'URL del vídeo', calentamiento:'URL del vídeo', taller:'URL del vídeo',
    playlist:'Enlace de Spotify / Apple Music', evento:'URL de la imagen (flyer)'
  }[tipo];
  if ($('vUrlLabel')) $('vUrlLabel').textContent=label;
  show('vUrlHint', tipo==='clase'||tipo==='calentamiento'||tipo==='bonus' ? 'block':'none');

  // El campo URL genérico solo aplica a clase/calentamiento/taller/playlist — evento usa su propio bloque de imagen
  show('vUrlLabel', tipo==='evento' ? 'none':'block');
  const urlInput=$('vUrl'); if (urlInput) urlInput.style.display = tipo==='evento' ? 'none':'block';

  show('vGrupoDiscNivel', tipo==='clase'||tipo==='bonus'||tipo==='playlist' ? 'grid':'none');
  show('vNotasLabel', tipo==='evento' ? 'none':'block');
  const notas=$('vNotas'); if (notas) notas.style.display = tipo==='evento' ? 'none':'block';
  show('vGrupoEvento', tipo==='evento' ? 'block':'none');
  if (tipo==='evento') avToggleFuenteEvento();
  if (tipo==='clase') avRecalcularOrden();
}

/* ── Calcula automáticamente el siguiente puesto libre en el nivel al crear
   un vídeo nuevo (no se toca si se está editando uno ya existente) ── */
function avRecalcularOrden(){
  const ordenInput=$('vOrden');
  if (!ordenInput || ordenInput.dataset.editando==='1') return; // editando: no recalcular
  const disc=$('vDisc')?.value, nivel=parseInt($('vNivel')?.value);
  const siguiente=(db.videos||[]).filter(v=>v.disciplina===disc&&v.nivel===nivel&&(!v.tipo||v.tipo==='clase')).length+1;
  ordenInput.value=siguiente;
}

/* ── Alterna entre "subir imagen" y "enlace de YouTube" para el flyer del evento ── */
function avToggleFuenteEvento(){
  const fuente=$('vEvFuente')?.value||'upload';
  if ($('vEvUploadWrap'))   $('vEvUploadWrap').style.display   = fuente==='upload'  ? 'flex':'none';
  if ($('vEvYoutubeWrap'))  $('vEvYoutubeWrap').style.display  = fuente==='youtube' ? 'block':'none';
}

/* ── Sube y previsualiza la imagen del flyer (JPG/PNG, máx. 2 MB) ── */
function previsualizarImagenEvento(input){
  const file=input.files[0]; if (!file) return;
  if (file.size > 2*1024*1024){ showToast('La imagen supera los 2 MB','warn'); input.value=''; return; }
  const reader=new FileReader();
  reader.onload = e=>{
    const src=e.target.result;
    const preview=$('vEvPreview');
    if (preview) preview.innerHTML=`<img src="${src}" style="width:100%;height:100%;object-fit:cover;">`;
    const hidden=$('vEvImgData'); if (hidden) hidden.value=src;
  };
  reader.readAsDataURL(file);
}

async function guardarVideo(id){
  const titulo=$('vTitulo').value.trim();
  if (!titulo){alert('El título es obligatorio.');return;}
  const tipo=$('vTipo').value;
  let data={titulo, tipo};

  if (tipo==='evento'){
    const fuente=$('vEvFuente').value;
    const urlImagen = fuente==='youtube' ? $('vEvYoutubeUrl').value.trim() : $('vEvImgData').value;
    if (!urlImagen){ alert('Añade una imagen (JPG) o un enlace de YouTube para el evento.'); return; }
    data.url=urlImagen;
    data.disciplina='General'; data.nivel=0; data.orden=1;
    data.notas=JSON.stringify({
      fecha:$('vEvFecha').value||'',
      descripcion:$('vEvDescripcion').value.trim(),
      tipoImagen: fuente
    });
  } else {
    data.url=$('vUrl').value.trim();
    if (tipo==='clase'||tipo==='bonus'||tipo==='playlist'){
      data.disciplina=$('vDisc').value;
      data.nivel=parseInt($('vNivel').value);
    } else {
      data.disciplina='General'; data.nivel=0;
    }
    if (tipo==='clase'){
      data.orden=parseInt($('vOrden').value)||1;
      data.notas=$('vNotas').value.trim();
    } else if (tipo==='calentamiento'||tipo==='bonus'){
      data.orden=1;
      data.notas=$('vNotas').value.trim();
    } else { // playlist
      data.orden=1; data.notas='';
    }
  }

  try {
    if (id){ await apiJSON('PUT',`/api/videos/${id}`,data); }
    else { await apiJSON('POST','/api/videos',data); }
    cerrarModal('modalVideo');
    await cargarDB(); renderView('videos');
    confirmSave(tipo==='evento' ? 'Evento guardado' : tipo==='playlist' ? 'Playlist guardada' : 'Contenido guardado');
  } catch(e){ alert('Error: '+e.message); }
}

async function borrarVideo(id){
  if (!confirm('¿Eliminar este vídeo?')) return;
  await apiJSON('DELETE',`/api/videos/${id}`);
  await cargarDB(); renderView('videos');
}

/* ── Siembra automática del catálogo oficial de YouTube (Bachata/Salsa · Nivel 1-3) ──
   Se ejecuta sola al arrancar la app (arrancarApp), sin botón ni confirmación.
   Es idempotente: solo crea las entradas que todavía no existan (misma
   disciplina+nivel+url), así en cada arranque comprueba y no duplica nada. */
async function sembrarCatalogoOficialVideos(){
  if (!db) return;
  const DISC_MAP = { bachata:'Bachata', salsa:'Salsa' };
  const existentes = new Set(
    (db.videos||[]).map(v => `${v.disciplina}|${v.nivel}|${v.url}`)
  );

  const nuevos = [];
  Object.entries(CATALOGO_OFICIAL_VIDEOS).forEach(([discKey, niveles])=>{
    const disciplina = DISC_MAP[discKey] || discKey;
    Object.entries(niveles).forEach(([nivelKey, ids])=>{
      const nivel = parseInt(nivelKey.replace('nivel',''),10);
      ids.forEach((vid, i)=>{
        const url = `https://www.youtube.com/embed/${vid}`;
        const clave = `${disciplina}|${nivel}|${url}`;
        if (existentes.has(clave)) return; // ya sembrado en un arranque anterior
        existentes.add(clave);
        nuevos.push({
          titulo: `${disciplina} · Nivel ${nivel} · Clase ${i+1}`,
          disciplina, nivel, url,
          notas: '',
          orden: i+1
        });
      });
    });
  });

  if (!nuevos.length) return; // ya está todo sembrado, no hay nada que hacer

  try {
    for (const data of nuevos){ await apiJSON('POST','/api/videos',data); }
    await cargarDB(); // refrescar db.videos con los ids reales que asigna el servidor
  } catch(e){
    console.error('No se pudo sembrar el catálogo oficial de vídeos:', e);
  }
}

/* ── Vista INFORMES ── */
function renderInformes(cont){
  const mes=mesActual();
  cont.innerHTML=`<div class="h2">◷ Informes</div>
  <div class="stats-grid" id="dashCards"></div>
  <div class="card" style="margin-bottom:16px;">
    <div class="h2">Resumen por rango</div>
    <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;">
      <div><label class="label-field">Desde</label><input type="month" id="infDesde" value="${mes}" style="width:160px;"></div>
      <div><label class="label-field">Hasta</label><input type="month" id="infHasta" value="${mes}" style="width:160px;"></div>
      <button class="btn" onclick="calcInforme()">Calcular</button>
    </div>
    <div id="resultInforme" style="margin-top:14px;"></div>
  </div>
  <div class="card">
    <div class="h2">Exportar</div>
    <div style="display:flex;gap:10px;flex-wrap:wrap;">
      <button class="btn sec" onclick="exportCSV()">⬇ Pagos CSV</button>
      <button class="btn sec" onclick="exportBackup()">⬇ Copia JSON</button>
    </div>
  </div>`;
  const t=totalesMes(mes);
  const activos=(db.users||[]).filter(u=>u.active&&u.role==='student').length;
  $('dashCards').innerHTML=
    statCard('Alumnos activos',activos,'var(--gold)')+
    statCard('Pagos este mes',t.num,'var(--text-2)')+
    statCard('Total cobrado',eur(t.cobrado),'var(--ok)')+
    statCard('IVA a liquidar',eur(t.iva),'var(--warn)');
}

function totalesMes(mes){
  const t={cobrado:0,iva:0,base:0,malevo:0,box:0,num:0};
  (db.payments||[]).filter(p=>p.mes===mes).forEach(p=>{
    const n=numPagoDeUsuario(p.userId,p.mes,p.id);
    const r=calcularReparto(p.importe||0,n);
    t.cobrado+=r.importe;t.iva+=r.iva;t.base+=r.base;t.malevo+=r.malevo;t.box+=r.box;t.num++;
  });
  return t;
}

function calcInforme(){
  const desde=$('infDesde').value, hasta=$('infHasta').value;
  if (!desde||!hasta){alert('Selecciona rango.');return;}
  const t={cobrado:0,iva:0,base:0,malevo:0,box:0,num:0};
  (db.payments||[]).filter(p=>p.mes>=desde&&p.mes<=hasta).forEach(p=>{
    const n=numPagoDeUsuario(p.userId,p.mes,p.id);
    const r=calcularReparto(p.importe||0,n);
    t.cobrado+=r.importe;t.iva+=r.iva;t.base+=r.base;t.malevo+=r.malevo;t.box+=r.box;t.num++;
  });
  $('resultInforme').innerHTML=`<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin-top:8px;">
    ${statCard('Pagos',t.num,'var(--text-2)')}
    ${statCard('Total cobrado',eur(t.cobrado),'var(--ok)')}
    ${statCard('IVA',eur(t.iva),'var(--warn)')}
    ${statCard('Base',eur(t.base),'var(--text-2)')}
    ${statCard('Malevo',eur(t.malevo),'var(--ok)')}
    ${statCard('The Box',eur(t.box),'var(--gold)')}
  </div>`;
}

function exportCSV(){
  const cab=['Mes','Alumno','FechaCobro','Cobrado','Base','IVA','Malevo','TheBox','Metodo'];
  const f=x=>(Math.round(x*100)/100).toString().replace('.',',');
  const rows=(db.payments||[]).sort((a,b)=>a.mes.localeCompare(b.mes)).map(p=>{
    const n=numPagoDeUsuario(p.userId,p.mes,p.id);
    const r=calcularReparto(p.importe||0,n);
    return [p.mes,nombreUsuario(p.userId),p.fechaPago,f(r.importe),f(r.base),f(r.iva),f(r.malevo),f(r.box),p.metodo||'']
      .map(c=>`"${String(c).replace(/"/g,'""')}"`).join(';');
  });
  descargar(`pagos_malevo_${hoy()}.csv`,'\ufeff'+cab.join(';')+'\n'+rows.join('\n'),'text/csv;charset=utf-8');
}
function exportBackup(){ descargar(`backup_malevo_${hoy()}.json`,JSON.stringify(db,null,2),'application/json'); }
function descargar(nombre,contenido,tipo){
  const a=document.createElement('a');
  a.href=URL.createObjectURL(new Blob([contenido],{type:tipo}));
  a.download=nombre; a.click(); URL.revokeObjectURL(a.href);
}

/* ── Vista CONFIG ── */
function renderConfig(cont){
  const c=db.config;
  cont.innerHTML=`
  <div class="h2">⚙ Configuración</div>

  <!-- ── Pestañas de configuración ── -->
  <div style="display:flex;gap:3px;margin-bottom:22px;flex-wrap:wrap;" id="cfgTabsBar">
    ${['negocio','tarifas','resumen','reparto','gestora','reset'].map(function(t,i){
      const labels={negocio:'🏢 Negocio',tarifas:'💰 Tarifas',resumen:'📊 Resumen',reparto:'⇄ Reparto con The Box',gestora:'📋 Gestora',reset:'⚠ Reset'};
      return '<button onclick="cfgTab(\'' + t + '\')" data-cfgtab="' + t + '"'
        + ' style="padding:9px 20px;border-radius:30px;border:1px solid rgba(255,215,0,' + (i===0?'.40':'.15') + ');'
        + ' background:' + (i===0?'linear-gradient(135deg,rgba(255,215,0,.22),rgba(138,112,0,.14))':'rgba(255,255,255,.04)') + ';'
        + ' color:' + (i===0?'var(--gold-2)':'var(--muted)') + ';font-weight:' + (i===0?'600':'500') + ';'
        + ' font-size:13px;font-family:inherit;cursor:pointer;transition:all .2s;'
        + (i===0?' box-shadow:0 0 14px var(--gold-glow);':'')
        + '">'
        + labels[t]
        + '</button>';
    }).join('')}
  </div>

  <!-- ── Panel: Negocio ── -->
  <div id="cfgPanel-negocio" class="card" style="margin-bottom:16px;">
    <h3 style="font-family:'Sora',sans-serif;font-size:15px;font-weight:700;margin-bottom:4px;color:var(--gold-2);">Datos fiscales del negocio</h3>
    <p style="color:var(--muted);font-size:12px;line-height:1.6;margin-bottom:20px;">
      Estos datos aparecen como cabecera emisor en todas las facturas. No deben incluir referencias a terceros.</p>

    <!-- Logo -->
    <label class="label-field">Logotipo (aparece en cabecera de facturas)</label>
    <div style="display:flex;align-items:center;gap:16px;margin-bottom:6px;flex-wrap:wrap;">
      <div id="logoPreview" style="width:96px;height:64px;border-radius:var(--r-sm);
        border:1px dashed var(--border-2);background:var(--surface-2);
        display:flex;align-items:center;justify-content:center;overflow:hidden;flex:0 0 auto;">
        ${c.negocio?.logo
          ? `<img src="${c.negocio.logo}" style="max-width:100%;max-height:100%;object-fit:contain;">`
          : `<span style="color:var(--muted);font-size:11px;text-align:center;padding:6px;">Sin logo</span>`}
      </div>
      <div style="flex:1;min-width:180px;">
        <label style="display:inline-flex;align-items:center;gap:8px;padding:9px 16px;
          border-radius:var(--r-sm);border:1px solid var(--border-2);cursor:pointer;
          font-size:12.5px;font-weight:600;color:var(--text-2);background:var(--surface-2);
          transition:all .2s;"
          onmouseover="this.style.borderColor='var(--gold)';this.style.color='var(--gold-2)'"
          onmouseout="this.style.borderColor='var(--border-2)';this.style.color='var(--text-2)'">
          📁 Seleccionar imagen
          <input type="file" id="cfgLogoFile" accept="image/*" style="display:none;" onchange="previsualizarLogo(this)">
        </label>
        <div style="font-size:11px;color:var(--muted);margin-top:6px;">PNG, JPG o SVG · Máx. 200 KB · Fondo claro recomendado</div>
        ${c.negocio?.logo ? `<button onclick="eliminarLogo()" class="btn sm sec warn"
          style="margin-top:6px;padding:5px 10px;font-size:11px;">✕ Eliminar logo</button>` : ''}
      </div>
    </div>
    <input type="hidden" id="cfgLogoData" value="${c.negocio?.logo ? '1' : ''}">

    <!-- Datos principales -->
    <label class="label-field">Nombre / Razón social *</label>
    <input type="text" id="cfgNombre" value="${esc(c.negocio?.nombre||'')}" placeholder="Ej: Academia de Baile Malevo">

    <div class="g2">
      <div>
        <label class="label-field">NIF / DNI *</label>
        <input type="text" id="cfgNif" value="${esc(c.negocio?.nif||'')}" placeholder="Ej: 12345678A">
      </div>
      <div>
        <label class="label-field">Teléfono de contacto</label>
        <input type="tel" id="cfgTelefono" value="${esc(c.negocio?.telefono||'')}" placeholder="Ej: 688 734 909">
      </div>
    </div>

    <label class="label-field">Email de contacto</label>
    <input type="email" id="cfgEmail" value="${esc(c.negocio?.email||'')}" placeholder="Ej: info@academiamalevo.com">

    <label class="label-field">Dirección fiscal completa</label>
    <input type="text" id="cfgDir" value="${esc(c.negocio?.direccion||'')}" placeholder="Ej: Calle Mayor 10, 28001 Madrid">

    <label class="label-field">Pie de factura (texto opcional)</label>
    <input type="text" id="cfgPie" value="${esc(c.negocio?.pie||'')}" placeholder="Ej: Gracias por bailar con nosotros 💃">

    <div style="margin-top:22px;display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
      <button class="btn" onclick="guardarNegocio()">Guardar datos fiscales</button>
      <small style="color:var(--muted);font-size:11.5px;">* Obligatorios para facturas válidas</small>
    </div>

    <!-- Enlace de invitación WhatsApp — dentro del panel Negocio -->
    <div style="margin-top:24px;padding-top:20px;border-top:1px solid var(--border);">
      <h3 style="font-family:'Sora',sans-serif;font-size:14px;font-weight:700;
        color:var(--gold-2);margin-bottom:4px;display:flex;align-items:center;gap:8px;">
        📲 Enviar enlace de acceso
        <span style="background:var(--ok-soft);color:var(--ok);border:1px solid rgba(255,215,0,.2);
          padding:2px 10px;border-radius:30px;font-size:10px;font-weight:600;letter-spacing:.3px;">
          Captación automática
        </span>
      </h3>
      <p style="color:var(--muted);font-size:12.5px;line-height:1.6;margin-bottom:14px;max-width:480px;">
        Copia este enlace y envíalo por WhatsApp a cualquier persona interesada.
        Al abrirlo, se registrará y realizará el primer pago antes de acceder a los contenidos.</p>

      <div id="inviteLinkWrap" style="display:none;">
        <div style="display:flex;gap:10px;align-items:center;margin-bottom:12px;">
          <input type="text" id="inviteLink" readonly
            style="background:rgba(255,215,0,.06);border-color:rgba(255,215,0,.25);
              color:var(--gold-light);font-size:12.5px;cursor:pointer;font-family:monospace;"
            onclick="this.select()">
          <button class="btn sm" onclick="copiarEnlaceInvitacion()" id="btnCopyInvite"
            style="flex:0 0 auto;padding:9px 14px;">📋 Copiar</button>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
          <button class="btn" onclick="compartirEnlaceWhatsApp()"
            style="background:linear-gradient(135deg,#25d366,#128c7e);box-shadow:0 4px 14px rgba(37,211,102,.30);">
            💬 Compartir por WhatsApp
          </button>
          <button class="btn sec sm" onclick="regenerarEnlaceInvitacion()"
            style="font-size:11.5px;padding:9px 14px;">🔄 Regenerar enlace</button>
        </div>
        <p style="color:var(--muted);font-size:11.5px;margin-top:12px;line-height:1.6;">
          ⚠ Si regeneras el enlace, el anterior quedará inválido.</p>
      </div>
      <div id="inviteLinkLoading" style="color:var(--muted);font-size:13px;">
        Cargando enlace…
      </div>
    </div>
  </div>

  <!-- ── Panel: Tarifas (lista editable) ── -->
  <div id="cfgPanel-tarifas" class="card" style="display:none;margin-bottom:16px;">
    <h3 style="font-family:'Sora',sans-serif;font-size:15px;font-weight:700;margin-bottom:6px;color:var(--gold-2);">Tarifas de clases</h3>
    <p style="color:var(--muted);font-size:12.5px;margin-bottom:20px;line-height:1.6;">
      Edita el nombre y precio de cada tarifa. Las marcadas con 🎓 incluyen acceso al Aula Virtual.</p>
    <div id="tarifasList" style="display:flex;flex-direction:column;gap:10px;">
      ${[
        {k:'suelta', nombre:'Clase suelta',          portal:false, desc:'Una clase individual, sin cuota'},
        {k:'35',     nombre:'1 clase / semana',       portal:true,  desc:'Cuota mensual · acceso al aula virtual'},
        {k:'50',     nombre:'2 clases / semana',      portal:true,  desc:'Cuota mensual · acceso al aula virtual'},
        {k:'80',     nombre:'VIP / Full Pass',        portal:true,  desc:'Clases ilimitadas · acceso al aula virtual'},
        {k:'bono',   nombre:'Bono 10 clases',         portal:false, desc:'Flexible, sin caducidad'},
      ].map(p=>`
        <div style="display:flex;align-items:center;gap:12px;padding:14px 18px;
          background:rgba(255,255,255,.04);border:1px solid rgba(255,215,0,.14);
          border-radius:var(--r-sm);transition:all .2s;"
          onmouseover="this.style.borderColor='rgba(255,215,0,.30)'"
          onmouseout="this.style.borderColor='rgba(255,215,0,.14)'">
          <div style="flex:0 0 32px;height:32px;border-radius:9px;
            background:${p.portal?'linear-gradient(135deg,rgba(255,215,0,.25),rgba(138,112,0,.15))':'rgba(255,255,255,.06)'};
            border:1px solid rgba(255,215,0,.${p.portal?'30':'12'});
            display:flex;align-items:center;justify-content:center;font-size:14px;">
            ${p.portal?'🎓':'📋'}
          </div>
          <div style="flex:1;min-width:0;">
            <input type="text" id="tNombre_${p.k}" value="${esc(p.nombre)}"
              style="width:100%;background:transparent;border:none;border-bottom:1px solid rgba(255,215,0,.20);
                border-radius:0;padding:4px 2px;font-size:14px;font-weight:600;color:var(--text);
                box-shadow:none;margin-bottom:3px;"
              onfocus="this.style.borderBottomColor='var(--gold)';this.style.boxShadow='none'"
              onblur="this.style.borderBottomColor='rgba(255,215,0,.20)'">
            <div style="font-size:11px;color:var(--muted);">${p.desc}${p.portal?' · <span style="color:var(--gold-2);">Portal incluido</span>':''}</div>
          </div>
          <div style="display:flex;align-items:center;gap:8px;flex:0 0 auto;">
            <input type="number" id="tPrecio_${p.k}" value="${c.precios[p.k]??0}" step="0.01" min="0"
              style="width:90px;text-align:right;font-size:15px;font-weight:700;color:var(--gold-2);
                background:rgba(255,215,0,.08);border:1px solid rgba(255,215,0,.22);border-radius:8px;padding:8px 10px;">
            <span style="color:var(--muted);font-size:13px;">€</span>
          </div>
        </div>`).join('')}
    </div>
    <div style="margin-top:22px;display:flex;align-items:center;gap:12px;">
      <button class="btn" onclick="guardarTarifas()">Guardar tarifas</button>
      <small style="color:var(--muted);font-size:12px;">🎓 = Acceso al Aula Virtual incluido</small>
    </div>
  </div>

  <!-- ── Panel: Reparto con The Box ── -->
  <div id="cfgPanel-reparto" class="card" style="display:none;margin-bottom:16px;">
    <h3 style="font-family:'Sora',sans-serif;font-size:15px;font-weight:700;margin-bottom:6px;color:var(--gold-2);">Reparto con The Box</h3>
    <p style="color:var(--muted);font-size:12.5px;margin-bottom:20px;line-height:1.6;">
      El reparto se calcula sobre la <strong style="color:var(--text-2);">base imponible</strong> (precio sin IVA).
      Los primeros meses usan el reparto inicial; a partir del mes configurado, el posterior.</p>

    <!-- IVA -->
    <div class="g2" style="margin-bottom:18px;">
      <div><label class="label-field">IVA aplicado (%)</label>
        <input type="number" id="cfgIva" value="${c.iva}" step="0.01" min="0" max="100"></div>
      <div><label class="label-field">Meses con reparto inicial</label>
        <input type="number" id="cfgMesesIni" value="${c.mesesIniciales}" min="0"></div>
    </div>

    <!-- Tarjetas de reparto visual -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:8px;">
      <!-- Inicial -->
      <div style="background:rgba(255,215,0,.07);border:1px solid rgba(255,215,0,.22);
        border-radius:var(--r-lg);padding:20px;">
        <div style="font-size:10px;text-transform:uppercase;letter-spacing:1.5px;color:var(--muted);margin-bottom:14px;font-weight:700;">
          Primeros ${c.mesesIniciales||3} meses</div>
        <div style="display:flex;gap:10px;align-items:flex-end;margin-bottom:12px;">
          <div style="flex:1;">
            <div style="font-size:11px;color:var(--muted);margin-bottom:5px;">Malevo</div>
            <input type="number" id="cfgIniMalevo" value="${c.inicial.malevo}" step="0.1" min="0" max="100"
              oninput="syncBox('IniBox','IniMalevo')"
              style="font-size:22px;font-weight:700;color:var(--gold-2);background:transparent;
                border:none;border-bottom:2px solid var(--gold);border-radius:0;padding:4px 2px;
                width:80px;text-align:center;box-shadow:none;">
          </div>
          <div style="color:var(--muted);font-size:20px;padding-bottom:8px;">+</div>
          <div style="flex:1;">
            <div style="font-size:11px;color:var(--muted);margin-bottom:5px;">The Box</div>
            <input type="number" id="cfgIniBox" value="${c.inicial.box}" step="0.1" min="0" max="100"
              oninput="syncBox('IniMalevo','IniBox')"
              style="font-size:22px;font-weight:700;color:var(--text-2);background:transparent;
                border:none;border-bottom:2px solid rgba(255,255,255,.25);border-radius:0;padding:4px 2px;
                width:80px;text-align:center;box-shadow:none;">
          </div>
          <div style="color:var(--muted);font-size:14px;padding-bottom:10px;">= 100%</div>
        </div>
        <div id="barIni" style="height:8px;border-radius:4px;background:rgba(255,255,255,.08);overflow:hidden;margin-top:6px;">
          <div id="barIniMalevo" style="height:100%;width:${c.inicial.malevo}%;
            background:linear-gradient(90deg,var(--gold),var(--gold-2));border-radius:4px;transition:.3s;"></div>
        </div>
        <div style="display:flex;justify-content:space-between;margin-top:6px;font-size:11px;color:var(--muted);">
          <span style="color:var(--gold-2);">Malevo ${c.inicial.malevo}%</span>
          <span>The Box ${c.inicial.box}%</span>
        </div>
      </div>
      <!-- Posterior -->
      <div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.10);
        border-radius:var(--r-lg);padding:20px;">
        <div style="font-size:10px;text-transform:uppercase;letter-spacing:1.5px;color:var(--muted);margin-bottom:14px;font-weight:700;">
          Meses siguientes</div>
        <div style="display:flex;gap:10px;align-items:flex-end;margin-bottom:12px;">
          <div style="flex:1;">
            <div style="font-size:11px;color:var(--muted);margin-bottom:5px;">Malevo</div>
            <input type="number" id="cfgPostMalevo" value="${c.posterior.malevo}" step="0.1" min="0" max="100"
              oninput="syncBox('PostBox','PostMalevo')"
              style="font-size:22px;font-weight:700;color:var(--gold-2);background:transparent;
                border:none;border-bottom:2px solid var(--gold);border-radius:0;padding:4px 2px;
                width:80px;text-align:center;box-shadow:none;">
          </div>
          <div style="color:var(--muted);font-size:20px;padding-bottom:8px;">+</div>
          <div style="flex:1;">
            <div style="font-size:11px;color:var(--muted);margin-bottom:5px;">The Box</div>
            <input type="number" id="cfgPostBox" value="${c.posterior.box}" step="0.1" min="0" max="100"
              oninput="syncBox('PostMalevo','PostBox')"
              style="font-size:22px;font-weight:700;color:var(--text-2);background:transparent;
                border:none;border-bottom:2px solid rgba(255,255,255,.25);border-radius:0;padding:4px 2px;
                width:80px;text-align:center;box-shadow:none;">
          </div>
          <div style="color:var(--muted);font-size:14px;padding-bottom:10px;">= 100%</div>
        </div>
        <div id="barPost" style="height:8px;border-radius:4px;background:rgba(255,255,255,.08);overflow:hidden;margin-top:6px;">
          <div id="barPostMalevo" style="height:100%;width:${c.posterior.malevo}%;
            background:linear-gradient(90deg,var(--gold),var(--gold-2));border-radius:4px;transition:.3s;"></div>
        </div>
        <div style="display:flex;justify-content:space-between;margin-top:6px;font-size:11px;color:var(--muted);">
          <span style="color:var(--gold-2);">Malevo ${c.posterior.malevo}%</span>
          <span>The Box ${c.posterior.box}%</span>
        </div>
      </div>
    </div>
    <div style="margin-top:20px;"><button class="btn" onclick="guardarConfig()">Guardar reparto</button></div>
  </div>

  <!-- ── Panel: Resumen (Fiscalidad) ── -->
  <div id="cfgPanel-resumen" style="display:none;margin-bottom:16px;">

    <!-- Calendario fiscal -->
    <div class="h2" style="margin-bottom:14px;">📅 Calendario fiscal</div>
    <div id="cfgCalFiscal" style="margin-bottom:28px;"></div>

    <!-- Resumen del mes con selector -->
    <div style="display:flex;align-items:center;justify-content:space-between;
      flex-wrap:wrap;gap:10px;margin-bottom:12px;">
      <div class="h2" style="margin-bottom:0;">€ Resumen del mes</div>
      <input type="month" id="resumMesSel" value="${mesActual()}"
        onchange="actualizarResumenMes()"
        style="width:190px;padding:7px 12px;font-size:13px;">
    </div>
    <div id="resumStats"
      style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin-bottom:24px;"></div>

    <!-- Reparto del mes -->
    <div class="h2" style="margin-bottom:12px;">⇄ Reparto del mes</div>
    <div id="resumReparto"
      style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin-bottom:4px;"></div>

  </div>

  <!-- ── Panel: Gestora ── -->
  <div id="cfgPanel-gestora" class="card" style="display:none;margin-bottom:16px;">
    <h3 style="font-family:'Sora',sans-serif;font-size:15px;font-weight:700;
      color:var(--gold-2);margin-bottom:6px;">📋 Documentación para la gestora</h3>
    <p style="color:var(--muted);font-size:12.5px;line-height:1.6;margin-bottom:22px;">
      Listado completo de facturas emitidas con descarga individual y generación del informe trimestral.
      <strong style="color:var(--text-2);">Ningún documento menciona a terceros.</strong></p>

    <!-- Filtros -->
    <div style="display:flex;gap:12px;align-items:flex-end;flex-wrap:wrap;margin-bottom:20px;">
      <div>
        <label class="label-field">Filtrar por trimestre</label>
        <select id="gestoraTrim" onchange="document.getElementById('gestoraFactMes').value='';actualizarGestora();" style="width:220px;">
          <option value="">— Todos los períodos —</option>
          ${(()=>{
            const now = new Date();
            const y   = now.getFullYear();
            const opts = [];
            for(let yr=y; yr>=y-1; yr--){
              [[1,'Enero – Marzo','01','03'],[2,'Abril – Junio','04','06'],
               [3,'Julio – Septiembre','07','09'],[4,'Octubre – Diciembre','10','12']]
              .reverse().forEach(([n,label,mI,mF])=>{
                opts.push(`<option value="${yr}-${mI}|${yr}-${mF}">${yr} · ${n}T — ${label}</option>`);
              });
            }
            return opts.join('');
          })()}
        </select>
      </div>
      <div>
        <label class="label-field">O mes concreto</label>
        <select id="gestoraFactMes" onchange="document.getElementById('gestoraTrim').value='';actualizarGestora();" style="width:190px;">
          <option value="">— Todos —</option>
          ${(()=>{
            const opts=[];
            const now=new Date();
            for(let m=11;m>=0;m--){
              const d=new Date(now.getFullYear(),now.getMonth()-m,1);
              const val=d.toISOString().slice(0,7);
              const label=d.toLocaleDateString('es-ES',{month:'long',year:'numeric'});
              opts.push('<option value="'+val+'">'+label.charAt(0).toUpperCase()+label.slice(1)+'</option>');
            }
            return opts.join('');
          })()}
        </select>
      </div>
      <button class="btn sm sec" onclick="document.getElementById('gestoraTrim').value='';document.getElementById('gestoraFactMes').value='';actualizarGestora();">
        Ver todos
      </button>
    </div>

    <!-- Tabla de facturas -->
    <div id="gestoraListaFacturas"></div>

    <!-- Acciones de descarga -->
    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:20px;padding-top:18px;
      border-top:1px solid var(--border);">
      <button class="btn" onclick="descargarFacturasMes()">
        Descargar facturas del período (.zip)
      </button>
      <button class="btn gold" onclick="generarInformeTrimestral()">
        Informe trimestral PDF
      </button>
    </div>
  </div>

  <!-- ── Panel: Reset ── -->
  <div id="cfgPanel-reset" class="card" style="display:none;">
    <h3 style="font-family:'Sora',sans-serif;font-size:15px;font-weight:700;margin-bottom:8px;color:var(--warn);">Reset de fábrica</h3>
    <p style="color:var(--muted);font-size:13px;margin-bottom:18px;line-height:1.6;">
      Borra por completo la base de datos: usuarios, pagos, inscripciones y vídeos.<br>
      <strong style="color:var(--warn);">Esta acción es irreversible.</strong></p>
    <button class="btn warn" onclick="vaciarTodo()">🗑 Vaciar toda la base de datos</button>
  </div>`;

  // Activar primera pestaña
  cfgTab('negocio');
}

/* ── Resumen: actualizar stats y reparto al cambiar mes ── */
function actualizarResumenMes(){
  const sel    = $('resumMesSel');
  const mes    = sel ? sel.value : mesActual();
  const t      = totalesMes(mes);
  const activos= (db.users||[]).filter(u=>u.active&&u.role==='student').length;

  const statsWrap = $('resumStats');
  if(statsWrap){
    statsWrap.innerHTML =
      statCard('Alumnos activos',    activos,       'var(--gold)')  +
      statCard('Pagos registrados',  t.num,         'var(--text-2)')+
      statCard('Total cobrado',      eur(t.cobrado),'var(--ok)')    +
      statCard('IVA a liquidar',     eur(t.iva),    'var(--warn)');
  }

  const repartoWrap = $('resumReparto');
  if(repartoWrap){
    repartoWrap.innerHTML =
      statCard('Base (sin IVA)',  eur(t.base),   'var(--text-2)') +
      statCard('Ingreso neto',    eur(t.malevo), 'var(--ok)')     +
      statCard('IVA repercutido', eur(t.iva),    'var(--warn)');
  }
}

/* ── Datos fiscales del negocio ── */
function previsualizarLogo(input){
  const file = input.files[0];
  if(!file) return;
  if(file.size > 200*1024){ showToast('El archivo supera los 200 KB','warn'); input.value=''; return; }
  const reader = new FileReader();
  reader.onload = e => {
    const src = e.target.result;
    const preview = $('logoPreview');
    if(preview) preview.innerHTML = `<img src="${src}" style="max-width:100%;max-height:100%;object-fit:contain;">`;
    // Guardar base64 en campo oculto para que guardarNegocio lo recoja
    const hidden = $('cfgLogoData');
    if(hidden) hidden.value = src;
    db.config.negocio = db.config.negocio || {};
    db.config.negocio.logo = src;
  };
  reader.readAsDataURL(file);
}

function eliminarLogo(){
  if(!confirm('¿Eliminar el logo?')) return;
  db.config.negocio = db.config.negocio || {};
  db.config.negocio.logo = '';
  const preview = $('logoPreview');
  if(preview) preview.innerHTML = '<span style="color:var(--muted);font-size:11px;text-align:center;padding:6px;">Sin logo</span>';
  const hidden = $('cfgLogoData');
  if(hidden) hidden.value = '';
  guardar();
  actualizarLogoHeader();
  showToast('Logo eliminado','ok');
}

async function guardarNegocio(){
  db.config.negocio = {
    nombre:    ($('cfgNombre')?.value||'').trim() || 'Academia de Baile Malevo',
    nif:       ($('cfgNif')?.value||'').trim(),
    telefono:  ($('cfgTelefono')?.value||'').trim(),
    email:     ($('cfgEmail')?.value||'').trim(),
    direccion: ($('cfgDir')?.value||'').trim(),
    pie:       ($('cfgPie')?.value||'').trim(),
    logo:      db.config.negocio?.logo || '',
  };
  // Si hay un nuevo logo en el campo oculto, ya está en db.config.negocio.logo
  // (lo actualiza previsualizarLogo en tiempo real)
  guardar();
  actualizarLogoHeader();
  confirmSave('Datos fiscales guardados');
}

/* ── Enlace general de invitación ── */
async function cargarEnlaceInvitacion(){
  const wrap    = $('inviteLinkWrap');
  const loading = $('inviteLinkLoading');
  const inp     = $('inviteLink');
  if (!wrap || !inp) return;
  if (inp.value) return; // ya cargado
  try {
    const r = await fetch('/api/invite-link', { credentials:'same-origin' });
    if (!r.ok) throw new Error();
    const { link } = await r.json();
    inp.value = link;
    if (loading) loading.style.display = 'none';
    wrap.style.display = 'block';
  } catch { if (loading) loading.textContent = 'No se pudo cargar el enlace.'; }
}

async function copiarEnlaceInvitacion(){
  const inp = $('inviteLink');
  if (!inp) return;
  try {
    await navigator.clipboard.writeText(inp.value);
    showToast('Enlace copiado al portapapeles','ok');
  } catch {
    inp.select(); document.execCommand('copy');
    showToast('Enlace copiado','ok');
  }
}

function compartirEnlaceWhatsApp(){
  const inp = $('inviteLink');
  if (!inp) return;
  const msg = '¡Te invitamos a unirte a la Academia de Baile Malevo! 🕺💃\nApúntate aquí: ' + inp.value;
  window.open('https://wa.me/?text=' + encodeURIComponent(msg), '_blank');
}

async function regenerarEnlaceInvitacion(){
  if (!confirm('¿Regenerar el enlace? El enlace anterior quedará inválido.')) return;
  try {
    const r = await fetch('/api/invite-link', { method:'PUT', credentials:'same-origin' });
    if (!r.ok) throw new Error();
    const { link } = await r.json();
    const inp = $('inviteLink');
    if (inp) inp.value = link;
    showToast('Nuevo enlace generado','ok');
  } catch { showToast('Error al regenerar el enlace','warn'); }
}

/* ── Cambiar pestaña config ── */
function cfgTab(tab){
  ['negocio','tarifas','resumen','reparto','gestora','reset'].forEach(t=>{
    const panel=$(`cfgPanel-${t}`);
    if(panel) panel.style.display = t===tab ? '' : 'none';
  });
  document.querySelectorAll('[data-cfgtab]').forEach(btn=>{
    const active = btn.dataset.cfgtab===tab;
    btn.style.background = active
      ? 'linear-gradient(135deg,rgba(255,215,0,.22),rgba(138,112,0,.14))'
      : 'rgba(255,255,255,.04)';
    btn.style.color  = active ? 'var(--gold-2)' : 'var(--muted)';
    btn.style.fontWeight = active ? '600' : '500';
    btn.style.borderColor = active ? 'rgba(255,215,0,.40)' : 'rgba(255,215,0,.15)';
    btn.style.boxShadow = active ? '0 0 14px var(--gold-glow)' : 'none';
  });
  if(tab==='resumen') { renderCalFiscal(); actualizarResumenMes(); }
  if(tab==='negocio') cargarEnlaceInvitacion();
  if(tab==='gestora') actualizarGestora();
  playClick();
}

/* ── Calendario fiscal ── */
function renderCalFiscal(){
  const cont = $('cfgCalFiscal');
  if(!cont) return;

  const now  = new Date();
  const year = now.getFullYear();
  const mes  = now.getMonth(); // 0-based

  // ── Calcular el trimestre activo para 130 y 303 ───────────────────────────
  // Plazos: 1T → 20 abril, 2T → 20 julio, 3T → 20 octubre, 4T → 30 enero(año+1)
  // Lógica: mostramos el trimestre cuyo plazo está más próximo (futuro) o el
  // último si ya pasaron todos en el año.
  const PLAZOS_TRIM = [
    {q:'1T', mes:3, dia:20, ini:[0],   fin:[2]},   // Jan-Mar → presenta en abr
    {q:'2T', mes:6, dia:20, ini:[3],   fin:[5]},   // Apr-Jun → presenta en jul
    {q:'3T', mes:9, dia:20, ini:[6],   fin:[8]},   // Jul-Sep → presenta en oct
    {q:'4T', mes:1, dia:30, ini:[9],   fin:[11], year:1}, // Oct-Dic → presenta en ene
  ];

  // Encuentra el plazo más próximo (futuro) o el último pasado
  let trimActivo = PLAZOS_TRIM[PLAZOS_TRIM.length-1];
  for(const pt of PLAZOS_TRIM){
    const dl = new Date(year + (pt.year||0), pt.mes, pt.dia);
    if(dl >= now){ trimActivo = pt; break; }
  }

  // Rangos de meses del trimestre activo para calcular importes
  const triYear = year - (trimActivo.year||0); // año fiscal del trimestre
  const mesIniStr = `${triYear}-${String(trimActivo.ini[0]+1).padStart(2,'0')}`;
  const mesFinStr = `${triYear}-${String(trimActivo.fin[0]+1).padStart(2,'0')}`;

  const deadlineTrim = new Date(year + (trimActivo.year||0), trimActivo.mes, trimActivo.dia);
  const diffTrim = Math.ceil((deadlineTrim - now) / 86400000);
  const pasadoTrim = diffTrim < 0;
  const urgenteTrim = !pasadoTrim && diffTrim <= 15;

  // ── Calcular importes del trimestre activo ────────────────────────────────
  const pagosTrim = (db.payments||[]).filter(p => p.mes && p.mes >= mesIniStr && p.mes <= mesFinStr);

  let ivaTrim = 0;
  let baseIRPF = 0;
  pagosTrim.forEach(pg => {
    const r = calcularReparto(pg.importe||0, numPagoDeUsuario(pg.userId, pg.mes, pg.id));
    ivaTrim  += r.iva;
    baseIRPF += r.malevo;
  });
  const irpfTrim = baseIRPF * 0.20;

  // ── Calcular Renta anual (año anterior) ───────────────────────────────────
  const yearRenta = year - 1; // declaración del año pasado
  const deadlineRenta = new Date(year, 5, 30); // 30 junio del año en curso
  const diffRenta = Math.ceil((deadlineRenta - now) / 86400000);
  const pasadoRenta = diffRenta < 0;
  const urgenteRenta = !pasadoRenta && diffRenta <= 15;

  const pagosRenta = (db.payments||[]).filter(p => p.mes && p.mes.startsWith(String(yearRenta)));
  let baseRenta = 0;
  pagosRenta.forEach(pg => {
    const r = calcularReparto(pg.importe||0, numPagoDeUsuario(pg.userId, pg.mes, pg.id));
    baseRenta += r.malevo;
  });

  // ── Construir tarjeta ─────────────────────────────────────────────────────
  function pill(pasado, urgente, dias){
    if(pasado)  return `<span style="display:inline-block;padding:4px 12px;border-radius:30px;font-size:12px;font-weight:600;background:var(--surface-2);color:var(--muted);border:1px solid var(--border);">Vencido</span>`;
    if(urgente) return `<span style="display:inline-block;padding:4px 12px;border-radius:30px;font-size:12px;font-weight:600;background:var(--warn-soft);color:var(--warn);border:1px solid rgba(224,92,92,.3);">¡Faltan ${dias} día${dias===1?'':'s'}!</span>`;
    return `<span style="display:inline-block;padding:4px 12px;border-radius:30px;font-size:12px;font-weight:600;background:var(--accent-soft);color:var(--accent-2);border:1px solid rgba(255,215,0,.25);">Faltan ${dias} días</span>`;
  }

  function alerta(urgente, dias){
    if(!urgente) return '';
    return `<div style="margin:14px 0 0;padding:10px 14px;border-radius:var(--r-sm);
      background:var(--warn-soft);border:1px solid rgba(224,92,92,.3);
      display:flex;align-items:center;gap:10px;">
      <span style="font-size:16px;">⚠️</span>
      <div style="font-size:12.5px;font-weight:700;color:var(--warn);">
        Quedan ${dias} día${dias===1?'':'s'} — Prepara la documentación
      </div>
    </div>`;
  }

  function bigCard({tipo, modelo, nombre, color, importe, deadline, pasado, urgente, diffDays, q, desc}){
    const dateStr = deadline.toLocaleDateString('es-ES',{day:'numeric',month:'long',year:'numeric'});
    return `<div style="padding:22px 24px;border-radius:var(--r-lg);
      background:var(--surface);border:1px solid var(--border);margin-bottom:12px;">
      <div style="font-size:10.5px;font-weight:600;letter-spacing:1.2px;
        text-transform:uppercase;color:var(--muted);margin-bottom:8px;">
        ${tipo} · Modelo ${modelo}${q?' · '+q:''}
      </div>
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:16px;">
        <div>
          <div style="font-family:'Sora',sans-serif;font-size:20px;font-weight:700;
            color:var(--text);margin-bottom:6px;">${nombre}</div>
          <div style="font-size:13px;color:${color};font-weight:600;margin-bottom:10px;">
            ${pasado?'Hasta el ':''}${dateStr}
          </div>
          ${pill(pasado, urgente, diffDays)}
        </div>
        <div style="font-family:'Sora',sans-serif;font-size:28px;font-weight:800;
          color:${color};white-space:nowrap;padding-top:4px;">
          ${eur(importe)}
        </div>
      </div>
      ${alerta(urgente, diffDays)}
      <div style="margin-top:14px;padding-top:12px;border-top:1px solid var(--border);
        font-size:12px;color:var(--muted);line-height:1.6;">${desc}</div>
    </div>`;
  }

  // ── Las tres tarjetas fijas ───────────────────────────────────────────────
  const card130 = bigCard({
    tipo:'IRPF', modelo:'130', nombre:'Pago fraccionado IRPF', color:'var(--gold)',
    importe: irpfTrim, deadline: deadlineTrim, pasado: pasadoTrim,
    urgente: urgenteTrim, diffDays: diffTrim, q: trimActivo.q,
    desc: `Estimación: 20% del beneficio del ${trimActivo.q} (${mesIniStr.slice(5,7)}/${triYear}–${mesFinStr.slice(5,7)}/${triYear}). Orientativo; no incluye gastos deducibles.`,
  });

  const card303 = bigCard({
    tipo:'IVA', modelo:'303', nombre:'IVA trimestral', color:'var(--warn)',
    importe: ivaTrim, deadline: deadlineTrim, pasado: pasadoTrim,
    urgente: urgenteTrim, diffDays: diffTrim, q: trimActivo.q,
    desc: `A liquidar del ${trimActivo.q}. Es el IVA cobrado en las cuotas; resta el IVA de tus gastos antes de presentar.`,
  });

  const card100 = bigCard({
    tipo:'IRPF', modelo:'100', nombre:'Declaración de la Renta', color:'var(--gold-2)',
    importe: baseRenta, deadline: deadlineRenta, pasado: pasadoRenta,
    urgente: urgenteRenta, diffDays: diffRenta, q: `Anual ${yearRenta}`,
    desc: `Ingresos netos de ${yearRenta}. Campaña abril–junio ${year}. El resultado depende de retenciones, gastos y deducciones.`,
  });

  // ── Histórico (todos los plazos del año, colapsado) ───────────────────────
  const ITEMS_HIST = [
    { tipo:'IRPF', modelo:'130', nombre:'Pago fraccionado IRPF', color:'var(--gold)',
      plazos: PLAZOS_TRIM },
    { tipo:'IVA', modelo:'303', nombre:'IVA trimestral', color:'var(--warn)',
      plazos: PLAZOS_TRIM },
  ];
  let htmlResto = '';
  ITEMS_HIST.forEach(item => {
    item.plazos.forEach(pt => {
      if(pt.q === trimActivo.q) return; // ya está en las tarjetas principales
      const dl = new Date(year + (pt.year||0), pt.mes, pt.dia);
      const dd = Math.ceil((dl - now) / 86400000);
      const pas = dd < 0;
      const urg = !pas && dd <= 15;
      htmlResto += bigCard({
        tipo: item.tipo, modelo: item.modelo, nombre: item.nombre, color: item.color,
        importe: 0, deadline: dl, pasado: pas, urgente: urg, diffDays: dd, q: pt.q,
        desc: `${item.modelo==='303'?'A liquidar':'Estimación 20% del beneficio'} del ${pt.q}.`,
      });
    });
  });

  cont.innerHTML = `
    ${card130}
    ${card303}
    ${card100}
    <div style="margin-top:4px;">
      <button onclick="toggleHistoricoFiscal(this)"
        style="background:transparent;border:none;color:var(--muted);font-size:12px;
          cursor:pointer;font-family:inherit;padding:6px 0;
          display:flex;align-items:center;gap:6px;transition:color .2s;"
        onmouseover="this.style.color='var(--gold-2)'"
        onmouseout="this.style.color='var(--muted)'">
        <span id="historicoIcon">▶</span>
        Ver todos los trimestres / Histórico fiscal
      </button>
      <div id="historicoFiscal" style="overflow:hidden;max-height:0;
        transition:max-height .4s ease;">
        <div style="padding-top:8px;">${htmlResto}</div>
      </div>
    </div>`;
}

function toggleHistoricoFiscal(btn){
  const div  = document.getElementById('historicoFiscal');
  const icon = document.getElementById('historicoIcon');
  if(!div) return;
  const cerrado = !div.style.maxHeight || div.style.maxHeight === '0px';
  if(cerrado){
    div.style.maxHeight = (div.scrollHeight + 600) + 'px';
    if(icon) icon.textContent = '▼';
  } else {
    div.style.maxHeight = '0';
    if(icon) icon.textContent = '▶';
  }
}

/* ── Gestora: actualizar lista de facturas al cambiar selector ── */
function actualizarGestora(){
  const lista = $('gestoraListaFacturas');
  if(!lista) return;

  // Leer filtro activo: trimestre o mes concreto
  const trimVal  = $('gestoraTrim')?.value  || '';
  const mesVal   = $('gestoraFactMes')?.value || '';
  const [tDesde, tHasta] = trimVal ? trimVal.split('|') : ['',''];

  // Filtrar y ordenar todos los pagos
  const pagos = (db.payments||[]).filter(p => {
    const m = (p.mes||'').slice(0,7);
    if(mesVal)  return m === mesVal;
    if(tDesde)  return m >= tDesde && m <= tHasta;
    return true; // sin filtro: todos
  }).sort((a,b) => (a.numeroTicket||0) - (b.numeroTicket||0));

  if(!pagos.length){
    lista.innerHTML = `
      <div class="vacio" style="margin-top:8px;">
        <div style="font-size:32px;margin-bottom:10px;">🧾</div>
        <p style="font-size:14px;font-weight:600;margin-bottom:6px;">Sin facturas en este período</p>
        <p style="font-size:12.5px;">Registra pagos en la sección <strong>Pagos</strong> para que aparezcan aquí.</p>
      </div>`;
    return;
  }

  const ivaRate = db.config.iva ?? 21;
  const f = x => (Math.round(x*100)/100).toLocaleString('es-ES',{minimumFractionDigits:2}) + ' €';

  let totBase=0, totIva=0, totTotal=0;

  // Tabla
  let rows = '';
  pagos.forEach(p => {
    const u    = (db.users||[]).find(x=>x.id===p.userId);
    const numT = p.numeroTicket ? 'T-'+String(p.numeroTicket).padStart(5,'0') : '—';
    const base = p.importe / (1+ivaRate/100);
    const iva  = p.importe - base;
    totBase  += base;
    totIva   += iva;
    totTotal += p.importe;
    const mesLabel = p.mes
      ? new Date(p.mes+'-01T00:00:00').toLocaleDateString('es-ES',{month:'short',year:'numeric'})
      : '—';
    const clienteNombre = p.simplificada
      ? `<span class="badge muted" style="font-size:11px;">⚡ ${esc(p.notas||'Anónimo')}</span>`
      : esc(u?.nombre || '—');
    const tel = (u?.telefono||'').replace(/\D/g,'');
    const pdfUrl = `${location.origin}/api/factura/${p.id}/pdf`;
    const waMsg = encodeURIComponent(
      `Hola ${u?.nombre||''}! 👋\nTe enviamos tu factura:\n📄 ${numT}\n💶 ${f(p.importe)}\n📅 ${p.mes||''}\n\n🔗 Descarga tu PDF aquí:\n${pdfUrl}\n\nGracias por bailar con nosotros 💃🕺`
    );
    const pdfFn = p.simplificada
      ? `generarTicketSimplificado('${p.id}','${esc(p.notas||'Cobro puntual').replace(/'/g,"\\'")}' )`
      : `generarTicket('${p.id}')`;

    rows += `<tr>
      <td><b style="color:var(--accent);font-size:12.5px;">${numT}</b></td>
      <td>${clienteNombre}</td>
      <td style="color:var(--muted);font-size:12px;">${mesLabel}</td>
      <td style="color:var(--muted);font-size:12px;">${p.fechaPago||'—'}</td>
      <td style="text-align:right;font-weight:700;">${f(p.importe)}</td>
      <td style="text-align:right;color:var(--muted);font-size:12px;">${f(base)}</td>
      <td style="text-align:right;color:var(--warn);font-size:12px;">${f(iva)}</td>
      <td><span class="badge muted" style="font-size:10.5px;">${esc(p.metodo||'—')}</span></td>
      <td>
        <div style="display:flex;gap:5px;justify-content:flex-end;">
          <button class="btn sm ok" onclick="${pdfFn}" title="Ver / Imprimir PDF">🧾</button>
          ${tel
            ? `<a href="https://wa.me/${tel}?text=${waMsg}" target="_blank"
                 class="btn sm" title="Enviar por WhatsApp"
                 style="text-decoration:none;background:linear-gradient(135deg,#25d366,#128c7e);
                   box-shadow:0 2px 8px rgba(37,211,102,.25);">💬</a>`
            : `<span class="btn sm sec" style="opacity:.3;cursor:not-allowed;" title="Sin teléfono">💬</span>`}
        </div>
      </td>
    </tr>`;
  });

  // Fila de totales
  const totalRow = `<tr style="background:var(--surface-2);">
    <td colspan="4" style="font-weight:700;font-size:12.5px;color:var(--text-2);">
      TOTAL · ${pagos.length} factura${pagos.length!==1?'s':''}
    </td>
    <td style="text-align:right;font-weight:800;font-size:14px;color:var(--gold-2);">${f(totTotal)}</td>
    <td style="text-align:right;font-weight:700;color:var(--muted);">${f(totBase)}</td>
    <td style="text-align:right;font-weight:700;color:var(--warn);">${f(totIva)}</td>
    <td colspan="2"></td>
  </tr>`;

  lista.innerHTML = `
    <div class="tbl-wrap" style="margin-top:8px;">
      <table>
        <thead><tr>
          <th>Nº Factura</th>
          <th>Cliente</th>
          <th>Mes</th>
          <th>Fecha cobro</th>
          <th style="text-align:right;">Total</th>
          <th style="text-align:right;">Base</th>
          <th style="text-align:right;">IVA</th>
          <th>Método</th>
          <th style="text-align:right;">Acciones</th>
        </tr></thead>
        <tbody>${rows}</tbody>
        <tfoot>${totalRow}</tfoot>
      </table>
    </div>`;
}

// ── Helpers para construir HTML de factura (para ZIP) ────────────────────
function _buildHtmlFacturaParaZip(p){
  const u       = (db.users||[]).find(x=>x.id===p.userId);
  const c       = db.config;
  const neg     = c.negocio || {};
  const ivaRate = c.iva ?? 21;
  const base    = p.importe / (1 + ivaRate/100);
  const iva     = p.importe - base;
  const f = x => (Math.round(x*100)/100).toLocaleString('es-ES',{minimumFractionDigits:2}) + ' €';
  const numT    = p.numeroTicket ? 'T-' + String(p.numeroTicket).padStart(5,'0') : 'T-' + p.id.slice(0,6);
  const fechaStr = new Date((p.fechaPago||hoy())+'T12:00:00')
    .toLocaleDateString('es-ES',{day:'numeric',month:'long',year:'numeric'});

  let clienteNombre, clienteExtra = '';
  if(p.simplificada || !u || p.userId === '__anonimo__'){
    clienteNombre = u?.nombre || 'Público en general';
    if(!u) clienteExtra = `<div class="cliente-meta" style="color:#bbb;font-size:11px;">Operación sin identificación de destinatario</div>`;
  } else {
    clienteNombre = u.nombre || '—';
    if(u.email)    clienteExtra += `<div class="cliente-meta">✉ ${esc(u.email)}</div>`;
    if(u.telefono) clienteExtra += `<div class="cliente-meta">📞 ${esc(u.telefono)}</div>`;
  }

  const mesStr    = p.mes ? new Date(p.mes+'-01T00:00:00').toLocaleDateString('es-ES',{month:'long',year:'numeric'}) : '';
  const planLabel = (u && PLAN_DESC[u.plan]) ? PLAN_DESC[u.plan] : 'Servicio de clases de baile';
  const concepto  = p.notas || (mesStr ? `${planLabel} · ${mesStr}` : 'Clase de baile · Cobro puntual');

  return `<!DOCTYPE html>
<html lang="es"><head><meta charset="UTF-8">
<title>Factura ${numT}</title>
<style>${_estiloFacturaA4()}</style>
</head><body>
${_cabeceraPDF(neg, numT, 'Factura simplificada', fechaStr)}
<div class="sec-label">Cliente</div>
<div class="cliente-box">
  <div class="cliente-nombre">${esc(clienteNombre)}</div>
  ${clienteExtra}
</div>
<div class="sec-label">Concepto y desglose</div>
<table>
  <thead><tr>
    <th>Descripción</th>
    <th class="r">Base imponible</th>
    <th class="r">IVA (${ivaRate}%)</th>
    <th class="r">Total</th>
  </tr></thead>
  <tbody><tr class="fila-base">
    <td>${esc(concepto)}</td>
    <td class="r">${f(base)}</td>
    <td class="r">${f(iva)}</td>
    <td class="r">${f(p.importe)}</td>
  </tr></tbody>
  <tfoot><tr class="fila-tot">
    <td>Total a pagar</td>
    <td class="r" colspan="3">${f(p.importe)}</td>
  </tr></tfoot>
</table>
${_piePDF(neg, p.metodo)}
<button class="btn-print" onclick="window.print()">🖨 Imprimir / Guardar como PDF</button>
</body></html>`;
}

async function _descargarZipFacturas(pagos, nombreZip){
  if(!pagos.length){ showToast('No hay facturas en este período.','warn'); return; }
  showToast(`Generando ZIP con ${pagos.length} factura${pagos.length!==1?'s':''}…`, 'info', 3000);
  try {
    const ids = pagos.map(p => p.id);
    const r = await fetch('/api/facturas/zip', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      credentials: 'same-origin',
      body: JSON.stringify({ ids, nombre: nombreZip })
    });
    if(!r.ok) throw new Error(await r.text());
    const blob = await r.blob();
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href = url; a.download = nombreZip; a.click();
    URL.revokeObjectURL(url);
    showToast(`✓ ${nombreZip} descargado · ${pagos.length} factura${pagos.length!==1?'s':''}`, 'ok', 4000);
  } catch(e) {
    showToast('Error al generar el ZIP: ' + e.message, 'warn');
  }
}

function descargarFacturasMes(){
  const trimVal = $('gestoraTrim')?.value || '';
  const mesVal  = $('gestoraFactMes')?.value || '';
  const [tDesde, tHasta] = trimVal ? trimVal.split('|') : ['',''];

  const pagos = (db.payments||[]).filter(p => {
    const m = (p.mes||'').slice(0,7);
    if(mesVal)  return m === mesVal;
    if(tDesde)  return m >= tDesde && m <= tHasta;
    return true;
  }).sort((a,b) =>
    ((a.mes||'')+(a.fechaPago||'')).localeCompare((b.mes||'')+(b.fechaPago||''))
  );

  if(!pagos.length){ showToast('No hay facturas en ese período.','warn'); return; }

  const etiqueta = mesVal || (trimVal ? trimVal.replace('|','_') : 'todas');
  _descargarZipFacturas(pagos, `facturas_malevo_${etiqueta}.zip`);
}

/* ── Botón 2: Informe de todas las facturas (PDF del servidor) ── */
async function descargarInformeTodasFacturas(){
  showToast('Generando informe...', 'info', 3000);
  try {
    const r = await fetch('/api/facturas/informe-todas', {
      method:'POST', headers:{'Content-Type':'application/json'},
      credentials:'same-origin',
      body: JSON.stringify({ titulo: 'Informe de todas las facturas', nombre: 'informe_todas_facturas_malevo.pdf' })
    });
    if(!r.ok){ const e=await r.json(); throw new Error(e.error||'Error servidor'); }
    const blob = await r.blob();
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href = url; a.download = 'informe_todas_facturas_malevo.pdf'; a.click();
    URL.revokeObjectURL(url);
    showToast('Informe descargado', 'ok');
  } catch(e){ showToast('Error: '+e.message, 'warn'); }
}

/* ── Botón 3: Informe trimestral PDF (servidor) ── */
async function generarInformeTrimestral(){
  const trimVal = $('gestoraTrim')?.value || '';
  if(!trimVal){ showToast('Selecciona un trimestre en el filtro de arriba.','warn'); return; }
  const [desde, hasta] = trimVal.split('|');
  const [yr, mI] = desde.split('-').map(Number);
  const trimNum  = Math.ceil(mI/3);
  const labels   = ['Enero-Marzo','Abril-Junio','Julio-Septiembre','Octubre-Diciembre'];
  const trimLabel= yr+' - '+trimNum+'T  '+labels[trimNum-1];
  showToast('Generando informe trimestral...', 'info', 3000);
  try {
    const r = await fetch('/api/facturas/informe-trimestral', {
      method:'POST', headers:{'Content-Type':'application/json'},
      credentials:'same-origin',
      body: JSON.stringify({ desde, hasta, trimLabel })
    });
    if(!r.ok){ const e=await r.json(); throw new Error(e.error||'Error servidor'); }
    const blob   = await r.blob();
    const nombre = 'informe_trimestral_'+desde+'_'+hasta+'.pdf';
    const url    = URL.createObjectURL(blob);
    const a      = document.createElement('a');
    a.href = url; a.download = nombre; a.click();
    URL.revokeObjectURL(url);
    showToast('Informe trimestral descargado', 'ok');
  } catch(e){ showToast('Error: '+e.message, 'warn'); }
}

/* ── Sincroniza The Box automáticamente al editar Malevo y viceversa ── */
function syncBox(targetId, sourceId){
  const src = parseFloat($('cfg'+sourceId)?.value)||0;
  const tgt = $('cfg'+targetId);
  if(tgt){ tgt.value = Math.max(0, Math.min(100, 100-src)).toFixed(1); }
  // Actualiza barra visual
  const prefix = sourceId.startsWith('Ini') ? 'Ini' : 'Post';
  const malevoVal = parseFloat($('cfg'+prefix+'Malevo')?.value)||0;
  const bar = $('bar'+prefix+'Malevo');
  if(bar) bar.style.width = Math.min(100,malevoVal)+'%';
}

/* ── Guardar solo tarifas ── */
function guardarTarifas(){
  db.config.precios = {
    suelta: parseFloat($('tPrecio_suelta').value)||12,
    '35':   parseFloat($('tPrecio_35').value)||35,
    '50':   parseFloat($('tPrecio_50').value)||50,
    '80':   parseFloat($('tPrecio_80').value)||80,
    bono:   parseFloat($('tPrecio_bono').value)||100,
  };
  guardar(); confirmSave('Tarifas guardadas');
}

async function guardarConfig(){
  const ini={malevo:parseFloat($('cfgIniMalevo')?.value||0),box:parseFloat($('cfgIniBox')?.value||0)};
  const pos={malevo:parseFloat($('cfgPostMalevo')?.value||0),box:parseFloat($('cfgPostBox')?.value||0)};
  if (Math.round(ini.malevo+ini.box)!==100||Math.round(pos.malevo+pos.box)!==100){
    showToast('El reparto debe sumar 100% en cada período.','warn'); return;
  }
  const precio = k => {
    const v = $('tPrecio_'+k)?.value ?? $('cfgP'+k)?.value;
    return parseFloat(v) || db.config.precios[k] || 0;
  };
  // Preservar negocio completo (logo incluido) — no sobreescribir si no estamos en pestaña negocio
  const negActual = db.config.negocio || {};
  db.config = {
    iva: parseFloat($('cfgIva')?.value) || db.config.iva || 21,
    mesesIniciales: parseInt($('cfgMesesIni')?.value) || db.config.mesesIniciales || 3,
    inicial: ini, posterior: pos,
    precios: {
      suelta: precio('suelta'),
      '35':   precio('35'),
      '50':   precio('50'),
      '80':   precio('80'),
      bono:   precio('bono'),
    },
    portalPlans: ['35','50','80'],
    bonoClases: 10,
    negocio: negActual,  // preservar logo y todos los campos fiscales
    inviteToken: db.config.inviteToken || '',
  };
  guardar(); confirmSave('Configuración guardada');
}

async function vaciarTodo(){
  if (!confirm('⚠ Se borrarán TODOS los datos. ¿Continuar?')) return;
  if (!confirm('Confirmación final: base de datos completamente vacía. ¿Seguro?')) return;
  db.users=[]; db.classes=[]; db.enrollments=[]; db.videos=[];
  db.attendances=[]; db.payments=[]; db.contadorTicket=0; db._rev++;
  guardar(); renderView('hoy'); showToast('Base de datos vaciada','warn');
}
/* ── Modales helpers ── */
function cerrarModal(id){
  const elem=document.getElementById(id);
  if (elem) elem.remove();
}

/* ── Toast elegante en esquina inferior derecha ── */
function showToast(msg, type='ok', duration=3200){
  const c=$('toastContainer'); if(!c) return;
  if (type==='warn') playError();
  const t=document.createElement('div');
  t.className='toast '+type;
  const icons={ok:'✓',warn:'⚠',info:'ℹ'};
  const icon=icons[type]||'';
  t.innerHTML=`<span style="font-size:16px;flex:0 0 auto;">${icon}</span><span style="flex:1;">${esc(msg)}</span>
    <span style="flex:0 0 auto;cursor:pointer;opacity:.5;font-size:16px;margin-left:6px;" onclick="this.parentElement.remove()">×</span>`;
  c.appendChild(t);
  setTimeout(()=>{
    t.style.animation='toastOut .3s ease forwards';
    setTimeout(()=>t.remove(),300);
  },duration);
}

/* ── Web Audio API — sonidos sin archivos externos ── */
let _audioCtx=null;
function getAudio(){
  if(!_audioCtx) _audioCtx=new(window.AudioContext||window.webkitAudioContext)();
  return _audioCtx;
}

function playClick(){
  try{
    const ctx=getAudio();
    const o=ctx.createOscillator(); const g=ctx.createGain();
    o.connect(g); g.connect(ctx.destination);
    o.type='sine'; o.frequency.setValueAtTime(880,ctx.currentTime);
    o.frequency.exponentialRampToValueAtTime(660,ctx.currentTime+0.06);
    g.gain.setValueAtTime(0.07,ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001,ctx.currentTime+0.1);
    o.start(ctx.currentTime); o.stop(ctx.currentTime+0.1);
  } catch{}
}

/* ── Sonido de navegación suave (cambio de vista) ── */
function playNav(){
  try{
    const ctx=getAudio();
    const o=ctx.createOscillator(); const g=ctx.createGain();
    o.connect(g); g.connect(ctx.destination);
    o.type='sine';
    o.frequency.setValueAtTime(520,ctx.currentTime);
    o.frequency.exponentialRampToValueAtTime(640,ctx.currentTime+0.08);
    g.gain.setValueAtTime(0.045,ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001,ctx.currentTime+0.14);
    o.start(ctx.currentTime); o.stop(ctx.currentTime+0.15);
  } catch{}
}

/* ── Sonido al abrir un modal ── */
function playModal(){
  try{
    const ctx=getAudio();
    [[600,0],[760,0.05]].forEach(([freq,t])=>{
      const o=ctx.createOscillator(); const g=ctx.createGain();
      o.connect(g); g.connect(ctx.destination);
      o.type='sine'; o.frequency.value=freq;
      g.gain.setValueAtTime(0.04,ctx.currentTime+t);
      g.gain.exponentialRampToValueAtTime(0.001,ctx.currentTime+t+0.12);
      o.start(ctx.currentTime+t); o.stop(ctx.currentTime+t+0.14);
    });
  } catch{}
}

function playSuccess(){
  try{
    const ctx=getAudio();
    [[440,0],[554,.06],[660,.12]].forEach(([freq,t])=>{
      const o=ctx.createOscillator(); const g=ctx.createGain();
      o.connect(g); g.connect(ctx.destination);
      o.type='sine'; o.frequency.value=freq;
      g.gain.setValueAtTime(0.07,ctx.currentTime+t);
      g.gain.exponentialRampToValueAtTime(0.001,ctx.currentTime+t+0.18);
      o.start(ctx.currentTime+t); o.stop(ctx.currentTime+t+0.2);
    });
  } catch{}
}

/* ── Sonido de alerta/error — tono bajo y sutil, nunca molesto ── */
function playError(){
  try{
    const ctx=getAudio();
    const o=ctx.createOscillator(); const g=ctx.createGain();
    o.connect(g); g.connect(ctx.destination);
    o.type='sine'; o.frequency.setValueAtTime(260,ctx.currentTime);
    o.frequency.exponentialRampToValueAtTime(210,ctx.currentTime+0.16);
    g.gain.setValueAtTime(0.05,ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001,ctx.currentTime+0.22);
    o.start(ctx.currentTime); o.stop(ctx.currentTime+0.24);
  } catch{}
}

/* ── flashSuccess — overlay verde translúcido 600ms ── */
function flashSuccess(){
  const f=$('flashOverlay'); if(!f) return;
  f.classList.remove('active');
  void f.offsetWidth;
  f.classList.add('active');
  setTimeout(()=>f.classList.remove('active'), 700);
}

/* ── confirmSave — llama a los tres juntos ── */
function confirmSave(msg='Guardado'){
  playSuccess();
  flashSuccess();
  showToast(msg,'ok');
}

/* ── Auth y arranque ── */
function mostrarLogin(){ $('loginOverlay').style.display='flex'; $('appShell').style.display='none'; }
function ocultarLogin(){ $('loginOverlay').style.display='none'; $('appShell').style.display='grid'; }

/* ── Alterna el campo de contraseña entre oculto (••••) y texto plano,
   para poder verificar que la clave está bien escrita antes de enviarla ── */
function togglePassVisibility(inputId, btn){
  const input = $(inputId); if (!input) return;
  const mostrar = input.type === 'password';
  input.type = mostrar ? 'text' : 'password';
  btn.querySelector('.eye-open').style.display = mostrar ? 'none' : '';
  btn.querySelector('.eye-closed').style.display = mostrar ? '' : 'none';
  btn.setAttribute('aria-label', mostrar ? 'Ocultar contraseña' : 'Mostrar contraseña');
}

async function hacerLogin(ev){
  if (ev) ev.preventDefault();
  const username=$('logUser').value.trim();
  const password=$('logPass').value;
  const errEl=$('logError'); errEl.textContent='';
  try {
    const r=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({username,password}),credentials:'same-origin'});
    if (r.ok){
      const j=await r.json();
      // Solo admin y teacher pueden acceder al panel
      if (!['admin','teacher'].includes(j.role)){
        errEl.innerHTML='Esta área es solo para administradores. <a href="/portal.html" style="color:var(--gold-2)">Ir al portal de alumnos →</a>';
        // Cerrar la sesión que se acaba de abrir para no dejar token huérfano
        try { await fetch('/api/logout',{method:'POST',credentials:'same-origin'}); } catch {}
        return;
      }
      currentUser={sub:j.sub,role:j.role,nombre:j.nombre};
      $('logPass').value='';
      ocultarLogin();
      await arrancarApp(j.role);
    } else { errEl.textContent='Usuario o contraseña incorrectos.'; }
  } catch { errEl.textContent='No se pudo conectar con el servidor.'; }
}

async function cerrarSesion(){
  if (!confirm('¿Cerrar sesión?')) return;
  try { await fetch('/api/logout',{method:'POST',credentials:'same-origin'}); } catch {}
  location.reload();
}

async function arrancarApp(role){
  if (!['admin','teacher'].includes(role)){
    location.href='/portal.html'; return;
  }
  try {
    await cargarDB();
    marcarEstado(true);
    // Siembra automática desactivada: el catálogo de ejemplo (CATALOGO_OFICIAL_VIDEOS)
    // ya cumplió su propósito inicial y ahora reinsertaría vídeos de prueba que
    // el admin ya no quiere cada vez que se borren manualmente. Ver nota en la
    // constante más arriba si se necesita reactivar en el futuro.
    // if (role==='admin') await sembrarCatalogoOficialVideos();
  } catch(e) {
    marcarEstado(false);
    if (role==='admin') alert('Advertencia: no se pudo cargar la base de datos del servidor.');
  }
  if ($('userBadge')) $('userBadge').textContent=`${currentUser.nombre} · ${ROLES_LABEL[currentUser.role]||currentUser.role}`;
  actualizarLogoHeader();
  buildNav();
  navigateTo('dashboard');
  mostrarBotonModoAlumno();
  if (!window._syncStarted){ window._syncStarted=true; setInterval(sincronizar,5000); }
}

async function iniciar(){
  try {
    const r=await fetch('/api/me',{cache:'no-store',credentials:'same-origin'});
    if (r.ok){
      const j=await r.json();
      // Si es alumno/invitado, redirigir al portal (no al panel admin)
      if (!['admin','teacher'].includes(j.role)){
        location.replace('/portal.html'); return;
      }
      currentUser={sub:j.sub,role:j.role,nombre:j.nombre};
      ocultarLogin();
      await arrancarApp(j.role);
    } else { mostrarLogin(); }
  } catch { mostrarLogin(); }
}

iniciar();

/* ══════════════════════════════════════════════
   MODO ALUMNO — selector dentro del panel admin
   Permite al admin ver la plataforma exactamente
   como la ve cualquier alumno (o el genérico)
══════════════════════════════════════════════ */

/* Estado del modo alumno */
let _maActivo      = false;
let _maUsuario     = null;   // objeto alumno activo o null (genérico)
let _maVista       = 'inicio';
let _maVideos      = [];
let _maClases      = [];

const MA_PLANES = {'suelta':'Clase suelta','35':'1 clase/sem','50':'2 clases/sem','80':'🎓 VIP · Full Pass','bono':'Bono 10 clases'};
const MA_DIAS_FULL  = ['Domingo','Lunes','Martes','Miércoles','Jueves','Viernes','Sábado'];

/* ── Mostrar botón en header solo para admins ── */
function mostrarBotonModoAlumno(){
  const btn = $('btnModoAlumno');
  if (btn && currentUser?.role === 'admin') btn.style.display = 'inline-flex';
}

/* ── Activar: si no hay userId muestra selector de alumno ── */
function activarModoAlumno(userId){
  // Si no se especifica alumno, mostrar selector primero
  if (!userId) {
    maAbrirSelector();
    return;
  }
  maEntrarComoAlumno(userId);
}

/* ── Selector de alumno (cuando se activa desde el header) ── */
function maAbrirSelector(){
  const alumnos = (db.users||[])
    .filter(u => u.role === 'student')
    .sort((a,b) => a.nombre.localeCompare(b.nombre));

  if (!alumnos.length){
    showToast('No hay alumnos registrados todavía.','warn');
    return;
  }

  // Cerrar si ya existe
  const old = $('maSelector');
  if (old) old.remove();

  const overlay = document.createElement('div');
  overlay.id = 'maSelector';
  overlay.className = 'modal-overlay open';
  overlay.innerHTML = `
    <div class="modal-box" style="max-width:500px;">
      <h3 class="modal-title">🎓 Ver como alumno</h3>
      <p style="color:var(--muted);font-size:13px;margin-bottom:16px;">
        Selecciona un alumno para ver la plataforma desde su perspectiva.</p>
      <input type="text" id="maSelectorBusq" placeholder="Buscar alumno…"
        oninput="maFiltrarSelector()"
        style="margin-bottom:12px;">
      <div id="maSelectorLista" style="max-height:340px;overflow-y:auto;
        display:flex;flex-direction:column;gap:6px;"></div>
      <div style="display:flex;justify-content:flex-end;margin-top:18px;">
        <button class="btn sec" onclick="cerrarModal('maSelector')">Cancelar</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);

  // Renderizar lista
  window._maSelectorAlumnos = alumnos;
  maFiltrarSelector();
}

function maFiltrarSelector(){
  const q = ($('maSelectorBusq')?.value||'').toLowerCase();
  const lista = window._maSelectorAlumnos || [];
  const cont = $('maSelectorLista');
  if (!cont) return;
  const filtrados = q ? lista.filter(u => u.nombre.toLowerCase().includes(q) || (u.telefono||'').includes(q)) : lista;
  if (!filtrados.length){
    cont.innerHTML = `<div style="color:var(--muted);text-align:center;padding:16px;">Sin resultados.</div>`;
    return;
  }
  cont.innerHTML = filtrados.map(u => {
    const asignadas = (u.assignedClasses||[]).length;
    const plan = MA_PLANES[u.plan]||'—';
    return `<div onclick="cerrarModal('maSelector');maEntrarComoAlumno('${u.id}')"
      style="display:flex;align-items:center;justify-content:space-between;
        padding:11px 14px;border-radius:10px;cursor:pointer;
        background:rgba(255,255,255,.04);border:1px solid rgba(255,215,0,.1);
        transition:all .18s;"
      onmouseover="this.style.borderColor='rgba(255,215,0,.38)';this.style.background='rgba(255,215,0,.08)'"
      onmouseout="this.style.borderColor='rgba(255,215,0,.1)';this.style.background='rgba(255,255,255,.04)'">
      <div>
        <div style="font-size:13.5px;font-weight:600;">${esc(u.nombre)}</div>
        <div style="font-size:11px;color:var(--muted);margin-top:2px;">
          @${esc(u.username)}
          ${u.plan?`&nbsp;·&nbsp;<span style="color:var(--gold-2);">${plan}</span>`:''}
        </div>
      </div>
      <div style="display:flex;align-items:center;gap:8px;">
        ${asignadas?`<span style="font-size:11px;color:var(--muted);">📅 ${asignadas} cl.</span>`:''}
        <span class="badge ${u.active?'ok':'muted'}" style="font-size:10px;">${u.active?'Activo':'Baja'}</span>
      </div>
    </div>`;
  }).join('');
}

/* ── Entrar al modo alumno con un alumno concreto ── */
function maEntrarComoAlumno(userId){
  _maActivo  = true;
  _maVideos  = [];
  _maUsuario = (db.users||[]).find(u => u.id === userId) || null;

  if (!_maUsuario){
    showToast('Alumno no encontrado.','warn');
    return;
  }

  const shell = $('modoAlumnoShell');
  if (!shell) return;
  shell.style.display = 'flex';
  shell.scrollTop = 0;

  /* Cabecera — datos reales del alumno */
  const nombre = $('maUserBadge');
  const plan   = $('maPlanBadge');
  if (nombre) nombre.textContent = _maUsuario.nombre;
  if (plan) {
    const p = _maUsuario.plan;
    if (p) {
      plan.textContent = MA_PLANES[p] || p;
      plan.style.display = 'inline-flex';
      plan.style.background = p === '80' ? 'rgba(255,215,0,.12)' : 'rgba(255,215,0,.12)';
    } else {
      plan.style.display = 'none';
    }
  }

  /* Clases del alumno */
  _maClases = [];
  if (_maUsuario) {
    const asignadas = _maUsuario.assignedClasses || [];
    _maClases = asignadas
      .map(cid => (db.classes||[]).find(c => c.id === cid))
      .filter(Boolean)
      .sort((a,b) => { const da=a.dia===0?7:a.dia, db_=b.dia===0?7:b.dia; return da-db_||(a.inicio||'').localeCompare(b.inicio||''); });
  }

  /* Construir nav del portal simulado — solo Inicio y Mi perfil */
  const nav = $('maNave');
  if (nav) {
    nav.innerHTML = '';
    [['inicio','🏠 Inicio'],['perfil','👤 Mi perfil']].forEach(([v,l]) => {
      const b = document.createElement('button');
      b.className = 'ma-nav-btn';
      b.dataset.maview = v;
      b.textContent = l;
      b.onclick = () => maNavegarA(v);
      nav.appendChild(b);
    });
  }

  /* Descripción en barra admin */
  const desc = $('modoAlumnoNombre');
  if (desc) desc.textContent = `Perspectiva de: ${_maUsuario.nombre}`;

  maNavegarA('inicio');
  playNav();
}

/* ── Desactivar: volver al panel admin ── */
function desactivarModoAlumno(){
  _maActivo = false;
  _maUsuario = null;
  _maVideos  = [];
  const shell = $('modoAlumnoShell');
  if (shell) shell.style.display = 'none';
  // Limpiar tabs vídeo
  const dt = $('maDiscTabs'), np = $('maNivelPills');
  if (dt) { dt.style.display = 'none'; dt.innerHTML = ''; }
  if (np) { np.style.display = 'none'; np.innerHTML = ''; }
  playNav();
}

/* ── Navegación interna del modo alumno ── */
function maNavegarA(vista){
  _maVista = vista;
  document.querySelectorAll('.ma-nav-btn').forEach(b =>
    b.classList.toggle('active', b.dataset.maview === vista));

  const cont = $('maContent');
  if (!cont) return;
  cont.innerHTML = '';

  const fade = document.createElement('div');
  fade.style.animation = 'fade .28s cubic-bezier(.4,0,.2,1)';
  cont.appendChild(fade);

  if      (vista === 'inicio') maRenderInicio(fade);
  else if (vista === 'perfil') maRenderPerfil(fade);
}

/* ── Vista INICIO del portal simulado ── */
function maRenderInicio(cont){
  const u = _maUsuario;
  if (!u){
    cont.innerHTML = `<div style="padding:48px;text-align:center;color:var(--muted);">
      <div style="font-size:36px;margin-bottom:12px;">⚠</div>
      No se encontraron datos del alumno.</div>`;
    return;
  }
  const hora = new Date().getHours();
  const saludo = hora < 13 ? '¡Buenos días' : hora < 20 ? '¡Buenas tardes' : '¡Buenas noches';
  const primerNombre = (u.nombre||'').split(' ')[0] || 'alumno';
  const hoyNum  = new Date().getDay();
  const manaNum = (hoyNum + 1) % 7;
  const clasesHoy  = _maClases.filter(c => (c.dia??0) === hoyNum);
  const clasesMana = _maClases.filter(c => (c.dia??0) === manaNum);
  const tieneVideos = u.plan === '80' || u.portalAccess === true;
  const planNombre  = MA_PLANES[u.plan] || '—';

  function chipClase(c){
    return `<div style="background:var(--card-bg);border:1px solid var(--card-border);
      border-radius:8px;padding:9px 12px;margin-bottom:7px;">
      <div style="font-size:11px;color:var(--text-2);font-weight:700;">${c.inicio||''}${c.fin?' – '+c.fin:''}</div>
      <div style="font-size:13px;font-weight:600;margin-top:2px;color:var(--white);">${esc(c.nombre)}</div>
      <div style="font-size:11px;color:var(--muted);">${esc(c.estilo)}${c.nivelNum?' · Nivel '+c.nivelNum:''}</div>
    </div>`;
  }
  function bloque(lista, etiqueta){
    if(!lista.length) return `<div style="color:var(--muted);font-size:12px;text-align:center;
      padding:14px 0;border:1px dashed var(--card-border);border-radius:8px;">Sin clases ${etiqueta.toLowerCase()}</div>`;
    return lista.map(chipClase).join('');
  }

  cont.innerHTML = `<div style="padding:28px 24px;max-width:1060px;margin:0 auto;">
    <!-- Hero + estadísticas, fusionados en una sola tarjeta -->
    <div style="background:var(--card-bg);border:1px solid var(--card-border);border-radius:22px;position:relative;overflow:hidden;
      padding:26px 32px;margin-bottom:22px;display:flex;align-items:center;justify-content:space-between;gap:20px;flex-wrap:wrap;">
      <div style="position:absolute;top:0;left:0;right:0;height:3px;background:var(--gold);"></div>
      <div style="display:flex;align-items:center;gap:16px;">
        <div style="width:60px;height:60px;border-radius:50%;flex:0 0 auto;overflow:hidden;
          border:2px solid var(--card-border);background:var(--bg);
          display:flex;align-items:center;justify-content:center;">
          ${u.fotoPerfil
            ? `<img src="${esc(u.fotoPerfil)}" alt="" style="width:100%;height:100%;object-fit:cover;">`
            : `<span style="font-family:'Sora',sans-serif;font-weight:700;font-size:20px;color:var(--text-2);">${iniciales(u.nombre)}</span>`}
        </div>
        <div>
          <h2 style="font-family:'Sora',sans-serif;font-size:22px;font-weight:700;
            color:var(--white);letter-spacing:-.3px;margin-bottom:6px;">
            ${saludo}, ${esc(primerNombre)}! 👋</h2>
          <p style="color:var(--text-2);font-size:13.5px;line-height:1.6;">
            Bienvenido a tu espacio en la Academia Malevo.</p>
          <div style="display:inline-flex;align-items:center;gap:8px;margin-top:14px;
            padding:5px 16px;border-radius:30px;font-size:11.5px;font-weight:600;
            background:rgba(255,215,0,.1);border:1px solid rgba(255,215,0,.25);color:var(--gold);">
            🎓 ${esc(planNombre)}
            ${tieneVideos ? '&nbsp;·&nbsp;<span style="color:var(--white);">✓ Aula Virtual activa</span>' : ''}
          </div>
        </div>
      </div>
      <div style="display:flex;gap:10px;flex-wrap:wrap;">
        ${[{n:_maClases.length,l:'Clases'},{n:u.nivelBachata?'Nivel '+u.nivelBachata:'—',l:'Bachata'},
           {n:u.nivelSalsa?'Nivel '+u.nivelSalsa:'—',l:'Salsa'},
           {n:u.rol==='leader'?'🕺':u.rol==='follower'?'💃':'🔄',l:u.rol==='leader'?'Leader':u.rol==='follower'?'Follower':'Indist.'}]
          .map(s=>`<div style="background:var(--bg);border:1px solid var(--card-border);
            border-radius:14px;padding:14px 16px;text-align:center;min-width:80px;">
            <div style="font-family:'Sora',sans-serif;font-size:20px;font-weight:800;color:var(--white);">${s.n}</div>
            <div style="font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-top:4px;">${s.l}</div>
          </div>`).join('')}
      </div>
    </div>

    <!-- Clases esta semana -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:32px;">
      <div style="background:var(--card-bg);border:1px solid ${clasesHoy.length?'var(--gold)':'var(--card-border)'};
        border-radius:18px;padding:20px;">
        <div style="font-size:10px;text-transform:uppercase;letter-spacing:1.5px;
          color:${clasesHoy.length?'var(--gold)':'var(--muted)'};font-weight:600;margin-bottom:10px;">
          ${clasesHoy.length?'● ':''} HOY — ${MA_DIAS_FULL[hoyNum]}</div>
        ${bloque(clasesHoy,'hoy')}
      </div>
      <div style="background:var(--card-bg);border:1px solid var(--card-border);border-radius:18px;padding:20px;">
        <div style="font-size:10px;text-transform:uppercase;letter-spacing:1.5px;color:var(--muted);font-weight:600;margin-bottom:10px;">
          MAÑANA — ${MA_DIAS_FULL[manaNum]}</div>
        ${bloque(clasesMana,'mañana')}
      </div>
    </div>

    <!-- Mis Vídeos, embebido en el mismo scroll -->
    <div style="display:flex;align-items:center;gap:14px;margin:8px 0 20px;">
      <div style="flex:1;height:1px;background:var(--card-border);"></div>
      <div style="font-size:10.5px;letter-spacing:3px;color:var(--muted);font-weight:700;">▶ MIS VÍDEOS</div>
      <div style="flex:1;height:1px;background:var(--card-border);"></div>
    </div>
    <div id="maVideosEmbed" style="margin-bottom:32px;"></div>
  </div>`;

  maRenderVideos($('maVideosEmbed'));
}

/* ── Vista VÍDEOS del portal simulado — tarjetas de nivel, igual que el portal real ── */
async function maRenderVideos(cont){
  const u = _maUsuario || { plan: null };
  const tieneVideos = u.plan === '80' || u.portalAccess === true;

  if (!tieneVideos){
    cont.innerHTML = `<div style="max-width:540px;margin:0 auto;padding:0 24px;">
      <div style="background:var(--card-bg);border:1px solid var(--card-border);
        border-radius:20px;padding:40px;text-align:center;">
        <div style="font-size:48px;margin-bottom:14px;">🔒</div>
        <h3 style="font-family:'Sora',sans-serif;font-size:20px;color:var(--white);margin-bottom:10px;">Aula Virtual no activa</h3>
        <p style="color:var(--text-2);font-size:13.5px;line-height:1.7;">
          Este alumno no tiene plan VIP.<br>Cambia su plan a <strong style="color:var(--gold);">VIP · Full Pass</strong> para activar el acceso.</p>
      </div></div>`;
    return;
  }

  if (!_maVideos.length){
    try {
      const r = await fetch('/api/videos',{credentials:'same-origin'});
      if (r.ok) _maVideos = await r.json();
    } catch { _maVideos = []; }
  }

  if (!_maVideos.length){
    cont.innerHTML = `<div style="padding:28px 24px;color:var(--muted);text-align:center;">Sin vídeos cargados todavía.</div>`;
    return;
  }

  // Niveles con contenido de clase (excluye calentamiento/bonus/playlist/evento), cruzando acceso real
  const discs = [...new Set(_maVideos.filter(v=>!v.tipo||v.tipo==='clase').map(v=>v.disciplina))];
  const nivelesCards = [];
  discs.forEach(disc=>{
    const acceso = maNivelesToAcceso(disc);
    [1,2,3,4].forEach(n=>{
      if (!acceso.includes(n)) return; // sin acceso a este nivel → ni se construye la tarjeta
      const vids = _maVideos.filter(v=>v.disciplina===disc && v.nivel===n && (!v.tipo||v.tipo==='clase'))
        .sort((a,b)=>(a.orden||0)-(b.orden||0));
      if (!vids.length) return;
      const bonus = n===4 ? [] : _maVideos.filter(v=>v.disciplina===disc && v.nivel===n && v.tipo==='bonus')
        .sort((a,b)=>(a.orden||0)-(b.orden||0)).slice(0,3);
      nivelesCards.push({disc, n, vids, bonus});
    });
  });

  let html = `<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:14px;margin-bottom:20px;">`;
  nivelesCards.forEach(nc=>{
    html += `<div class="card" style="cursor:pointer;" onclick="maAbrirNivel('${esc(nc.disc)}',${nc.n})">
      <div style="font-weight:700;color:var(--white);font-size:13.5px;margin-bottom:12px;">${esc(nc.disc)} · ${nivelLabelCorto(nc.n)}</div>
      <div style="display:flex;align-items:baseline;gap:6px;margin-bottom:10px;">
        <span style="font-family:'Sora',sans-serif;font-size:30px;font-weight:800;color:var(--gold);">${nc.vids.length}</span>
        <span style="font-size:10px;color:var(--muted);letter-spacing:1px;">CLASES</span>
      </div>
      <div style="display:flex;gap:3px;margin-bottom:10px;" title="El progreso de visualización solo se registra en el dispositivo del propio alumno">
        ${nc.vids.map(()=>`<div style="flex:1;height:5px;border-radius:2px;background:rgba(255,255,255,.1);"></div>`).join('')}
      </div>
      <div style="text-align:right;"><span style="font-size:12px;color:var(--gold);font-weight:600;">Ver →</span></div>
      ${nc.bonus.length ? `<div style="display:flex;align-items:center;gap:6px;margin-top:12px;padding-top:10px;border-top:1px solid var(--card-border);">
          <span style="font-size:13px;">🎁</span>
          <span style="font-size:10.5px;color:var(--muted);">Bonus: 0/${nc.bonus.length} desbloqueados (vista del alumno)</span>
        </div>` : ''}
    </div>`;
  });
  html += `</div>`;

  html += `<div id="maAulaWrap" class="card" style="padding:0;overflow:hidden;display:none;border-color:var(--gold);">
      <div style="display:flex;align-items:center;justify-content:space-between;
        padding:16px 22px;border-bottom:1px solid var(--card-border);">
        <div>
          <div id="maPanelTitulo" style="font-size:15px;font-weight:700;color:var(--white);"></div>
          <div id="maPanelSub" style="font-size:11.5px;color:var(--muted);margin-top:2px;"></div>
        </div>
        <button class="btn sm sec" onclick="maCerrarPanelVideo()">× Cerrar</button>
      </div>
      <div id="maPlayerWrap" style="position:relative;width:100%;padding-top:56.25%;background:#000;">
        <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;
          color:var(--muted);gap:12px;background:#0e0e0e;">
          <svg width="50" height="50" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" opacity=".3">
            <circle cx="12" cy="12" r="10"/><polygon points="10,8 16,12 10,16" fill="currentColor"/>
          </svg>
          <span style="font-size:13px;">Selecciona una clase</span>
        </div>
      </div>
      <div id="maVideoMeta" style="padding:16px 22px 4px;">
        <div id="maVideoTitle" style="display:none;font-family:'Sora',sans-serif;font-size:17px;font-weight:700;color:var(--white);"></div>
        <div id="maVideoNotes" style="color:var(--text-2);font-size:13px;line-height:1.7;margin-top:6px;"></div>
      </div>
      <div id="maVideoCurrentLabel" class="video-status-bar" style="display:none;">
        <span id="maVideoCurrentLabelText"></span>
      </div>
      <div id="maVideoListRow" style="display:flex;gap:16px;align-items:flex-start;padding:16px 22px;">
        <div id="maVideoList" style="flex:1;min-width:0;display:flex;flex-direction:column;gap:8px;"></div>
        <div id="maSpotifyPanelWrap" style="flex:0 0 300px;display:none;flex-direction:column;gap:12px;"></div>
      </div>
    </div>`;

  cont.innerHTML = html;
}

/* ── Abre el panel de un nivel (tarjeta "Ver →") ── */
/* ── El admin puede pegar el <iframe> completo de Spotify, el enlace de
   "Insertar" (embed) o el de "Copiar enlace a la playlist" (normal, no embed).
   Esto normaliza cualquiera de los tres a una URL de embed válida. ── */
function extraerSpotifyEmbed(raw){
  if (!raw) return null;
  const srcMatch = raw.match(/src=["']([^"']+)["']/);
  let src = srcMatch ? srcMatch[1] : (/^https?:\/\//.test(raw.trim()) ? raw.trim() : null);
  if (!src) return null;
  // "Copiar enlace" da open.spotify.com/playlist/ID — sin /embed/, hay que insertarlo
  if (src.includes('open.spotify.com/') && !src.includes('/embed/')){
    src = src.replace('open.spotify.com/', 'open.spotify.com/embed/');
  }
  return { src };
}

/* ── Incrusta el/los reproductor(es) de Spotify de este nivel, en tamaño
   completo (con la lista de canciones visible), apilados en la columna
   derecha junto a la lista de clases. Son iframes independientes: no pausan
   ni afectan al vídeo de YouTube. ── */
function maConstruirEmbedsSpotify(disc, nivel){
  const items = (_maVideos||[]).filter(v=>v.disciplina===disc && v.nivel===nivel && v.tipo==='playlist');
  return items.map(p=>{
    const embed = extraerSpotifyEmbed(p.url);
    if (!embed) return '';
    return `<iframe src="${esc(embed.src)}" width="100%" height="352" style="border-radius:12px;display:block;border:none;"
      frameBorder="0" loading="lazy" title="${esc(p.titulo)}"
      allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"></iframe>`;
  }).filter(Boolean).join('');
}

function maAbrirNivel(disc, nivel){
  const vids = _maVideos.filter(v=>v.disciplina===disc && v.nivel===nivel && (!v.tipo||v.tipo==='clase'))
    .sort((a,b)=>(a.orden||0)-(b.orden||0));
  const wrap = $('maAulaWrap'); if (!wrap) return;
  wrap.style.display='';
  if ($('maPanelTitulo')) $('maPanelTitulo').textContent = `${disc} · ${nivelLabel(nivel)}`;
  if ($('maPanelSub'))    $('maPanelSub').textContent    = `${vids.length} clase${vids.length!==1?'s':''}`;
  const spotifyWrap=$('maSpotifyPanelWrap');
  if (spotifyWrap){
    const html = maConstruirEmbedsSpotify(disc, nivel);
    spotifyWrap.innerHTML = html;
    spotifyWrap.style.display = html ? 'flex' : 'none';
  }

  const list = $('maVideoList');
  if (list){
    let html = vids.length ? vids.map((v,i)=>`
      <div class="video-row" data-vid="${v.id}" onclick="maPlayVideo('${v.id}')">
        <div class="video-row-num">${i+1}</div>
        <div style="flex:1;min-width:0;">
          <div class="video-row-title">${esc(v.titulo)}</div>
          <div class="video-row-sub">${esc(v.disciplina)} · ${nivelLabel(v.nivel)}</div>
        </div>
        <span class="video-row-arrow">▶</span>
      </div>`).join('')
      : '<div style="padding:20px;color:var(--muted);font-size:13px;text-align:center;">Sin clases en este nivel.</div>';

    const bonus = nivel===4 ? [] : _maVideos.filter(v=>v.disciplina===disc && v.nivel===nivel && v.tipo==='bonus')
      .sort((a,b)=>(a.orden||0)-(b.orden||0)).slice(0,3);
    if (bonus.length){
      html += `<div style="display:flex;align-items:center;gap:8px;margin:18px 0 10px;padding-top:14px;border-top:1px solid var(--card-border);">
        <span style="font-size:14px;">🎁</span>
        <span style="font-size:10px;text-transform:uppercase;letter-spacing:2px;color:var(--muted);font-weight:700;">Bonus</span>
      </div>`;
      html += bonus.map((bv,i)=>{
        const umbral=(i+1)*5;
        return `<div class="video-row" style="opacity:.55;cursor:not-allowed;"
          title="Se desbloquea cuando el alumno complete ${umbral} vídeos del nivel (progreso no visible desde el admin)">
          <div class="video-row-num">🔒</div>
          <div style="flex:1;min-width:0;">
            <div class="video-row-title">Bonus ${i+1} · ${esc(bv.titulo)}</div>
            <div class="video-row-sub">Se desbloquea a los ${umbral} vídeos vistos</div>
          </div>
        </div>`;
      }).join('');
    }
    list.innerHTML = html;
  }

  if (vids.length) maPlayVideo(vids[0].id);
  wrap.scrollIntoView({behavior:'smooth', block:'start'});
  playNav();
}

/* ── Cierra el panel de vídeo (botón "× Cerrar") ── */
function maCerrarPanelVideo(){
  const wrap = $('maAulaWrap'); if (wrap) wrap.style.display='none';
  const label = $('maVideoCurrentLabel'); if (label) label.style.display='none';
}

function maPlayVideo(id){
  const v = _maVideos.find(x => x.id === id);
  if (!v) return;
  document.querySelectorAll('#maVideoList .video-row').forEach(el => {
    el.classList.toggle('active', el.dataset.vid === id);
  });
  const title = $('maVideoTitle'), notes = $('maVideoNotes');
  if (title) { title.style.display = ''; title.textContent = v.titulo; }
  if (notes) notes.textContent = v.notas || '';

  const label = $('maVideoCurrentLabel');
  const labelText = $('maVideoCurrentLabelText');
  if (label && labelText){
    if (!v.tipo || v.tipo==='clase'){
      const lista = _maVideos.filter(x=>x.disciplina===v.disciplina && x.nivel===v.nivel && (!x.tipo||x.tipo==='clase'))
        .sort((a,b)=>(a.orden||0)-(b.orden||0));
      const posicion = lista.findIndex(x=>x.id===v.id) + 1;
      label.style.display='flex';
      labelText.innerHTML = `${esc(v.disciplina)} · ${nivelLabel(v.nivel)} — <span class="clase-actual">Clase ${posicion||1}</span>`;
    } else {
      label.style.display='none';
    }
  }
  const wrap = $('maPlayerWrap'); if (!wrap) return;
  wrap.querySelectorAll('iframe,video').forEach(e => e.remove());
  const placeholder = wrap.querySelector('div');
  if (placeholder) placeholder.remove();
  const url = v.url || '';
  if (url.includes('youtube.com/embed') || url.includes('youtu.be') || url.includes('vimeo.com')){
    let embed = url;
    if (url.includes('youtu.be/')){ const vid_ = url.split('youtu.be/')[1].split('?')[0]; embed = `https://www.youtube.com/embed/${vid_}`; }
    const ifr = document.createElement('iframe');
    ifr.src = embed; ifr.allow = 'accelerometer;autoplay;clipboard-write;encrypted-media;gyroscope;picture-in-picture';
    ifr.allowFullscreen = true;
    ifr.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;border:none;';
    wrap.appendChild(ifr);
  } else if (url.match(/\.(mp4|webm|m4v)$/i)){
    const vid_ = document.createElement('video');
    vid_.src = url; vid_.controls = true; vid_.controlsList = 'nodownload';
    vid_.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;';
    wrap.appendChild(vid_);
  }
}
/* ── Calcula qué niveles puede ver el alumno en vista previa (modo admin) ──
   Espejo exacto de nivelesToAcceso() en portal.js, pero usando _maUsuario
   (el alumno que el admin está simulando) en vez de currentUser.
   Devuelve SIEMPRE un array (nunca null): sin nivel asignado = sin acceso. */
function maNivelesToAcceso(disc){
  const u = _maUsuario;
  if (!u) return [];
  // VIP: acceso acumulado hasta su nivelMax en esa disciplina
  if (u.plan === '80'){
    const nivelMax = disc === 'Bachata' ? (parseInt(u.nivelBachata)||0)
                   : disc === 'Salsa'   ? (parseInt(u.nivelSalsa)||0)
                   : 0;
    if (!nivelMax) return []; // VIP sin nivel asignado todavía → sin acceso hasta que se le asigne
    return Array.from({length: nivelMax}, (_,i) => i+1);
  }
  // Plan no-VIP con acceso portal: solo su nivel exacto
  const nivelExacto = disc === 'Bachata' ? parseInt(u.nivelBachata)||null
                    : disc === 'Salsa'   ? parseInt(u.nivelSalsa)||null
                    : null;
  if (!nivelExacto) return []; // sin nivel asignado → sin acceso (fail-closed)
  return [nivelExacto];
}

/* ── Vista REFERIDOS del portal simulado ── */
function maRenderReferidos(cont){
  const u = _maUsuario;
  const code = u?.referralCode || '—';
  const referred = u?.referralCount || 0;
  const discount = u?.referralDiscount || 0;
  const link = u ? `${location.origin}/registro.html?ref=${code}` : `${location.origin}/registro.html`;

  cont.innerHTML = `<div style="padding:28px 24px;max-width:700px;margin:0 auto;">
    <div class="h2">🎁 Invitar amigos</div>
    <div style="background:linear-gradient(135deg,rgba(255,215,0,.1),rgba(138,112,0,.07));
      border:1px solid rgba(255,215,0,.22);border-radius:20px;padding:32px;text-align:center;margin-bottom:18px;">
      <div style="font-size:44px;margin-bottom:12px;">🎁</div>
      <h3 style="font-family:'Sora',sans-serif;font-size:20px;color:var(--gold-2);margin-bottom:8px;">Gana un 30% de descuento</h3>
      <p style="color:var(--text-2);font-size:13.5px;line-height:1.7;">
        Cada amigo que se registre con tu enlace te da un <strong style="color:var(--gold-light);">30% de descuento</strong> en tu cuota.</p>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:18px;">
      <div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,215,0,.14);border-radius:16px;padding:20px;text-align:center;">
        <div style="font-family:'Sora',sans-serif;font-size:34px;font-weight:800;color:var(--gold-2);">${referred}</div>
        <div style="font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-top:4px;">Amigos invitados</div>
      </div>
      <div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,215,0,.14);border-radius:16px;padding:20px;text-align:center;">
        <div style="font-family:'Sora',sans-serif;font-size:34px;font-weight:800;color:${discount>0?'var(--ok)':'var(--muted)'};">${discount}%</div>
        <div style="font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-top:4px;">Descuento activo</div>
      </div>
    </div>
    <div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,215,0,.14);border-radius:16px;padding:20px;">
      <div style="font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:8px;font-weight:600;">Enlace personal</div>
      <input type="text" value="${esc(link)}" readonly
        style="background:rgba(255,215,0,.06);border-color:rgba(255,215,0,.25);
          color:var(--gold-light);font-size:12.5px;cursor:pointer;" onclick="this.select();">
    </div>
  </div>`;
}

/* ── Vista PERFIL del portal simulado ── */
function maRenderPerfil(cont){
  const u = _maUsuario || { nombre:'', email:'', telefono:'', plan:null, nivelBachata:null, nivelSalsa:null, rol:'indiferente' };
  const planNombre = MA_PLANES[u.plan] || 'Sin plan asignado';
  const avatarHtml = u.fotoPerfil
    ? '<img src="'+esc(u.fotoPerfil)+'" style="width:100%;height:100%;object-fit:cover;">'
    : '<span style="font-size:34px;opacity:.5;">👤</span>';

  cont.innerHTML = `<div style="padding:28px 24px;max-width:660px;margin:0 auto;">
    <div class="h2">👤 Mi perfil</div>

    <!-- ── Foto de perfil (editable desde aquí) ── -->
    <div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,215,0,.14);
      border-radius:18px;padding:22px;margin-bottom:16px;">
      <div style="font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:1px;
        margin-bottom:14px;font-weight:700;">📷 Foto de perfil</div>
      <div style="display:flex;align-items:center;gap:20px;flex-wrap:wrap;">
        <div style="flex:0 0 auto;">
          <div id="maFotoPreview" style="width:90px;height:90px;border-radius:50%;overflow:hidden;
            background:linear-gradient(135deg,rgba(255,215,0,.2),rgba(138,112,0,.15));
            border:2px solid rgba(255,215,0,.4);display:flex;align-items:center;justify-content:center;
            box-shadow:0 2px 12px rgba(0,0,0,.4);">
            ${avatarHtml}
          </div>
        </div>
        <div style="flex:1;display:flex;flex-direction:column;gap:10px;">
          <p style="color:var(--muted);font-size:13px;margin:0;line-height:1.5;">
            La foto aparecerá en el saludo de inicio del alumno.</p>
          <div style="display:flex;gap:8px;flex-wrap:wrap;">
            <label style="cursor:pointer;">
              <input type="file" id="maFotoInput" accept="image/*" style="display:none;"
                onchange="maPreviewFoto(this)">
              <span class="btn sm sec" style="display:inline-flex;align-items:center;gap:6px;">📁 Subir foto</span>
            </label>
            <button class="btn sm sec" onclick="maCapturarFoto()"
              style="display:inline-flex;align-items:center;gap:6px;">📷 Usar cámara</button>
            ${u.fotoPerfil ? '<button class="btn sm warn" onclick="maEliminarFoto()" style="display:inline-flex;align-items:center;gap:6px;">× Quitar foto</button>' : ''}
          </div>
          <canvas id="maFotoCanvas" style="display:none;"></canvas>
          <video id="maFotoVideo" autoplay playsinline
            style="display:none;width:220px;border-radius:10px;border:1px solid rgba(255,215,0,.3);"></video>
          <div id="maFotoCamControls" style="display:none;gap:8px;flex-wrap:wrap;">
            <button class="btn sm ok" onclick="maTomarFoto()"
              style="display:inline-flex;align-items:center;gap:6px;">📸 Tomar foto</button>
            <button class="btn sm sec" onclick="maCancelarCamara()"
              style="display:inline-flex;align-items:center;gap:6px;">× Cancelar</button>
          </div>
          <div id="maFotoGuardarWrap" style="display:none;">
            <button onclick="maGuardarFoto('${u.id}')"
              style="background:linear-gradient(135deg,var(--gold),var(--accent-deep));
                color:#0a0a0a;border:none;padding:9px 22px;border-radius:9px;cursor:pointer;
                font-size:13px;font-weight:700;font-family:inherit;
                box-shadow:0 4px 14px rgba(0,0,0,.4);display:inline-flex;align-items:center;gap:6px;">
              ✓ Guardar foto
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Datos -->
    <div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,215,0,.14);
      border-radius:18px;padding:22px;margin-bottom:16px;">
      <div style="display:flex;align-items:center;gap:16px;margin-bottom:14px;">
        <div>
          <div style="font-size:17px;font-weight:700;">${esc(u.nombre||'—')}</div>
          <div style="font-size:12px;color:var(--muted);">@${esc(u.username||'')}</div>
        </div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
        <div><div style="font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:.7px;margin-bottom:4px;">Email</div>
          <div style="font-size:13px;padding:9px 12px;background:rgba(255,255,255,.03);border-radius:8px;">${esc(u.email||'—')}</div></div>
        <div><div style="font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:.7px;margin-bottom:4px;">Teléfono</div>
          <div style="font-size:13px;padding:9px 12px;background:rgba(255,255,255,.03);border-radius:8px;">${u.telefono?'📱 '+esc(u.telefono):'—'}</div></div>
      </div>
      ${u.bio?'<div style="margin-top:10px;font-size:12.5px;color:var(--text-2);padding:9px 12px;background:rgba(255,255,255,.03);border-radius:8px;">'+esc(u.bio)+'</div>':''}
    </div>

    <!-- Niveles y rol -->
    <div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,215,0,.14);
      border-radius:18px;padding:22px;margin-bottom:16px;">
      <div style="font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:14px;font-weight:700;">Niveles y rol</div>
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;text-align:center;">
        <div style="padding:14px;background:rgba(255,255,255,.03);border-radius:12px;border:1px solid rgba(255,215,0,.1);">
          <div style="font-size:22px;font-weight:800;color:${u.nivelBachata?'var(--gold-2)':'var(--muted)'};">${u.nivelBachata?'Nivel '+u.nivelBachata:'—'}</div>
          <div style="font-size:10.5px;color:var(--muted);margin-top:4px;text-transform:uppercase;letter-spacing:1px;">Bachata</div></div>
        <div style="padding:14px;background:rgba(255,255,255,.03);border-radius:12px;border:1px solid rgba(255,215,0,.1);">
          <div style="font-size:22px;font-weight:800;color:${u.nivelSalsa?'var(--gold-2)':'var(--muted)'};">${u.nivelSalsa?'Nivel '+u.nivelSalsa:'—'}</div>
          <div style="font-size:10.5px;color:var(--muted);margin-top:4px;text-transform:uppercase;letter-spacing:1px;">Salsa</div></div>
        <div style="padding:14px;background:rgba(255,255,255,.03);border-radius:12px;border:1px solid rgba(255,215,0,.1);">
          <div style="font-size:22px;">${u.rol==='leader'?'🕺':u.rol==='follower'?'💃':'🔄'}</div>
          <div style="font-size:10.5px;color:var(--muted);margin-top:4px;text-transform:uppercase;letter-spacing:1px;">${u.rol==='leader'?'Leader':u.rol==='follower'?'Follower':'Indistinto'}</div></div>
      </div>
    </div>

    <!-- Plan -->
    <div style="background:rgba(255,215,0,.05);border:1px solid rgba(255,215,0,.18);
      border-radius:18px;padding:18px 20px;margin-bottom:16px;">
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <div>
          <div style="font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;">Plan actual</div>
          <div style="font-size:18px;font-weight:700;color:var(--gold-2);">${esc(planNombre)}</div>
        </div>
        ${u.plan==='80'?'<span class="badge ok">🎓 VIP · Aula Virtual</span>':'<span class="badge muted">Solo presencial</span>'}
      </div>
    </div>

    <button onclick="cerrarModal('modalVerAlumno');abrirModalAlumno('${u.id}')"
      style="background:rgba(255,255,255,.05);border:1px solid rgba(255,215,0,.28);color:var(--gold-2);
        padding:10px 22px;border-radius:9px;cursor:pointer;font-size:13px;
        font-weight:600;font-family:inherit;width:100%;">
      ✏ Editar todos los datos del alumno
    </button>
  </div>`;
}

/* ── Funciones de foto para la vista previa admin ── */
function maPreviewFoto(input){
  const file = input.files[0]; if(!file) return;
  if(file.size > 2*1024*1024){ showToast('Imagen debe ser < 2 MB','warn'); return; }
  const reader = new FileReader();
  reader.onload = e => {
    const d = e.target.result;
    const p = $('maFotoPreview');
    if(p) p.innerHTML = '<img src="'+d+'" style="width:100%;height:100%;object-fit:cover;">';
    window._maFotoTemporal = d;
    const w = $('maFotoGuardarWrap'); if(w) w.style.display='block';
  };
  reader.readAsDataURL(file);
}
async function maCapturarFoto(){
  const v=$('maFotoVideo'), c=$('maFotoCamControls'); if(!v||!c) return;
  try {
    const s=await navigator.mediaDevices.getUserMedia({video:{facingMode:'user'}});
    v._stream=s; v.srcObject=s; v.style.display='block'; c.style.display='flex';
  } catch { showToast('No se pudo acceder a la cámara','warn'); }
}
function maTomarFoto(){
  const v=$('maFotoVideo'), cv=$('maFotoCanvas'); if(!v||!cv) return;
  cv.width=v.videoWidth||320; cv.height=v.videoHeight||320;
  cv.getContext('2d').drawImage(v,0,0);
  const d=cv.toDataURL('image/jpeg',0.85);
  maCancelarCamara();
  const p=$('maFotoPreview'); if(p) p.innerHTML='<img src="'+d+'" style="width:100%;height:100%;object-fit:cover;">';
  window._maFotoTemporal=d;
  const w=$('maFotoGuardarWrap'); if(w) w.style.display='block';
}
function maCancelarCamara(){
  const v=$('maFotoVideo'), c=$('maFotoCamControls');
  if(v){ if(v._stream) v._stream.getTracks().forEach(t=>t.stop()); v.style.display='none'; }
  if(c) c.style.display='none';
}
function maEliminarFoto(){
  if(!confirm('¿Quitar la foto de este alumno?')) return;
  window._maFotoTemporal='';
  const p=$('maFotoPreview'); if(p) p.innerHTML='<span style="font-size:34px;opacity:.5;">👤</span>';
  const w=$('maFotoGuardarWrap'); if(w) w.style.display='block';
}
async function maGuardarFoto(userId){
  const foto = window._maFotoTemporal;
  if(foto===undefined){ showToast('Selecciona una foto primero','warn'); return; }
  try {
    await apiJSON('PUT',`/api/users/${userId}`,{
      nombre:_maUsuario.nombre, telefono:_maUsuario.telefono||'',
      email:_maUsuario.email||'', role:'student', plan:_maUsuario.plan,
      active:_maUsuario.active!==false, portalAccess:_maUsuario.portalAccess||false,
      cashOnly:_maUsuario.cashOnly||false, guestCourtesy:_maUsuario.guestCourtesy||false,
      facturaEnvio:_maUsuario.facturaEnvio||'none',
      fotoPerfil: foto
    });
    _maUsuario.fotoPerfil = foto;
    delete window._maFotoTemporal;
    await cargarDB();
    const w=$('maFotoGuardarWrap'); if(w) w.style.display='none';
    showToast('Foto guardada correctamente','ok');
    playSuccess(); flashSuccess();
  } catch(e){ showToast('Error al guardar: '+e.message,'warn'); }
}

/* ── Conectar botón Ver del listado al modo alumno ── */
function verComoAlumno(userId){
  maEntrarComoAlumno(userId);
}

/* ── mostrarBotonModoAlumno se llama desde arrancarApp (ver arriba) ── */
