/* ===== Malevo v3.0 · Portal del Alumno ===== */
'use strict';

/* ── Web Audio · sonidos del portal ── */
let _portalAudioCtx = null;
function _getAudio(){
  if(!_portalAudioCtx) _portalAudioCtx=new(window.AudioContext||window.webkitAudioContext)();
  return _portalAudioCtx;
}
/* Sonido de navegación entre pestañas — suave, cristalino */
function portalPlayNav(){
  try{
    const ctx=_getAudio();
    const o=ctx.createOscillator(), g=ctx.createGain();
    o.connect(g); g.connect(ctx.destination);
    o.type='sine';
    o.frequency.setValueAtTime(480,ctx.currentTime);
    o.frequency.exponentialRampToValueAtTime(620,ctx.currentTime+0.1);
    g.gain.setValueAtTime(0.04,ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001,ctx.currentTime+0.18);
    o.start(ctx.currentTime); o.stop(ctx.currentTime+0.2);
  }catch{}
}
/* Sonido de guardado exitoso */
function portalPlaySuccess(){
  try{
    const ctx=_getAudio();
    [[440,0],[554,0.07],[660,0.14]].forEach(([freq,t])=>{
      const o=ctx.createOscillator(), g=ctx.createGain();
      o.connect(g); g.connect(ctx.destination);
      o.type='sine'; o.frequency.value=freq;
      g.gain.setValueAtTime(0.055,ctx.currentTime+t);
      g.gain.exponentialRampToValueAtTime(0.001,ctx.currentTime+t+0.18);
      o.start(ctx.currentTime+t); o.stop(ctx.currentTime+t+0.2);
    });
  }catch{}
}
/* Clic suave general */
function portalPlayClick(){
  try{
    const ctx=_getAudio();
    const o=ctx.createOscillator(), g=ctx.createGain();
    o.connect(g); g.connect(ctx.destination);
    o.type='sine';
    o.frequency.setValueAtTime(720,ctx.currentTime);
    o.frequency.exponentialRampToValueAtTime(540,ctx.currentTime+0.07);
    g.gain.setValueAtTime(0.035,ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001,ctx.currentTime+0.1);
    o.start(ctx.currentTime); o.stop(ctx.currentTime+0.1);
  }catch{}
}
/* Sonido de copia de enlace */
function portalPlayCopy(){
  try{
    const ctx=_getAudio();
    [[880,0],[1100,0.05]].forEach(([freq,t])=>{
      const o=ctx.createOscillator(), g=ctx.createGain();
      o.connect(g); g.connect(ctx.destination);
      o.type='sine'; o.frequency.value=freq;
      g.gain.setValueAtTime(0.04,ctx.currentTime+t);
      g.gain.exponentialRampToValueAtTime(0.001,ctx.currentTime+t+0.1);
      o.start(ctx.currentTime+t); o.stop(ctx.currentTime+t+0.12);
    });
  }catch{}
}

const DISCIPLINAS_VIDEO = ['Bachata','Salsa'];
const DIAS_FULL = ['Domingo','Lunes','Martes','Miércoles','Jueves','Viernes','Sábado'];
const DIAS_CORTO = ['Dom','Lun','Mar','Mié','Jue','Vie','Sáb'];

let currentUser   = null;   // { sub, role, nombre, hasPortalAccess }
let allVideos     = [];
let myClasses     = [];     // clases asignadas por admin
let activeView    = null;
let activeDisciplina = null;
let activeNivel   = null;
let activeVideoId = null;

/* ── Utils ── */
function $(id){ return document.getElementById(id); }
function esc(s){ return String(s??'').replace(/[&<>"']/g,c=>
  ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function iniciales(n){ return (n||'').trim().split(/\s+/).slice(0,2).map(w=>w[0]).join('').toUpperCase()||'?'; }

/* ── Nivel 4 se muestra como "Coreografías" en toda la interfaz de vídeo ── */
function nivelLabel(n){ return n===4 ? 'Coreografías' : 'Nivel '+n; }
function nivelLabelCorto(n){ return n===4 ? 'Coreo' : 'N'+n; }

/* ── Pinta el avatar (foto real o iniciales) del alumno en el contenedor indicado ── */
function pintarAvatar(elId, fotoUrl, nombre, fontSize){
  const el=$(elId); if(!el) return;
  el.innerHTML = fotoUrl
    ? `<img src="${esc(fotoUrl)}" alt="">`
    : `<span style="font-family:'Sora',sans-serif;font-weight:700;font-size:${fontSize||14}px;color:var(--text-2);">${iniciales(nombre)}</span>`;
}

function showToast(msg, type='ok', duration=3200){
  const c=$('toastContainer'); if(!c) return;
  const t=document.createElement('div');
  t.className='portal-toast '+type;
  const icons={ok:'✓',warn:'⚠',info:'ℹ'};
  t.innerHTML=`<span style="font-size:16px;flex:0 0 auto;">${icons[type]||''}</span>
    <span style="flex:1;">${esc(msg)}</span>
    <span onclick="this.parentElement.remove()" style="cursor:pointer;opacity:.5;font-size:16px;margin-left:6px;">×</span>`;
  c.appendChild(t);
  setTimeout(()=>{ t.style.animation='toastOut .3s ease forwards'; setTimeout(()=>t.remove(),300); },duration);
}

/* ── Auth ── */
async function portalLogin(ev){
  ev.preventDefault();
  const username=$('pUser').value.trim();
  const password=$('pPass').value;
  const err=$('pError'); err.textContent='';
  try {
    const r=await fetch('/api/login',{method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({username,password}), credentials:'same-origin'});
    if (!r.ok){ err.textContent='Usuario o contraseña incorrectos.'; return; }
    const j=await r.json();
    // Admins y profesores → redirigir al panel de administración
    if (['admin','teacher'].includes(j.role)){ location.replace('/index.html'); return; }
    currentUser={sub:j.sub,role:j.role,nombre:j.nombre};
    $('pPass').value='';
    await arrancarPortal();
  } catch { err.textContent='No se pudo conectar.'; }
}

async function portalLogout(){
  if (!confirm('¿Salir?')) return;
  try { await fetch('/api/logout',{method:'POST',credentials:'same-origin'}); } catch {}
  location.reload();
}

function mostrarLogin(){ $('loginOverlay').style.display='flex'; $('portalApp').style.display='none'; }
function ocultarLogin(){ $('loginOverlay').style.display='none'; $('portalApp').style.display='grid'; }

/* ── Alterna el campo de contraseña entre oculto (••••) y texto plano,
   para poder verificar que la clave está bien escrita antes de enviarla ── */
function togglePassVisibility(inputId, btn){
  const input = $(inputId); if (!input) return;
  const mostrar = input.type === 'password';
  input.type = mostrar ? 'text' : 'password';
  btn.querySelector('.eye-open').style.display = mostrar ? 'none' : '';
  btn.querySelector('.eye-closed').style.display = mostrar ? '' : 'none';
  btn.setAttribute('aria-label', mostrar ? 'Ocultar contraseña' : 'Mostrar contraseña');
}

function togglePortalSidebar(){
  const nav = $('portalNav');
  const ov  = $('portalSidebarOverlay');
  if(nav) nav.classList.toggle('open');
  if(ov)  ov.classList.toggle('open');
}

async function iniciarPortal(){
  try {
    const r=await fetch('/api/me',{cache:'no-store',credentials:'same-origin'});
    if (r.ok){
      const j=await r.json();
      // Admins y profesores → redirigir al panel
      if (['admin','teacher'].includes(j.role)){ location.replace('/index.html'); return; }
      currentUser={sub:j.sub,role:j.role,nombre:j.nombre,hasPortalAccess:j.hasPortalAccess};

      // Verificar si tiene pago pendiente (onboarding incompleto)
      const statusRes = await fetch('/api/onboarding/status',{cache:'no-store',credentials:'same-origin'});
      if (statusRes.ok){
        const st = await statusRes.json();
        if (st.pendingPayment && st.onboardingToken){
          mostrarLogin();
          mostrarPantallaPago(st);
          return;
        }
      }

      await arrancarPortal();
    } else { mostrarLogin(); }
  } catch { mostrarLogin(); }
}

async function arrancarPortal(){
  ocultarLogin();
  if ($('pUserBadge')) $('pUserBadge').textContent=currentUser.nombre;
  pintarAvatar('pHeaderAvatar', null, currentUser.nombre, 13); // iniciales mientras carga el perfil

  // Cargar clases del alumno en paralelo
  const [clsRes, profileRes] = await Promise.allSettled([
    fetch('/api/my-classes',{credentials:'same-origin'}),
    fetch('/api/profile',{credentials:'same-origin'})
  ]);
  if (clsRes.status==='fulfilled' && clsRes.value.ok) myClasses=await clsRes.value.json();
  if (profileRes.status==='fulfilled' && profileRes.value.ok){
    const p=await profileRes.value.json();
    Object.assign(currentUser, p);
  }
  pintarAvatar('pHeaderAvatar', currentUser.fotoPerfil, currentUser.nombre, 13);

  // Mostrar badge de plan en el header
  const planBadge = $('pPlanBadge');
  if(planBadge && currentUser.plan){
    const planNames = {'suelta':'Clase suelta','35':'1 clase/sem','50':'2 clases/sem','80':'🎓 VIP','bono':'Bono'};
    planBadge.textContent = planNames[currentUser.plan] || currentUser.plan;
    planBadge.style.display = 'inline-flex';
    if(currentUser.plan==='80') planBadge.style.background='rgba(255,215,0,.12)';
  }

  // Si el perfil no está completo, abrir directamente perfil
  if (!currentUser.profileComplete){
    pNavigate('perfil', true);
  } else {
    pNavigate('inicio');
  }
}

/* ── Recargar clases y perfil del alumno desde el servidor ── */
async function recargarMisClases(){
  try {
    const [clsRes, profileRes] = await Promise.allSettled([
      fetch('/api/my-classes',{credentials:'same-origin',cache:'no-store'}),
      fetch('/api/profile',{credentials:'same-origin',cache:'no-store'})
    ]);
    if(clsRes.status==='fulfilled' && clsRes.value.ok)
      myClasses = await clsRes.value.json();
    if(profileRes.status==='fulfilled' && profileRes.value.ok){
      const p = await profileRes.value.json();
      Object.assign(currentUser, p);
    }
  } catch {}
}

/* ── Navegación del portal ── */
async function pNavigate(view, firstTime=false){
  activeView=view;
  document.querySelectorAll('.pnav-btn').forEach(b=>{
    const on=b.dataset.pview===view;
    b.classList.toggle('active',on);
  });
  portalPlayNav();

  // Cerrar sidebar en móvil al navegar
  const nav=$('portalNav'), ov=$('portalSidebarOverlay');
  if(nav) nav.classList.remove('open');
  if(ov)  ov.classList.remove('open');

  const cont=$('portalContent');
  cont.className='';
  cont.innerHTML='';
  const fade=document.createElement('div');
  fade.style.animation='fade .28s cubic-bezier(.4,0,.2,1)';
  cont.appendChild(fade);

  // Recargar clases/perfil al entrar a inicio para reflejar cambios del admin
  if(view==='inicio'){
    await recargarMisClases();
  }

  if (view==='inicio')        renderInicio(fade);
  else if(view==='referidos') renderReferidos(fade);
  else if(view==='perfil')    renderPerfil(fade, firstTime);
}

/* ══════════════════════════════════════════════
   SECCIÓN 0 — INICIO (Dashboard de bienvenida)
══════════════════════════════════════════════ */
async function renderInicio(cont){
  const u = currentUser;
  const tieneVideosPreCarga = u.plan === '80' || u.hasPortalAccess;
  if (tieneVideosPreCarga && !allVideos.length){
    try {
      const r=await fetch('/api/videos',{credentials:'same-origin'});
      if (r.ok) allVideos=await r.json();
    } catch { /* se mostrará el aviso de "sin vídeos" más abajo */ }
  }
  const hora = new Date().getHours();
  const saludo = hora < 13 ? '¡Buenos días' : hora < 20 ? '¡Buenas tardes' : '¡Buenas noches';
  const primerNombre = (u.nombre||'').split(' ')[0] || 'bailarín';
  const foto = u.fotoPerfil || null;

  const hoyNum  = new Date().getDay();
  const manaNum = (hoyNum + 1) % 7;
  const clasesHoy  = myClasses.filter(c => (c.dia ?? 0) === hoyNum).sort((a,b)=>(a.inicio||'').localeCompare(b.inicio||''));
  const clasesMana = myClasses.filter(c => (c.dia ?? 0) === manaNum).sort((a,b)=>(a.inicio||'').localeCompare(b.inicio||''));

  const tieneVideos = u.plan === '80' || u.hasPortalAccess;
  const planLabel_  = planLabel(u.plan);
  const totalClases = myClasses.length;
  const nivelBachata = u.nivelBachata ? `Nivel ${u.nivelBachata}` : '—';
  const nivelSalsa   = u.nivelSalsa   ? `Nivel ${u.nivelSalsa}`   : '—';

  function chipClase(c){
    return `<div class="clase-chip-mini">
      <div class="cc-hora">${c.inicio||''}${c.fin?' – '+c.fin:''}</div>
      <div class="cc-nom">${esc(c.nombre)}</div>
      <div class="cc-est">${esc(c.estilo)}${c.nivelNum?' · Nivel '+c.nivelNum:''}</div>
    </div>`;
  }
  function bloque(lista, lbl){
    if(!lista.length) return `<div style="color:var(--muted);font-size:12.5px;text-align:center;
      padding:16px 0;border:1px dashed rgba(255,215,0,.1);border-radius:var(--r-sm);">
      Sin clases ${lbl.toLowerCase()}</div>`;
    return lista.map(chipClase).join('');
  }

  cont.innerHTML = `<div id="inicioWrap">

    <!-- ── Hero + estadísticas, fusionados en una sola tarjeta ── -->
    <div class="bienvenida-hero" style="display:flex;align-items:center;justify-content:space-between;gap:20px;flex-wrap:wrap;">
      <div style="display:flex;align-items:center;gap:16px;">
        <div id="pHeroAvatar" class="hero-avatar" onclick="pNavigate('perfil')" title="Editar mi foto de perfil"></div>
        <div>
          <div style="font-size:10px;letter-spacing:2px;color:var(--muted);text-transform:uppercase;margin-bottom:4px;">Academia Malevo</div>
          <h1 style="margin-bottom:2px;">${saludo}, ${esc(primerNombre)}! 👋</h1>
          <div class="bienvenida-plan" style="margin-top:6px;">
            🎓 ${esc(planLabel_)}
            ${tieneVideos ? '&nbsp;·&nbsp;<span style="color:var(--white);">✓ Aula Virtual</span>' : ''}
          </div>
        </div>
      </div>
      <div style="display:flex;gap:10px;flex-wrap:wrap;">
        <div class="stat-box" style="min-width:66px;padding:12px 14px;">
          <div class="stat-num" style="font-size:20px;${u.nivelBachata?'color:var(--gold);':''}">${nivelBachata}</div>
          <div class="stat-lbl">Bachata</div>
        </div>
        <div class="stat-box" style="min-width:66px;padding:12px 14px;">
          <div class="stat-num" style="font-size:20px;${u.nivelSalsa?'color:var(--gold);':''}">${nivelSalsa}</div>
          <div class="stat-lbl">Salsa</div>
        </div>
        <div class="stat-box" style="min-width:66px;padding:12px 14px;">
          <div class="stat-num" style="font-size:20px;">${totalClases}</div>
          <div class="stat-lbl">Clases</div>
        </div>
        <div class="stat-box" style="min-width:66px;padding:12px 14px;">
          <div class="stat-num" style="font-size:18px;">${u.rol==='leader'?'🕺':u.rol==='follower'?'💃':'🔄'}</div>
          <div class="stat-lbl">${u.rol==='leader'?'Leader':u.rol==='follower'?'Follower':'Indist.'}</div>
        </div>
      </div>
    </div>

    <!-- Racha de práctica -->
    ${(()=>{ const racha=calcularRachaSemanas();
      return racha>0
        ? `<div style="display:inline-flex;align-items:center;gap:8px;margin:14px 0 0;
            padding:8px 18px;border-radius:30px;font-size:12.5px;color:var(--text-2);
            background:var(--card-bg);border:1px solid var(--card-border);">
            🔥 Racha actual: <strong style="color:var(--white);margin-left:2px;">${racha} semana${racha!==1?'s':''} activa${racha!==1?'s':''}</strong>
           </div>`
        : `<div style="display:inline-flex;align-items:center;gap:8px;margin:14px 0 0;
            padding:8px 18px;border-radius:30px;font-size:12px;color:var(--muted);
            background:var(--card-bg);border:1px solid var(--card-border);">
            🔥 Mira un vídeo esta semana para empezar tu racha
           </div>`;
    })()}


    <!-- Esta semana -->
    <div class="h2" style="margin-bottom:14px;">Esta semana</div>
    <div class="inicio-grid" style="margin-bottom:28px;">
      <div class="semana-card ${clasesHoy.length?'semana-hoy':''}">
        <div class="semana-dia-label ${clasesHoy.length?'hoy':''}">
          ${clasesHoy.length?'● HOY — ':''}${DIAS_FULL[hoyNum]}</div>
        ${!myClasses.length?'<div style="color:var(--muted);font-size:12.5px;text-align:center;padding:16px 0;">Sin clases asignadas aún</div>':bloque(clasesHoy,'Hoy')}
      </div>
      <div class="semana-card">
        <div class="semana-dia-label">MAÑANA — ${DIAS_FULL[manaNum]}</div>
        ${!myClasses.length?'<div style="color:var(--muted);font-size:12.5px;text-align:center;padding:16px 0;">Sin clases asignadas aún</div>':bloque(clasesMana,'Mañana')}
      </div>
    </div>

    <!-- ══ SECCIÓN VÍDEOS (fusionada en Inicio) ══ -->
    <div id="seccionVideos">${construirBloqueVideos()}</div>

    <!-- Invitar amigos (fusionado desde su propia sección) -->
    <div class="h2" style="margin-bottom:14px;">🎁 Invitar amigos</div>
    <div id="refBlock">
      <div style="color:var(--muted);font-size:13px;padding:10px 0;">Cargando…</div>
    </div>

    <!-- Mi perfil -->
    <div class="h2" style="margin-bottom:14px;margin-top:28px;">Mi espacio</div>
    <div class="inicio-grid-3" style="margin-bottom:28px;">
      <div class="acceso-card" onclick="pNavigate('perfil')">
        <div class="acceso-icon">👤</div>
        <div class="acceso-title">Mi perfil</div>
        <div class="acceso-desc">Actualiza tus datos, foto y preferencias de baile.</div>
        ${!u.profileComplete?'<span class="badge warn">⚠ Incompleto</span>':'<span class="badge ok">✓ Completado</span>'}
      </div>
      <div class="acceso-card" style="cursor:default;">
        <div class="acceso-icon">📞</div>
        <div class="acceso-title">Contacto</div>
        <div class="acceso-desc">¿Dudas? Habla con Gastón o Gimena.</div>
        <span class="badge muted">Academia Malevo</span>
      </div>
    </div>

    ${!myClasses.length?`
    <div style="background:var(--card-bg);border:1px solid var(--card-border);
      border-radius:var(--r-lg);padding:20px 24px;display:flex;gap:16px;align-items:flex-start;">
      <span style="font-size:22px;flex:0 0 auto;">ℹ️</span>
      <div>
        <div style="font-size:13.5px;font-weight:600;color:var(--white);margin-bottom:4px;">Tu horario estará disponible pronto</div>
        <div style="font-size:13px;color:var(--text-2);line-height:1.65;">
          Una vez confirmada tu matrícula, Gastón o Gimena asignarán tus clases y aparecerán aquí automáticamente.</div>
      </div>
    </div>`:''}
  </div>`;

  pintarAvatar('pHeroAvatar', foto, u.nombre, 24);

  // Inicializar el bloque de vídeos (reproductor + playlists) si tiene acceso
  if (tieneVideos) inicializarBloqueVideos();

  // Cargar bloque de referidos de forma asíncrona
  cargarRefBlock();
}

/* ── Carga asíncrona del bloque de referidos en el Inicio ── */
async function cargarRefBlock(){
  const block = $('refBlock');
  if (!block) return;
  try {
    const r = await fetch('/api/referral',{credentials:'same-origin'});
    if (!r.ok) throw new Error();
    const data = await r.json();
    const link = `${location.origin}/registro.html?ref=${data.code}`;
    block.innerHTML = `
      <div style="background:linear-gradient(135deg,rgba(255,215,0,.1),rgba(138,112,0,.07));
        border:1px solid rgba(255,215,0,.22);border-radius:var(--r-lg);padding:22px 24px;">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px;">
          <div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,215,0,.12);
            border-radius:12px;padding:14px;text-align:center;">
            <div style="font-family:'Sora',sans-serif;font-size:28px;font-weight:800;color:var(--gold-2);">${data.referred}</div>
            <div style="font-size:10.5px;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-top:4px;">Amigos invitados</div>
          </div>
          <div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,215,0,.12);
            border-radius:12px;padding:14px;text-align:center;">
            <div style="font-family:'Sora',sans-serif;font-size:28px;font-weight:800;
              color:${data.discount>0?'var(--ok)':'var(--muted)'};">${data.discount}%</div>
            <div style="font-size:10.5px;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-top:4px;">Descuento activo</div>
          </div>
        </div>
        <p style="font-size:13px;color:var(--text-2);margin-bottom:12px;line-height:1.6;">
          Comparte tu enlace. Cada amigo que pague te da un <strong style="color:var(--gold-light);">30% de descuento</strong> en tu cuota.</p>
        <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
          <input type="text" id="refLink" value="${esc(link)}" readonly
            style="background:rgba(255,215,0,.06);border-color:rgba(255,215,0,.2);
              color:var(--gold-light);font-size:12.5px;flex:1;min-width:200px;cursor:pointer;"
            onclick="this.select();">
          <button class="btn sm" onclick="copiarEnlace('${esc(link)}')">📋 Copiar</button>
          <button class="btn sm sec" onclick="compartirWhatsapp('${esc(link)}')">💬 WhatsApp</button>
        </div>
      </div>`;
  } catch {
    block.innerHTML = `<div style="color:var(--muted);font-size:13px;padding:8px 0;">
      No se pudo cargar el enlace de referidos.</div>`;
  }
}

/* ══════════════════════════════════════════════
   SECCIÓN 1 — MIS VÍDEOS (solo VIP plan 80)
══════════════════════════════════════════════ */
/* ── Construye el HTML del bloque de vídeos para insertarlo en el muro de Inicio.
   No hace fetch (eso ya lo hizo renderInicio antes de llamar aquí). ── */
function construirBloqueVideos(){
  const tieneAcceso = currentUser.plan === '80' || currentUser.hasPortalAccess ||
    PORTAL_PLANS.includes(currentUser.plan);

  if (!tieneAcceso){
    return `<div class="card" style="text-align:center;padding:40px 32px;margin-bottom:32px;">
      <div style="font-size:48px;margin-bottom:14px;">🎓</div>
      <h2 style="font-family:'Sora',sans-serif;font-size:20px;font-weight:700;
        margin-bottom:10px;color:var(--white);">Aula Virtual exclusiva VIP</h2>
      <p style="color:var(--text-2);font-size:13.5px;line-height:1.7;margin-bottom:24px;">
        El acceso a los vídeos está disponible con el plan<br>
        <strong style="color:var(--gold);">VIP · Full Pass · 80 €/mes</strong></p>
      <p style="color:var(--muted);font-size:12.5px;">
        Habla con Gastón o Gimena para actualizar tu plan.</p>
    </div>`;
  }

  if (!allVideos.length){
    return `<div class="vacio" style="margin-bottom:32px;">Sin vídeos disponibles todavía.</div>`;
  }

  const nivelesCards = [];
  DISCIPLINAS_VIDEO.forEach(disc=>{
    const acceso = nivelesToAcceso(disc);
    [1,2,3,4].forEach(n=>{
      if (!acceso.includes(n)) return; // sin acceso a este nivel → ni se construye la tarjeta
      const vids = videosDeNivel(disc,n);
      if (!vids.length) return;
      const vistos = vids.filter(v=>esVisto(v.id)).length;
      const pct = Math.round(vistos/vids.length*100);
      nivelesCards.push({disc,n,vids,vistos,pct,bonus:bonusDeNivel(disc,n)});
    });
  });
  const calent = calentamientos();
  const lastId = getLastVideoId();
  const lastVideo = lastId ? allVideos.find(v=>v.id===lastId) : null;

  let html = '';

  if (lastVideo){
    html += `<div class="card" style="margin-bottom:20px;display:flex;align-items:center;gap:16px;cursor:pointer;"
      onclick="reproducirEnHub('${lastVideo.id}')">
      <div style="width:44px;height:44px;border-radius:50%;background:rgba(255,215,0,.1);
        border:1px solid var(--gold);display:flex;align-items:center;justify-content:center;flex:0 0 auto;color:var(--gold);">▶</div>
      <div style="flex:1;min-width:0;">
        <div style="font-size:10px;text-transform:uppercase;letter-spacing:1.5px;color:var(--muted);margin-bottom:3px;">Continuar viendo</div>
        <div style="font-size:14px;font-weight:700;color:var(--white);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(lastVideo.titulo)}</div>
      </div>
      <span style="color:var(--gold);font-size:20px;">›</span>
    </div>`;
  }

  html += `<div class="section-divider"><span class="line"></span><span class="label">▶ Mis Vídeos</span><span class="line"></span></div>`;

  if (!nivelesCards.length){
    html += `<div class="vacio" style="margin-bottom:32px;">Aún no hay vídeos para tu nivel. Habla con Gastón o Gimena.</div>`;
  } else {
    html += `<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:16px;margin-bottom:20px;">`;
    nivelesCards.forEach(nc=>{
      const bonusDesbloqueados = nc.bonus.filter((_,i)=>nc.vistos>=(i+1)*5).length;
      html += `<div class="card" style="cursor:pointer;" onclick="abrirNivelHub('${nc.disc}',${nc.n})">
        <div style="font-weight:700;color:var(--white);font-size:13.5px;margin-bottom:12px;">${nc.disc} · ${nivelLabelCorto(nc.n)}</div>
        <div style="display:flex;align-items:baseline;gap:6px;margin-bottom:10px;">
          <span style="font-family:'Sora',sans-serif;font-size:32px;font-weight:800;color:var(--gold);">${nc.vids.length}</span>
          <span style="font-size:10px;color:var(--muted);letter-spacing:1px;">CLASES</span>
        </div>
        <div style="display:flex;gap:3px;margin-bottom:10px;">
          ${nc.vids.map(v=>`<div style="flex:1;height:5px;border-radius:2px;
            background:${esVisto(v.id)?'var(--gold)':'rgba(255,255,255,.1)'};transition:background .3s;"></div>`).join('')}
        </div>
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <span style="font-size:11px;color:var(--muted);">${nc.vistos}/${nc.vids.length} vistas</span>
          <span style="font-size:12px;color:var(--gold);font-weight:600;">Ver →</span>
        </div>
        ${nc.bonus.length ? `<div style="display:flex;align-items:center;gap:6px;margin-top:12px;padding-top:10px;border-top:1px solid var(--card-border);">
            <span style="font-size:13px;">🎁</span>
            <span style="font-size:10.5px;color:var(--muted);">Bonus: ${bonusDesbloqueados}/${nc.bonus.length} desbloqueados</span>
          </div>` : ''}
      </div>`;
    });
    html += `</div>`;
  }

  html += `<div id="aulaWrap" class="card" style="margin-bottom:32px;padding:0;overflow:hidden;display:none;border-color:var(--gold);">
      <div id="panelVideoHeader" style="display:flex;align-items:center;justify-content:space-between;
        padding:16px 22px;border-bottom:1px solid var(--card-border);">
        <div>
          <div id="panelVideoTitulo" style="font-size:15px;font-weight:700;color:var(--white);"></div>
          <div id="panelVideoSub" style="font-size:11.5px;color:var(--muted);margin-top:2px;"></div>
        </div>
        <button class="btn sm sec" onclick="cerrarPanelVideo()">× Cerrar</button>
      </div>
      <div id="playerWrap">
        <div id="playerPlaceholder" style="position:absolute;inset:0;display:flex;flex-direction:column;
          align-items:center;justify-content:center;color:var(--muted);gap:14px;background:#0e0e0e;">
          <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width=".8" opacity=".2">
            <circle cx="12" cy="12" r="10"/><polygon points="10,8 16,12 10,16" fill="currentColor" opacity=".5"/>
          </svg>
          <span style="font-size:14px;letter-spacing:.5px;">Selecciona una clase para empezar</span>
        </div>
      </div>
      <div id="videoMeta">
        <div id="videoTitle" style="display:none;"></div>
        <div id="videoNotes"></div>
      </div>
      <div id="videoCurrentLabel" class="video-status-bar" style="display:none;">
        <span id="videoCurrentLabelText"></span>
      </div>
      <div id="videoListRow" style="display:flex;gap:16px;align-items:flex-start;padding:20px 24px;">
        <div id="videoList" style="flex:1;min-width:0;display:flex;flex-direction:column;gap:8px;"></div>
        <div id="spotifyPanelWrap" style="flex:0 0 300px;display:none;flex-direction:column;gap:12px;"></div>
      </div>
    </div>`;

  // ── Calentamientos: sección propia e independiente, no mezclada con los niveles ──
  if (calent.length){
    html += `<div class="card" style="margin-bottom:32px;padding:22px 20px;">
      <div class="h2" style="margin-bottom:14px;">🔥 Calentamiento y estiramiento</div>
      <p style="font-size:12px;color:var(--muted);margin:-8px 0 14px;">Independiente de tus niveles — úsalos antes de ensayar.</p>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:12px;">
        ${calent.map(v=>`<div class="video-item" onclick="reproducirEnHub('${v.id}')">
          ${esVisto(v.id)?'<span class="vi-done" title="Ya lo hiciste"></span>':''}
          <div class="vi-title">${esc(v.titulo)}</div>
          <div class="vi-disc">Calentamiento</div>
        </div>`).join('')}
      </div>
    </div>`;
  }

  html += renderPlaylistsSection();
  html += `<div id="eventosSectionWrap">${renderEventosSection()}</div>`;

  return html;
}

/* ── Post-montaje: arranca el reproductor y la primera pestaña de playlist.
   Se llama después de insertar construirBloqueVideos() en el DOM. ── */
function inicializarBloqueVideos(){
  if (!allVideos.length) return;
  const lastId = getLastVideoId();
  const lastVideo = lastId ? allVideos.find(v=>v.id===lastId) : null;
  if (lastVideo){
    reproducirEnHub(lastVideo.id, true);
  } else {
    const disc0 = DISCIPLINAS_VIDEO.find(disc=>{
      const acceso=nivelesToAcceso(disc);
      return [1,2,3,4].some(n=>acceso.includes(n) && videosDeNivel(disc,n).length);
    });
    if (disc0){
      const acceso=nivelesToAcceso(disc0);
      const n0=[1,2,3,4].find(n=>acceso.includes(n) && videosDeNivel(disc0,n).length);
      if (n0) mostrarListaNivel(disc0,n0);
    }
  }
  const primerTabPlaylist = document.querySelector('#playlistTabs .disc-tab');
  if (primerTabPlaylist) primerTabPlaylist.click();
}

/* ── Calcula qué niveles puede ver el alumno en una disciplina ──
   Devuelve SIEMPRE un array (nunca null): sin nivel asignado = sin acceso.
   Antes, "sin nivel asignado" devolvía null (= sin restricción, veía TODO),
   lo cual dejaba todos los niveles superiores abiertos por error. */
function nivelesToAcceso(disc){
  const u = currentUser;
  // VIP: acceso acumulado hasta su nivelMax en esa disciplina
  if (u.plan === '80'){
    const nivelMax = disc === 'Bachata' ? (parseInt(u.nivelBachata)||0)
                   : disc === 'Salsa'   ? (parseInt(u.nivelSalsa)||0)
                   : 0;
    if (!nivelMax) return []; // VIP sin nivel asignado todavía → sin acceso hasta que se le asigne
    return Array.from({length: nivelMax}, (_,i) => i+1);
  }
  // Plan no-VIP con acceso portal: solo su nivel exacto
  const nivelExacto = disc === 'Bachata' ? parseInt(u.nivelBachata)||null
                    : disc === 'Salsa'   ? parseInt(u.nivelSalsa)||null
                    : null;
  if (!nivelExacto) return []; // sin nivel asignado → sin acceso (fail-closed)
  return [nivelExacto];
}

/* ── Muestra la lista de vídeos de un nivel en #videoList y reproduce
   el primero no visto (o el primero, si ya los vio todos) ── */
function mostrarListaNivel(disc, nivel){
  activeDisciplina=disc; activeNivel=nivel;
  const vids = videosDeNivel(disc,nivel);
  const cont=$('videoList'); if (!cont) return;

  $('aulaWrap') && ($('aulaWrap').style.display='');
  if ($('panelVideoTitulo')) $('panelVideoTitulo').textContent = `${disc} · ${nivelLabel(nivel)}`;
  if ($('panelVideoSub'))    $('panelVideoSub').textContent    = `${vids.length} clase${vids.length!==1?'s':''}`;
  const spotifyWrap=$('spotifyPanelWrap');
  if (spotifyWrap){
    const html = construirEmbedsSpotify(disc, nivel);
    spotifyWrap.innerHTML = html;
    spotifyWrap.style.display = html ? 'flex' : 'none';
  }

  if (!vids.length){
    cont.innerHTML='<div style="padding:20px 22px;color:var(--muted);font-size:13px;text-align:center;">Sin clases en este nivel.</div>';
    return;
  }
  const vistosCount = vids.filter(v=>esVisto(v.id)).length;
  const bonus = bonusDeNivel(disc,nivel);

  let html = vids.map((v,i)=>`<div class="video-row${esVisto(v.id)?' visto':''}" data-vid="${v.id}" onclick="playVideo('${v.id}')">
      ${esVisto(v.id)?'<span class="vi-done" title="Ya la viste"></span>':''}
      <div class="video-row-num">${i+1}</div>
      <div style="flex:1;min-width:0;">
        <div class="video-row-title">${esc(v.titulo)}</div>
        <div class="video-row-sub">${esc(v.disciplina)} · ${nivelLabel(v.nivel)}</div>
      </div>
      <span class="video-row-arrow">▶</span>
    </div>`).join('');

  if (bonus.length){
    html += `<div style="display:flex;align-items:center;gap:8px;margin:18px 0 10px;padding-top:14px;border-top:1px solid var(--card-border);">
      <span style="font-size:14px;">🎁</span>
      <span style="font-size:10px;text-transform:uppercase;letter-spacing:2px;color:var(--muted);font-weight:700;">Bonus</span>
    </div>`;
    html += bonus.map((bv,i)=>{
      const umbral=(i+1)*5;
      const desbloqueado = vistosCount>=umbral;
      if (desbloqueado){
        return `<div class="video-row${esVisto(bv.id)?' visto':''}" data-vid="${bv.id}" onclick="playVideo('${bv.id}')">
          ${esVisto(bv.id)?'<span class="vi-done" title="Ya lo viste"></span>':''}
          <div class="video-row-num" style="background:var(--gold);color:#0a0a0a;border-color:transparent;">🎁</div>
          <div style="flex:1;min-width:0;">
            <div class="video-row-title">${esc(bv.titulo)}</div>
            <div class="video-row-sub">Bonus ${i+1} · Desbloqueado</div>
          </div>
          <span class="video-row-arrow" style="opacity:1;">▶</span>
        </div>`;
      }
      return `<div class="video-row" style="opacity:.55;cursor:not-allowed;" title="Completa ${umbral} vídeos del nivel para desbloquear este bonus">
        <div class="video-row-num">🔒</div>
        <div style="flex:1;min-width:0;">
          <div class="video-row-title">Bonus ${i+1} bloqueado</div>
          <div class="video-row-sub">Completa ${umbral} vídeos del nivel (${vistosCount}/${umbral})</div>
        </div>
      </div>`;
    }).join('');
  }

  cont.innerHTML = html;
  const primero = vids.find(v=>!esVisto(v.id)) || vids[0];
  playVideo(primero.id);
}

/* ── Abre un nivel desde la tarjeta y hace scroll hasta el panel del reproductor ── */
function abrirNivelHub(disc, nivel){
  mostrarListaNivel(disc, nivel);
  $('aulaWrap')?.scrollIntoView({behavior:'smooth', block:'start'});
  portalPlayNav();
}

/* ── Cierra el panel del reproductor (botón "× Cerrar") ── */
function cerrarPanelVideo(){
  const wrap=$('aulaWrap'); if (!wrap) return;
  wrap.style.display='none';
  const label=$('videoCurrentLabel'); if (label) label.style.display='none';
}

/* ── Reproduce un vídeo suelto (continuar viendo / calentamiento / taller),
   reconstruyendo el contexto de lista que corresponda ── */
function reproducirEnHub(id, sinScroll){
  const v = allVideos.find(x=>x.id===id);
  if (!v) return;
  $('aulaWrap') && ($('aulaWrap').style.display='');

  if (!v.tipo || v.tipo==='clase' || v.tipo==='bonus'){
    mostrarListaNivel(v.disciplina, v.nivel);
    playVideo(id); // seleccionar exactamente este, no el primero no-visto
  } else if (v.tipo==='calentamiento'){
    const spotifyWrap=$('spotifyPanelWrap'); if (spotifyWrap){ spotifyWrap.innerHTML=''; spotifyWrap.style.display='none'; }
    const grupo = calentamientos();
    if ($('panelVideoTitulo')) $('panelVideoTitulo').textContent = '🔥 Calentamiento y estiramiento';
    if ($('panelVideoSub'))    $('panelVideoSub').textContent    = `${grupo.length} vídeo${grupo.length!==1?'s':''}`;
    const cont=$('videoList');
    if (cont){
      cont.innerHTML = grupo.map((gv,i)=>`<div class="video-row${esVisto(gv.id)?' visto':''}" data-vid="${gv.id}" onclick="playVideo('${gv.id}')">
          ${esVisto(gv.id)?'<span class="vi-done"></span>':''}
          <div class="video-row-num">${i+1}</div>
          <div style="flex:1;min-width:0;"><div class="video-row-title">${esc(gv.titulo)}</div></div>
          <span class="video-row-arrow">▶</span>
        </div>`).join('');
    }
    playVideo(id);
  }
  if (!sinScroll) $('aulaWrap')?.scrollIntoView({behavior:'smooth', block:'start'});
}

/* ── Playlists Oficiales — 8 pestañas (Bachata/Salsa × Nivel 1-4) ──
   Reutiliza la misma colección db.videos vía /api/videos con tipo:'playlist',
   sin necesitar un endpoint nuevo en el servidor. ── */
function renderPlaylistsSection(){
  const combos=[];
  DISCIPLINAS_VIDEO.forEach(d=>{ for(let n=1;n<=4;n++) combos.push({d,n}); });
  return `<div class="h2" style="margin-bottom:12px;">🎵 Playlists Oficiales</div>
    <div class="card" style="margin-bottom:32px;padding:22px 20px;">
      <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:18px;" id="playlistTabs">
        ${combos.map((c,i)=>`<button class="disc-tab${i===0?' active':''}"
          onclick="mostrarPlaylist('${c.d}',${c.n},this)">🎵 ${c.d} ${nivelLabelCorto(c.n)}</button>`).join('')}
      </div>
      <div id="playlistBody"></div>
    </div>`;
}
function mostrarPlaylist(disc, nivel, btn){
  document.querySelectorAll('#playlistTabs .disc-tab').forEach(b=>b.classList.toggle('active', b===btn));
  const items = playlistsCatalogo().filter(p=>p.disciplina===disc && p.nivel===nivel);
  const body=$('playlistBody'); if (!body) return;
  if (!items.length){
    body.innerHTML = `<div style="color:var(--muted);font-size:13px;padding:16px 0;text-align:center;">
      Aún no se ha añadido la playlist de ${esc(disc)} ${nivelLabel(nivel)}.</div>`;
    return;
  }
  body.innerHTML = items.map(item=>`<div style="display:flex;align-items:center;gap:14px;padding:8px 0;flex-wrap:wrap;
      border-bottom:1px solid var(--card-border);">
    <div style="width:44px;height:44px;border-radius:12px;background:rgba(255,215,0,.1);
      border:1px solid var(--gold);display:flex;align-items:center;justify-content:center;font-size:20px;flex:0 0 auto;">🎵</div>
    <div style="flex:1;min-width:160px;">
      <div style="font-size:14px;font-weight:700;color:var(--white);">${esc(item.titulo||disc+' '+nivelLabel(nivel))}</div>
      <div style="font-size:12px;color:var(--muted);">${esc(disc)} · ${nivelLabel(nivel)}</div>
    </div>
    <a href="${esc(item.url)}" target="_blank" class="btn sm" style="background:var(--card-bg);border:1px solid var(--gold);color:var(--gold);box-shadow:none;">🎧 Abrir ↗</a>
  </div>`).join('');
}

/* ── Eventos y Talleres — cuadrícula con encuesta de asistencia ──
   Igual que las playlists, usa db.videos con tipo:'evento' (imagen en .url,
   fecha/descripción en .notas como JSON) para no requerir endpoint nuevo. ── */
function toYoutubeEmbed(url){
  if (!url) return url;
  const m1=url.match(/[?&]v=([^&]+)/); if (m1) return 'https://www.youtube.com/embed/'+m1[1];
  const m2=url.match(/youtu\.be\/([^?&]+)/); if (m2) return 'https://www.youtube.com/embed/'+m2[1];
  return url;
}
function eventosCatalogo(){
  return allVideos.filter(v=>v.tipo==='evento').map(v=>{
    let meta={}; try{ meta=JSON.parse(v.notas||'{}'); }catch{}
    return {id:v.id, titulo:v.titulo, imagen:v.url, tipoMedia:meta.tipoImagen||'upload', fecha:meta.fecha||'', descripcion:meta.descripcion||''};
  }).sort((a,b)=>(a.fecha||'').localeCompare(b.fecha||''));
}
function formatearFechaEvento(iso){
  try{ const d=new Date(iso+'T00:00:00'); return d.toLocaleDateString('es-ES',{weekday:'long',day:'numeric',month:'long'}); }
  catch{ return iso; }
}
function renderEventosSection(){
  const eventos = eventosCatalogo();
  const misRSVP = currentUser.eventRsvps || {};
  return `<div class="card" style="padding:24px 22px;">
    <div class="h2" style="margin-bottom:${eventos.length?'16px':'4px'};">🎉 Eventos y Talleres</div>
    ${!eventos.length
      ? `<div style="color:var(--muted);font-size:13px;padding:6px 0;">No hay eventos programados por ahora. Vuelve pronto.</div>`
      : `<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:16px;">
        ${eventos.map(ev=>{
          const resp = misRSVP[ev.id];
          return `<div style="background:var(--bg);border:1px solid var(--card-border);border-radius:var(--r-lg);overflow:hidden;">
            ${ev.imagen?(ev.tipoMedia==='youtube'
                ? `<div style="width:100%;aspect-ratio:16/9;">
                    <iframe src="${esc(toYoutubeEmbed(ev.imagen))}" style="width:100%;height:100%;border:none;" allowfullscreen></iframe>
                   </div>`
                : `<div style="width:100%;height:140px;background:#000 url('${esc(ev.imagen)}') center/cover;"></div>`)
              :''}
            <div style="padding:18px 20px;">
              <div style="font-size:14.5px;font-weight:700;color:var(--white);margin-bottom:4px;">${esc(ev.titulo)}</div>
              ${ev.fecha?`<div style="font-size:12px;color:var(--muted);margin-bottom:10px;">📅 ${esc(formatearFechaEvento(ev.fecha))}</div>`:''}
              ${ev.descripcion?`<div style="font-size:12.5px;color:var(--text-2);margin-bottom:14px;line-height:1.6;">${esc(ev.descripcion)}</div>`:''}
              <div style="display:flex;gap:8px;">
                <button class="btn sm" style="flex:1;${resp==='si'?'':'background:var(--card-bg);border:1px solid var(--card-border);color:var(--text-2);box-shadow:none;'}"
                  onclick="responderEvento('${ev.id}','si')">✓ Sí, asistiré</button>
                <button class="btn sm sec" style="flex:1;${resp==='no'?'border-color:var(--text-2);color:var(--white);':''}"
                  onclick="responderEvento('${ev.id}','no')">No podré</button>
              </div>
            </div>
          </div>`;
        }).join('')}
      </div>`}
  </div>`;
}
async function responderEvento(eventId, respuesta){
  currentUser.eventRsvps = currentUser.eventRsvps || {};
  currentUser.eventRsvps[eventId] = respuesta;
  const wrap=$('eventosSectionWrap');
  if (wrap) wrap.innerHTML = renderEventosSection();
  showToast(respuesta==='si' ? '¡Genial, cuentan contigo! 🎉' : 'Anotado, gracias por avisar','ok');
  portalPlaySuccess();
  try {
    await fetch('/api/profile',{method:'PUT',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({eventRsvps: currentUser.eventRsvps}), credentials:'same-origin'});
  } catch {}
}

/* ── Vídeos vistos: se guardan con fecha (para poder calcular la racha semanal).
   Guardado local por alumno — el sistema no registra analítica de reproducción
   en el servidor, así que esto vive en localStorage del dispositivo. ── */
function _watchedKey(){ return 'malevo_watched_'+(currentUser&&currentUser.sub||'anon'); }
function getWatchedMap(){
  try {
    const raw = JSON.parse(localStorage.getItem(_watchedKey())||'{}');
    if (Array.isArray(raw)){ // compat con el formato anterior (solo array de ids)
      const migrado={}; raw.forEach(id=>migrado[id]=Date.now());
      localStorage.setItem(_watchedKey(), JSON.stringify(migrado));
      return migrado;
    }
    return raw;
  } catch { return {}; }
}
function esVisto(id){ return !!getWatchedMap()[id]; }
function marcarVisto(id){
  const m=getWatchedMap();
  if (m[id]) return;
  m[id]=Date.now();
  try { localStorage.setItem(_watchedKey(), JSON.stringify(m)); } catch {}
  _actualizarRachaServidor(); // fire-and-forget: sube/actualiza la racha global
}

/* ── Racha de práctica — GLOBAL, persistida en el perfil del alumno (servidor) ──
   Se guarda como {streakWeeks, streakLastWeek} vía PUT /api/profile (el mismo
   endpoint que el alumno ya usa para su perfil), así es consistente entre
   dispositivos. Se basa en actividad real de vídeo, no en asistencia oficial
   de clase (el portal no tiene acceso a esos datos). ── */
function _inicioSemana(ts){
  const d=new Date(ts);
  const diaLunes=(d.getDay()+6)%7; // lunes=0 ... domingo=6
  d.setHours(0,0,0,0);
  d.setDate(d.getDate()-diaLunes);
  return d.getTime();
}
const MS_SEMANA=7*24*60*60*1000;

/* Valor a MOSTRAR ahora mismo, sin necesitar que el alumno vea algo hoy:
   si la última semana activa guardada quedó a más de 1 semana de hoy, la
   racha se considera rota aunque el servidor aún no lo sepa. */
function calcularRachaSemanas(){
  const u=currentUser;
  if (u && u.streakWeeks!=null && u.streakLastWeek!=null){
    const semanaActual=_inicioSemana(Date.now());
    const gap=Math.round((semanaActual-u.streakLastWeek)/MS_SEMANA);
    return gap<=1 ? u.streakWeeks : 0;
  }
  // Respaldo local (primer arranque, o si el servidor no devolvió el campo)
  const fechas=Object.values(getWatchedMap());
  if (!fechas.length) return 0;
  const semanas=new Set(fechas.map(_inicioSemana));
  let racha=0, cursor=_inicioSemana(Date.now());
  while (semanas.has(cursor)){ racha++; cursor-=MS_SEMANA; }
  return racha;
}

/* Actualiza la racha al ver un vídeo y la sube al servidor. */
async function _actualizarRachaServidor(){
  const u=currentUser;
  const semanaActual=_inicioSemana(Date.now());
  const ultima=u.streakLastWeek||0;
  let nuevaRacha;
  if (!ultima){
    nuevaRacha=1;
  } else {
    const gap=Math.round((semanaActual-ultima)/MS_SEMANA);
    if (gap===0) return; // esta semana ya estaba contabilizada
    nuevaRacha = gap===1 ? (u.streakWeeks||0)+1 : 1;
  }
  u.streakWeeks=nuevaRacha; u.streakLastWeek=semanaActual;
  try {
    await fetch('/api/profile',{method:'PUT',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({streakWeeks:nuevaRacha, streakLastWeek:semanaActual}), credentials:'same-origin'});
  } catch {}
}

/* ── "Continuar viendo": última clase reproducida ── */
function _lastVideoKey(){ return 'malevo_lastvideo_'+(currentUser&&currentUser.sub||'anon'); }
function getLastVideoId(){ try { return localStorage.getItem(_lastVideoKey())||null; } catch { return null; } }
function setLastVideoId(id){ try { localStorage.setItem(_lastVideoKey(), id); } catch {} }

/* ── Catálogo de vídeo por tipo (clase de nivel / calentamiento / taller) ──
   Vídeos "normales" no tienen v.tipo o tienen tipo:'clase'. Se reutiliza la
   misma colección db.videos / endpoint /api/videos ya existente. ── */
function videosDeNivel(disc,nivel){
  return allVideos.filter(v=>v.disciplina===disc && v.nivel===nivel && (!v.tipo||v.tipo==='clase'))
    .sort((a,b)=>(a.orden||0)-(b.orden||0));
}
/* ── Bonus progresivos: solo aplica a niveles 1, 2 y 3 (no a Coreografías/4).
   Hasta 3 vídeos, se desbloquean a los 5/10/15 vídeos completados del nivel. ── */
function bonusDeNivel(disc,nivel){
  if (nivel===4) return [];
  return allVideos.filter(v=>v.disciplina===disc && v.nivel===nivel && v.tipo==='bonus')
    .sort((a,b)=>(a.orden||0)-(b.orden||0)).slice(0,3);
}
function calentamientos(){
  return allVideos.filter(v=>v.tipo==='calentamiento').sort((a,b)=>(a.orden||0)-(b.orden||0));
}
function playlistsCatalogo(){
  return allVideos.filter(v=>v.tipo==='playlist');
}

/* ── El admin puede pegar el <iframe> completo de Spotify, el enlace de
   "Insertar" (embed) o el de "Copiar enlace a la playlist" (normal, no embed).
   Esto normaliza cualquiera de los tres a una URL de embed válida. ── */
function extraerSpotifyEmbed(raw){
  if (!raw) return null;
  const srcMatch = raw.match(/src=["']([^"']+)["']/);
  let src = srcMatch ? srcMatch[1] : (/^https?:\/\//.test(raw.trim()) ? raw.trim() : null);
  if (!src) return null;
  // "Copiar enlace" da open.spotify.com/playlist/ID — sin /embed/, hay que insertarlo
  if (src.includes('open.spotify.com/') && !src.includes('/embed/')){
    src = src.replace('open.spotify.com/', 'open.spotify.com/embed/');
  }
  return { src };
}

/* ── Incrusta el/los reproductor(es) de Spotify de este nivel, en tamaño
   completo (con la lista de canciones visible), apilados en la columna
   derecha junto a la lista de clases. Son iframes independientes: no pausan
   ni afectan al vídeo de YouTube. ── */
function construirEmbedsSpotify(disc, nivel){
  const items = playlistsCatalogo().filter(p=>p.disciplina===disc && p.nivel===nivel);
  return items.map(p=>{
    const embed = extraerSpotifyEmbed(p.url);
    if (!embed) return '';
    return `<iframe src="${esc(embed.src)}" width="100%" height="352" style="border-radius:12px;display:block;border:none;"
      frameBorder="0" loading="lazy" title="${esc(p.titulo)}"
      allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"></iframe>`;
  }).filter(Boolean).join('');
}

function playVideo(id){
  activeVideoId=id;
  const v=allVideos.find(x=>x.id===id); if(!v) return;

  marcarVisto(id);
  setLastVideoId(id);

  // Marcar activo (y visto) en la cuadrícula de tarjetas y en las filas de lista
  document.querySelectorAll('.video-item, .video-row').forEach(el=>{
    const activo = el.dataset.vid===id;
    el.classList.toggle('playing', activo);
    el.classList.toggle('active', activo);
    if (activo && !el.classList.contains('visto')){
      el.classList.add('visto');
      if (!el.querySelector('.vi-done')){
        const dot=document.createElement('span');
        dot.className='vi-done'; dot.title='Ya la viste';
        el.prepend(dot);
      }
    }
  });

  const title=$('videoTitle'); const notes=$('videoNotes');
  if(title){ title.style.display=''; title.textContent=v.titulo; }
  if(notes) notes.textContent=v.notas||'';

  const label=$('videoCurrentLabel');
  const labelText=$('videoCurrentLabelText');
  if (label && labelText){
    if (!v.tipo || v.tipo==='clase'){
      const lista = videosDeNivel(v.disciplina, v.nivel);
      const posicion = lista.findIndex(x=>x.id===v.id) + 1;
      label.style.display='flex';
      labelText.innerHTML = `${esc(v.disciplina)} · ${nivelLabel(v.nivel)} — <span class="clase-actual">Clase ${posicion||1}</span>`;
    } else {
      label.style.display='none';
    }
  }

  const wrap=$('playerWrap'); if(!wrap) return;
  const ph=$('playerPlaceholder'); if(ph) ph.remove();
  wrap.querySelectorAll('iframe,video').forEach(e=>e.remove());

  const url=v.url||'';
  if(url.includes('youtube.com/embed')||url.includes('youtu.be')||url.includes('vimeo.com')){
    let embed=url;
    if(url.includes('youtu.be/')){ const vid_=url.split('youtu.be/')[1].split('?')[0]; embed=`https://www.youtube.com/embed/${vid_}?autoplay=1&rel=0`; }
    else if(url.includes('youtube.com/watch')){ const p=new URLSearchParams(url.split('?')[1]); embed=`https://www.youtube.com/embed/${p.get('v')}?autoplay=1&rel=0`; }
    const ifr=document.createElement('iframe');
    ifr.src=embed;
    ifr.allow='accelerometer;autoplay;clipboard-write;encrypted-media;gyroscope;picture-in-picture;fullscreen';
    ifr.allowFullscreen=true;
    ifr.style.cssText='position:absolute;inset:0;width:100%;height:100%;border:none;';
    wrap.appendChild(ifr);
  } else if(url.match(/\.(mp4|webm|m4v)$/i)){
    const vid_=document.createElement('video');
    vid_.src=url; vid_.controls=true; vid_.autoplay=true; vid_.controlsList='nodownload';
    vid_.oncontextmenu=e=>e.preventDefault();
    vid_.style.cssText='position:absolute;inset:0;width:100%;height:100%;background:#000;';
    wrap.appendChild(vid_);
  } else if(url){
    const ifr=document.createElement('iframe');
    ifr.src=url; ifr.allowFullscreen=true;
    ifr.style.cssText='position:absolute;inset:0;width:100%;height:100%;border:none;';
    wrap.appendChild(ifr);
  }

  // Scroll suave al reproductor
  wrap.scrollIntoView({behavior:'smooth', block:'start'});
}

function clearPlayer(){
  const wrap=$('playerWrap'); if(!wrap) return;
  wrap.querySelectorAll('iframe,video').forEach(e=>e.remove());
  $('videoTitle').style.display='none'; if($('videoNotes')) $('videoNotes').textContent='';
}

/* ══════════════════════════════════════════════
   SECCIÓN 3 — INVITAR AMIGOS (Referidos)
══════════════════════════════════════════════ */
async function renderReferidos(cont){
  cont.style.cssText='padding:28px 24px;max-width:700px;margin:0 auto;';
  cont.innerHTML=`<div class="h2">🎁 Invitar amigos</div>
    <div style="text-align:center;padding:20px 0;color:var(--muted);font-size:13px;">Cargando…</div>`;

  try {
    const r=await fetch('/api/referral',{credentials:'same-origin'});
    if(!r.ok) throw new Error();
    const data=await r.json();
    const link=`${location.origin}/registro.html?ref=${data.code}`;

    cont.innerHTML=`
    <div class="h2">🎁 Invitar amigos</div>

    <!-- Hero -->
    <div class="card gold-glow" style="text-align:center;padding:36px 28px;margin-bottom:20px;">
      <div style="font-size:48px;margin-bottom:14px;">🎁</div>
      <h2 style="font-family:'Sora',sans-serif;font-size:22px;font-weight:700;color:var(--white);margin-bottom:10px;">
        Gana un 30% de descuento</h2>
      <p style="color:var(--text-2);font-size:14px;line-height:1.7;">
        Cada amigo que se registre y pague a través de tu enlace,<br>
        tú consigues automáticamente un <strong style="color:var(--gold-light);">30% de descuento</strong>
        en tu próxima cuota mensual.</p>
    </div>

    <!-- Stats -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:20px;">
      <div class="card" style="text-align:center;">
        <div style="font-size:38px;font-weight:800;font-family:'Sora',sans-serif;color:var(--gold-2);">${data.referred}</div>
        <div style="font-size:12px;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-top:4px;">Amigos invitados</div>
      </div>
      <div class="card" style="text-align:center;">
        <div style="font-size:38px;font-weight:800;font-family:'Sora',sans-serif;color:${data.discount>0?'var(--ok)':'var(--muted)'};">${data.discount}%</div>
        <div style="font-size:12px;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-top:4px;">Descuento activo</div>
      </div>
    </div>

    <!-- Enlace -->
    <div class="card" style="margin-bottom:20px;">
      <div style="font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:10px;font-weight:600;">Tu enlace personal</div>
      <div style="display:flex;gap:10px;align-items:center;">
        <input type="text" id="refLink" value="${esc(link)}" readonly
          style="background:rgba(255,215,0,.06);border-color:rgba(255,215,0,.25);color:var(--gold-light);
            font-size:13px;flex:1;cursor:pointer;"
          onclick="this.select();">
        <button class="btn sm" onclick="copiarEnlace('${esc(link)}')">📋 Copiar</button>
      </div>
      <div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap;">
        <button class="btn sm sec" onclick="compartirWhatsapp('${esc(link)}')">💬 WhatsApp</button>
        <button class="btn sm sec" onclick="compartirEmail('${esc(link)}')">📧 Email</button>
      </div>
    </div>

    <!-- Cómo funciona -->
    <div class="card">
      <div class="h2" style="margin-bottom:14px;">¿Cómo funciona?</div>
      ${[
        {n:1, txt:'Comparte tu enlace con amigos que quieran aprender a bailar'},
        {n:2, txt:'Tu amigo se registra en Malevo usando tu enlace único'},
        {n:3, txt:'Cuando tu amigo realiza su primer pago, ¡tú obtienes el descuento!'},
        {n:4, txt:'El 30% se aplica automáticamente en tu próxima cuota mensual'}
      ].map(s=>`
        <div style="display:flex;gap:14px;align-items:flex-start;padding:12px 0;
          border-bottom:1px solid var(--border);">
          <div style="flex:0 0 32px;height:32px;border-radius:50%;
            background:linear-gradient(135deg,rgba(255,215,0,.25),rgba(138,112,0,.15));
            border:1px solid rgba(255,215,0,.3);display:flex;align-items:center;justify-content:center;
            font-weight:700;font-size:13px;color:var(--gold-2);">${s.n}</div>
          <div style="font-size:13.5px;color:var(--text-2);padding-top:6px;">${s.txt}</div>
        </div>`).join('')}
    </div>`;
  } catch {
    cont.innerHTML+='<div class="vacio">No se pudo cargar la información de referidos.</div>';
  }
}

function copiarEnlace(link){
  portalPlayCopy();   // ← sonido al copiar
  navigator.clipboard?.writeText(link).then(()=>showToast('Enlace copiado','ok'))
    .catch(()=>{ $('refLink')?.select(); document.execCommand('copy'); showToast('Enlace copiado','ok'); });
}
function compartirWhatsapp(link){
  window.open(`https://wa.me/?text=${encodeURIComponent('¡Apúntate a la Academia Malevo! Usa mi enlace: '+link)}`, '_blank');
}
function compartirEmail(link){
  location.href=`mailto:?subject=${encodeURIComponent('Únete a la Academia Malevo')}&body=${encodeURIComponent('¡Hola! Te invito a aprender a bailar en la Academia Malevo. Regístrate con mi enlace: '+link)}`;
}

/* ══════════════════════════════════════════════
   SECCIÓN 4 — MI PERFIL
══════════════════════════════════════════════ */
function renderPerfil(cont, firstTime=false){
  cont.style.cssText='padding:28px 24px;max-width:680px;margin:0 auto;';
  const u=currentUser;

  // Banner de bienvenida (sin backtick anidado)
  const bannerBienvenida = firstTime
    ? '<div class="card" style="margin-bottom:20px;text-align:center;">'+
      '<div style="font-size:32px;margin-bottom:8px;">👋</div>'+
      '<h3 style="font-family:\'Sora\',sans-serif;font-size:17px;color:var(--white);margin-bottom:6px;">¡Bienvenido a Malevo!</h3>'+
      '<p style="color:var(--text-2);font-size:13.5px;">Completa tu perfil para que podamos personalizarlo todo para ti.</p>'+
      '</div>'
    : '';

  const avatarHtml = u.fotoPerfil
    ? '<img src="'+esc(u.fotoPerfil)+'" style="width:100%;height:100%;object-fit:cover;">'
    : '<span style="font-size:34px;opacity:.5;">👤</span>';

  const quitarFotoBtn = u.fotoPerfil
    ? '<button class="btn sm warn" onclick="eliminarFoto()" style="display:inline-flex;align-items:center;gap:6px;">× Quitar foto</button>'
    : '';

  cont.innerHTML=bannerBienvenida+`
  <div class="h2">👤 Mi perfil</div>

  <!-- Foto de perfil -->
  <div class="card" style="margin-bottom:16px;">
    <h3 style="font-family:'Sora',sans-serif;font-size:15px;font-weight:700;color:var(--white);margin-bottom:16px;">
      📷 Foto de perfil</h3>
    <div style="display:flex;align-items:center;gap:22px;flex-wrap:wrap;">
      <div style="flex:0 0 auto;">
        <div id="fotoPreview" style="width:90px;height:90px;border-radius:50%;overflow:hidden;
          background:linear-gradient(135deg,rgba(255,215,0,.2),rgba(138,112,0,.15));
          border:2px solid rgba(255,215,0,.4);display:flex;align-items:center;justify-content:center;
          box-shadow:0 2px 12px rgba(0,0,0,.4);">
          ${avatarHtml}
        </div>
      </div>
      <div style="flex:1;display:flex;flex-direction:column;gap:10px;">
        <p style="color:var(--muted);font-size:13px;line-height:1.5;margin:0;">
          Sube una foto o hazte una con tu cámara.<br>
          Aparecerá en el saludo de tu pantalla de inicio.</p>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
          <label style="cursor:pointer;">
            <input type="file" id="fotoInput" accept="image/*" style="display:none;"
              onchange="previewFoto(this)">
            <span class="btn sm sec" style="display:inline-flex;align-items:center;gap:6px;">📁 Subir foto</span>
          </label>
          <button class="btn sm sec" onclick="capturarFoto()"
            style="display:inline-flex;align-items:center;gap:6px;">📷 Usar cámara</button>
          ${quitarFotoBtn}
        </div>
        <canvas id="fotoCanvas" style="display:none;"></canvas>
        <video id="fotoVideo" autoplay playsinline
          style="display:none;width:220px;border-radius:10px;border:1px solid rgba(255,215,0,.3);margin-top:6px;"></video>
        <div id="fotoCamControls" style="display:none;gap:8px;flex-wrap:wrap;margin-top:4px;">
          <button class="btn sm ok" onclick="tomarFoto()"
            style="display:inline-flex;align-items:center;gap:6px;">📸 Tomar foto</button>
          <button class="btn sm sec" onclick="cancelarCamara()"
            style="display:inline-flex;align-items:center;gap:6px;">× Cancelar</button>
        </div>
      </div>
    </div>
  </div>

  <div class="card" style="margin-bottom:16px;">
    <h3 style="font-family:'Sora',sans-serif;font-size:15px;font-weight:700;color:var(--white);margin-bottom:18px;">
      Datos personales</h3>
    <label class="label-field">Nombre completo</label>
    <input type="text" id="pNombre" value="${esc(u.nombre||'')}" placeholder="Tu nombre">
    <div class="g2">
      <div><label class="label-field">Email</label>
        <input type="email" id="pEmail" value="${esc(u.email||'')}" placeholder="correo@…"></div>
      <div><label class="label-field">Teléfono</label>
        <input type="tel" id="pTel" value="${esc(u.telefono||'')}" placeholder="600 000 000"></div>
    </div>
    <label class="label-field">Sobre mí (opcional)</label>
    <textarea id="pBio" rows="2" placeholder="Cuéntanos algo sobre ti, tus objetivos…">${esc(u.bio||'')}</textarea>
  </div>

  <div class="card" style="margin-bottom:16px;">
    <h3 style="font-family:'Sora',sans-serif;font-size:15px;font-weight:700;color:var(--white);margin-bottom:18px;">
      Mi rol de baile</h3>
    <p style="color:var(--muted);font-size:13px;margin-bottom:16px;">
      Indica tu rol preferido en las clases de pareja.</p>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;">
      ${[{v:'leader',l:'Leader',i:'🕺',d:'Guío en la pareja'},
         {v:'follower',l:'Follower',i:'💃',d:'Sigo en la pareja'},
         {v:'indiferente',l:'Indiferente',i:'🔄',d:'Me adapto a lo que toque'}].map(r=>`
        <div onclick="selectRol('${r.v}')" id="rolCard_${r.v}"
          style="padding:16px 12px;border-radius:var(--r);cursor:pointer;text-align:center;
            transition:all .2s;border:2px solid ${(u.rol||'indiferente')===r.v?'var(--gold)':'var(--border)'};
            background:${(u.rol||'indiferente')===r.v?'rgba(255,215,0,.12)':'rgba(255,255,255,.03)'};">
          <div style="font-size:28px;margin-bottom:6px;">${r.i}</div>
          <div style="font-size:13px;font-weight:700;color:${(u.rol||'indiferente')===r.v?'var(--gold-2)':'var(--text-2)'};">${r.l}</div>
          <div style="font-size:11px;color:var(--muted);margin-top:3px;">${r.d}</div>
        </div>`).join('')}
    </div>
    <input type="hidden" id="pRol" value="${esc(u.rol||'indiferente')}">
  </div>

  <div class="card" style="margin-bottom:16px;">
    <h3 style="font-family:'Sora',sans-serif;font-size:15px;font-weight:700;color:var(--white);margin-bottom:18px;">
      Mis niveles de baile</h3>
    <p style="color:var(--muted);font-size:13px;margin-bottom:16px;">
      El administrador asignará tus niveles oficiales. Puedes indicar dónde te sientes más cómodo.</p>
    <div class="g2">
      <div><label class="label-field">Nivel en Bachata</label>
        <select id="pNivelBachata">
          <option value="">Sin experiencia</option>
          ${[1,2,3,4].map(n=>`<option value="${n}" ${u.nivelBachata==n?'selected':''}>Nivel ${n}</option>`).join('')}
        </select></div>
      <div><label class="label-field">Nivel en Salsa</label>
        <select id="pNivelSalsa">
          <option value="">Sin experiencia</option>
          ${[1,2,3,4].map(n=>`<option value="${n}" ${u.nivelSalsa==n?'selected':''}>Nivel ${n}</option>`).join('')}
        </select></div>
    </div>
  </div>

  <div class="card" style="margin-bottom:16px;">
    <h3 style="font-family:'Sora',sans-serif;font-size:15px;font-weight:700;color:var(--white);margin-bottom:18px;">
      Cambiar contraseña</h3>
    <div class="g2">
      <div><label class="label-field">Nueva contraseña</label>
        <input type="password" id="pNewPass" placeholder="Mínimo 6 caracteres" autocomplete="new-password"></div>
      <div><label class="label-field">Repetir contraseña</label>
        <input type="password" id="pNewPass2" placeholder="Repetir…" autocomplete="new-password"></div>
    </div>
    <small style="color:var(--muted);font-size:12px;margin-top:6px;display:block;">Déjalo vacío para no cambiarla.</small>
  </div>

  <div style="display:flex;gap:12px;align-items:center;">
    <button class="btn" onclick="guardarPerfil()"
      style="padding:12px 28px;font-size:14px;">${firstTime?'Guardar y continuar →':'Guardar cambios'}</button>
    ${!firstTime?'<button class="btn sec" onclick="pNavigate(\'agenda\')">Cancelar</button>':''}
  </div>

  <!-- Info del plan -->
  <div class="card" style="margin-top:16px;background:rgba(255,215,0,.05);border-color:rgba(255,215,0,.18);">
    <div style="display:flex;justify-content:space-between;align-items:center;">
      <div>
        <div style="font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;">Mi plan actual</div>
        <div style="font-size:18px;font-weight:700;color:var(--gold-2);">${planLabel(u.plan)}</div>
      </div>
      ${u.plan==='80'?'<span class="badge gold">🎓 VIP · Aula Virtual</span>':'<span class="badge muted">Solo presencial</span>'}
    </div>
    <p style="color:var(--muted);font-size:12.5px;margin-top:10px;">
      Para cambiar de plan habla con Gastón o Gimena.</p>
  </div>`;
}

function selectRol(v){
  ['leader','follower','indiferente'].forEach(r=>{
    const card=document.getElementById('rolCard_'+r);
    if(!card) return;
    const active=r===v;
    card.style.borderColor=active?'var(--gold)':'var(--border)';
    card.style.background=active?'rgba(255,215,0,.12)':'rgba(255,255,255,.03)';
    card.querySelector('div:nth-child(2)').style.color=active?'var(--gold-2)':'var(--text-2)';
  });
  const inp=document.getElementById('pRol'); if(inp) inp.value=v;
}

function planLabel(plan){
  const m={'suelta':'Clase suelta','35':'1 clase/sem','50':'2 clases/sem','80':'VIP · Full Pass','bono':'Bono 10 clases'};
  return m[plan]||plan||'Sin plan asignado';
}

async function guardarPerfil(){
  const pass=$('pNewPass')?.value||'';
  const pass2=$('pNewPass2')?.value||'';
  if(pass && pass!==pass2){ showToast('Las contraseñas no coinciden','warn'); return; }
  if(pass && pass.length<6){ showToast('La contraseña debe tener al menos 6 caracteres','warn'); return; }

  const data={
    nombre:$('pNombre')?.value.trim()||'',
    email:$('pEmail')?.value.trim()||'',
    telefono:$('pTel')?.value.trim()||'',
    bio:$('pBio')?.value.trim()||'',
    rol:$('pRol')?.value||'indiferente',
    nivelBachata:$('pNivelBachata')?.value||null,
    nivelSalsa:$('pNivelSalsa')?.value||null,
  };

  // Incluir foto si se cambió
  if(currentUser._fotoTemporal !== undefined){
    data.fotoPerfil = currentUser._fotoTemporal; // '' para eliminar, dataUrl para guardar
  }

  if(pass) data.password=pass;

  try {
    const r=await fetch('/api/profile',{method:'PUT',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify(data), credentials:'same-origin'});
    if(!r.ok) throw new Error();
    const j=await r.json();
    Object.assign(currentUser, j.user);
    // Limpiar foto temporal tras guardar
    delete currentUser._fotoTemporal;

    if($('pUserBadge')) $('pUserBadge').textContent=currentUser.nombre;
    showToast('Perfil guardado','ok');
    portalPlaySuccess();
    cancelarCamara(); // cerrar cámara si estaba abierta
    if(!currentUser.profileComplete||activeView==='perfil'){
      setTimeout(()=>pNavigate('inicio'),800);
    }
  } catch { showToast('Error al guardar el perfil','warn'); }
}

/* ══════════════════════════════════════════════
   PAGO PENDIENTE (onboarding incompleto)
══════════════════════════════════════════════ */
const PLAN_LABELS_P = {
  suelta:{ nombre:'Clase suelta',    desc:'Una clase individual, sin cuota', icon:'🎟' },
  '35':  { nombre:'1 clase/semana',  desc:'Cuota mensual · Aula Virtual',    icon:'📅' },
  '50':  { nombre:'2 clases/semana', desc:'Cuota mensual · Aula Virtual',    icon:'📅📅' },
  '80':  { nombre:'VIP / Full Pass', desc:'Clases ilimitadas · Aula Virtual',icon:'🎓' },
  bono:  { nombre:'Bono 10 clases',  desc:'Flexible, sin caducidad',         icon:'🎫' },
};

function mostrarPantallaPago(st){
  // Inyectar overlay de pago en el portal
  let overlay = document.getElementById('paymentOverlay');
  if (!overlay){
    overlay = document.createElement('div');
    overlay.id = 'paymentOverlay';
    overlay.style.cssText = 'position:fixed;inset:0;z-index:200;display:flex;align-items:center;justify-content:center;padding:24px;background:radial-gradient(ellipse 120% 100% at 50% -20%,#1a1200 0%,#0A0A0A 90%);';
    document.body.appendChild(overlay);
  }
  const p   = PLAN_LABELS_P[st.plan] || { nombre: st.plan, desc:'', icon:'📋' };
  const tok = st.onboardingToken || '';

  // Construir HTML de métodos fuera del template para evitar backtick anidados
  const metodosHtml = ['transferencia','efectivo','bizum','tarjeta'].map(function(m,i){
    const icons={transferencia:'🏦',efectivo:'💵',bizum:'📱',tarjeta:'💳'};
    const names={transferencia:'Transferencia',efectivo:'Efectivo',bizum:'Bizum',tarjeta:'Tarjeta'};
    const bord = i===0?'var(--gold)':'rgba(255,215,0,.18)';
    const bg   = i===0?'rgba(255,215,0,.12)':'rgba(255,255,255,.03)';
    return '<div onclick="selectMetodoPago(\''+m+'\')" id="pm_'+m+'"'+
      ' style="padding:14px;border-radius:10px;cursor:pointer;text-align:center;'+
      'border:2px solid '+bord+';background:'+bg+';transition:all .2s;">'+
      '<div style="font-size:24px;margin-bottom:5px;">'+icons[m]+'</div>'+
      '<div style="font-size:12.5px;font-weight:600;color:var(--text-2);">'+names[m]+'</div>'+
      '</div>';
  }).join('');

  overlay.innerHTML = `
    <div style="width:100%;max-width:460px;background:rgba(10,8,0,.97);
      backdrop-filter:blur(40px);border:1px solid rgba(255,215,0,.28);border-radius:28px;
      padding:44px 38px;box-shadow:0 24px 64px rgba(0,0,0,.85),inset 0 1px 0 rgba(255,255,255,.06);
      text-align:center;animation:scaleIn .4s cubic-bezier(.34,1.56,.64,1);">
      <div style="font-size:48px;margin-bottom:14px;">💳</div>
      <h2 style="font-family:'Sora',sans-serif;font-size:22px;font-weight:700;color:var(--white);margin-bottom:8px;">
        Un paso más, ${esc(st.nombre||'')}</h2>
      <p style="color:var(--text-2);font-size:13.5px;line-height:1.75;margin-bottom:24px;">
        Para acceder a los contenidos necesitas confirmar el pago de tu primer mes.</p>
      <div style="background:rgba(255,215,0,.08);border:1px solid rgba(255,215,0,.22);
        border-radius:16px;padding:18px 22px;margin-bottom:24px;text-align:left;display:flex;justify-content:space-between;align-items:center;">
        <div>
          <div style="font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;">Plan seleccionado</div>
          <div style="font-size:17px;font-weight:700;color:var(--gold-2);">${p.icon} ${p.nombre}</div>
          <div style="font-size:12px;color:var(--muted);margin-top:2px;">${p.desc}</div>
        </div>
        <div style="font-family:'Sora',sans-serif;font-size:30px;font-weight:800;color:var(--gold-light);">
          ${st.precio}<span style="font-size:14px;color:var(--muted);margin-left:2px;">€</span>
        </div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:24px;" id="pMetodos">
        ${metodosHtml}
      </div>
      <div id="payErr" style="color:var(--warn);font-size:13px;margin-bottom:12px;min-height:18px;"></div>
      <button id="btnPagar" onclick="confirmarPagoPortal('${esc(tok)}')"
        style="width:100%;padding:15px;background:linear-gradient(135deg,#FFD700,#8A7000);
          color:#fff;border:none;border-radius:10px;font-size:15px;font-weight:600;
          cursor:pointer;font-family:inherit;transition:all .2s;
          box-shadow:0 5px 18px rgba(0,0,0,.4),inset 0 1px 0 rgba(255,255,255,.15);">
        ✓ Confirmar pago y entrar
      </button>
    </div>`;

  window._metodoPagoSeleccionado = 'transferencia';
}

function selectMetodoPago(m){
  window._metodoPagoSeleccionado = m;
  document.querySelectorAll('#pMetodos > div').forEach(d=>{
    const active = d.id === 'pm_'+m;
    d.style.borderColor = active ? 'var(--gold)' : 'rgba(255,215,0,.18)';
    d.style.background  = active ? 'rgba(255,215,0,.12)' : 'rgba(255,255,255,.03)';
  });
}

async function confirmarPagoPortal(tok){
  const btn = document.getElementById('btnPagar');
  const err = document.getElementById('payErr');
  if (btn) { btn.disabled=true; btn.textContent='Procesando…'; }
  if (err) err.textContent='';
  try {
    const r = await fetch('/api/onboarding/confirm-payment',{
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ onboardingToken: tok, metodo: window._metodoPagoSeleccionado||'transferencia' }),
      credentials:'same-origin'
    });
    const j = await r.json();
    if (!r.ok){
      if (err) err.textContent = j.error || 'Error al confirmar el pago.';
      if (btn) { btn.disabled=false; btn.textContent='✓ Confirmar pago y entrar'; }
      return;
    }
    // Pago confirmado → quitar overlay y arrancar portal
    const overlay = document.getElementById('paymentOverlay');
    if (overlay) overlay.remove();
    showToast('¡Pago registrado! Bienvenido/a a Malevo 🎉','ok',4000);
    await arrancarPortal();
  } catch {
    if (err) err.textContent = 'No se pudo conectar. Inténtalo de nuevo.';
    if (btn) { btn.disabled=false; btn.textContent='✓ Confirmar pago y entrar'; }
  }
}

/* ══════════════════════════════════════════════
   FOTO DE PERFIL
══════════════════════════════════════════════ */
function previewFoto(input){
  const file = input.files[0];
  if (!file) return;
  if (file.size > 2 * 1024 * 1024){ showToast('La imagen debe ser menor de 2 MB','warn'); return; }
  const reader = new FileReader();
  reader.onload = e => {
    const dataUrl = e.target.result;
    actualizarPreviewFoto(dataUrl);
  };
  reader.readAsDataURL(file);
}

function actualizarPreviewFoto(dataUrl){
  const preview = $('fotoPreview');
  if(preview) preview.innerHTML = `<img src="${dataUrl}" style="width:100%;height:100%;object-fit:cover;">`;
  // Guardar temporalmente en currentUser para que se refleje al guardar el perfil
  currentUser._fotoTemporal = dataUrl;
}

async function capturarFoto(){
  const video = $('fotoVideo');
  const controls = $('fotoCamControls');
  if(!video || !controls) return;
  try {
    const stream = await navigator.mediaDevices.getUserMedia({video:{facingMode:'user'}});
    video._stream = stream;
    video.srcObject = stream;
    video.style.display = 'block';
    controls.style.display = 'flex';
  } catch {
    showToast('No se pudo acceder a la cámara','warn');
  }
}

function tomarFoto(){
  const video = $('fotoVideo');
  const canvas = $('fotoCanvas');
  if(!video || !canvas) return;
  canvas.width  = video.videoWidth  || 320;
  canvas.height = video.videoHeight || 320;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(video, 0, 0);
  const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
  cancelarCamara();
  actualizarPreviewFoto(dataUrl);
  showToast('Foto capturada — pulsa Guardar para aplicarla','info');
}

function cancelarCamara(){
  const video = $('fotoVideo');
  const controls = $('fotoCamControls');
  if(video){
    if(video._stream) video._stream.getTracks().forEach(t=>t.stop());
    video.style.display = 'none';
  }
  if(controls) controls.style.display = 'none';
}

function eliminarFoto(){
  if(!confirm('¿Quitar la foto de perfil?')) return;
  currentUser._fotoTemporal = '';
  const preview = $('fotoPreview');
  if(preview) preview.innerHTML = '<span style="font-size:34px;opacity:.5;">👤</span>';
  showToast('Foto eliminada — pulsa Guardar para confirmar','info');
}

iniciarPortal();
